from datetime import datetime, timezone
from enum import Enum
from typing import Any
from pydantic import BaseModel, Field


class JobStatus(str, Enum):
    STARTED = "STARTED"
    RUNNING = "RUNNING"
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"
    SKIPPED = "SKIPPED"


class JobResult(BaseModel):
    job_id: str
    job_type: str
    status: JobStatus
    started_at: datetime
    finished_at: datetime | None = None
    processed_files: list[str] = Field(default_factory=list)
    deleted_paths: list[str] = Field(default_factory=list)
    message: str = ""
    details: dict[str, Any] = Field(default_factory=dict)

    @classmethod
    def started(cls, job_id: str, job_type: str) -> "JobResult":
        return cls(
            job_id=job_id,
            job_type=job_type,
            status=JobStatus.STARTED,
            started_at=datetime.now(timezone.utc),
        )
