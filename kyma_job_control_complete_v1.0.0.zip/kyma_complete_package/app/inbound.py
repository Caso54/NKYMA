import base64
import csv
import logging
import shutil
import uuid
from datetime import datetime, timezone
from pathlib import Path
from .config import settings
from .crypto import decrypt_gpg
from .downstream import deliver_file
from .models import JobResult, JobStatus
from .status_outbox import publish
from .storage import SftpStorage

log = logging.getLogger(__name__)


def _decode_base64_columns(source: Path, target: Path, columns: list[str]) -> None:
    if not columns:
        shutil.copy2(source, target)
        return
    with source.open("r", encoding="utf-8-sig", newline="") as src, target.open("w", encoding="utf-8", newline="") as dst:
        reader = csv.DictReader(src, delimiter=";")
        writer = csv.DictWriter(dst, fieldnames=reader.fieldnames, delimiter=";", lineterminator="\n")
        writer.writeheader()
        for row in reader:
            for col in columns:
                if row.get(col):
                    row[col] = base64.b64decode(row[col]).decode("utf-8")
            writer.writerow(row)


def run_inbound(base64_columns: list[str] | None = None) -> JobResult:
    job_id = f"IN-{datetime.now(timezone.utc):%Y%m%dT%H%M%SZ}-{uuid.uuid4().hex[:8]}"
    result = JobResult.started(job_id, "INBOUND")
    work = settings.workdir / job_id
    work.mkdir(parents=True, exist_ok=True)
    try:
        with SftpStorage() as sftp:
            sftp.ensure_dir(settings.inbound_decrypted)
            candidates = sftp.list_matching(settings.inbound_root, "*.gpg")
            for remote in candidates:
                local_gpg = work / Path(remote).name
                clear_name = Path(remote).name[:-4] if remote.lower().endswith(".gpg") else Path(remote).name + ".clear"
                local_clear = work / clear_name
                local_final = work / f"decoded-{clear_name}"
                sftp.download(remote, local_gpg)
                decrypt_gpg(local_gpg, local_clear)
                _decode_base64_columns(local_clear, local_final, base64_columns or [])
                deliver_file(local_final, clear_name)
                remote_clear = f"{settings.inbound_decrypted.rstrip('/')}/{clear_name}"
                sftp.upload(local_final, remote_clear)
                sftp.remove(remote)
                result.processed_files.append(remote)

        result.status = JobStatus.SUCCESS
        result.message = f"{len(result.processed_files)} inbound file(s) processed"
    except Exception as exc:
        result.status = JobStatus.FAILED
        result.message = str(exc)
        log.exception("Inbound failed", extra={"job_id": job_id})
    finally:
        result.finished_at = datetime.now(timezone.utc)
        try:
            publish(result)
        except Exception:
            log.exception("Could not publish inbound status", extra={"job_id": job_id})
        shutil.rmtree(work, ignore_errors=True)
    return result
