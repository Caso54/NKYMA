import subprocess
from pathlib import Path
from .config import settings


def _run(cmd: list[str]) -> None:
    proc = subprocess.run(cmd, capture_output=True, text=True)
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr.strip() or "GPG command failed")


def decrypt_gpg(source: Path, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    cmd = [
        settings.gpg_binary, "--batch", "--yes", "--pinentry-mode", "loopback",
        "--passphrase", settings.gpg_passphrase,
        "--output", str(target), "--decrypt", str(source),
    ]
    _run(cmd)


def encrypt_symmetric(source: Path, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    cmd = [
        settings.gpg_binary, "--batch", "--yes", "--pinentry-mode", "loopback",
        "--passphrase", settings.gpg_passphrase,
        "--cipher-algo", "AES256", "--symmetric",
        "--output", str(target), str(source),
    ]
    _run(cmd)
