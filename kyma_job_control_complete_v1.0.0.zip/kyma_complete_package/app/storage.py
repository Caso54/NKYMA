import fnmatch
import os
import stat
from pathlib import Path
from typing import Iterable
import paramiko
from .config import settings


class SftpStorage:
    def __init__(self):
        self.transport = None
        self.client = None

    def __enter__(self):
        self.transport = paramiko.Transport((settings.sftp_host, settings.sftp_port))
        if settings.sftp_private_key:
            pkey = paramiko.RSAKey.from_private_key_file(settings.sftp_private_key)
            self.transport.connect(username=settings.sftp_username, pkey=pkey)
        else:
            self.transport.connect(username=settings.sftp_username, password=settings.sftp_password)
        self.client = paramiko.SFTPClient.from_transport(self.transport)
        return self

    def __exit__(self, exc_type, exc, tb):
        if self.client:
            self.client.close()
        if self.transport:
            self.transport.close()

    def ensure_dir(self, remote_dir: str) -> None:
        parts = remote_dir.strip("/").split("/") if remote_dir.strip("/") else []
        current = ""
        for part in parts:
            current += "/" + part
            try:
                self.client.stat(current)
            except FileNotFoundError:
                self.client.mkdir(current)

    def list_matching(self, remote_dir: str, pattern: str) -> list[str]:
        try:
            names = self.client.listdir(remote_dir)
        except FileNotFoundError:
            return []
        return sorted([f"{remote_dir.rstrip('/')}/{name}" for name in names if fnmatch.fnmatch(name, pattern)])

    def list_files_recursive(self, remote_dir: str) -> list[str]:
        result = []
        try:
            entries = self.client.listdir_attr(remote_dir)
        except FileNotFoundError:
            return result
        for e in entries:
            path = f"{remote_dir.rstrip('/')}/{e.filename}"
            if stat.S_ISDIR(e.st_mode):
                result.extend(self.list_files_recursive(path))
            else:
                result.append(path)
        return result

    def download(self, remote_path: str, local_path: Path) -> None:
        local_path.parent.mkdir(parents=True, exist_ok=True)
        self.client.get(remote_path, str(local_path))

    def upload(self, local_path: Path, remote_path: str) -> None:
        self.ensure_dir(os.path.dirname(remote_path))
        self.client.put(str(local_path), remote_path)

    def remove(self, remote_path: str) -> None:
        self.client.remove(remote_path)

    def remove_tree(self, remote_dir: str) -> None:
        try:
            entries = self.client.listdir_attr(remote_dir)
        except FileNotFoundError:
            return
        for e in entries:
            path = f"{remote_dir.rstrip('/')}/{e.filename}"
            if stat.S_ISDIR(e.st_mode):
                self.remove_tree(path)
            else:
                self.client.remove(path)
        self.client.rmdir(remote_dir)
