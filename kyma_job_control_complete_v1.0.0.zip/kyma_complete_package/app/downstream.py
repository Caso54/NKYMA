from pathlib import Path
import requests
from .config import settings


def deliver_file(path: Path, logical_name: str | None = None) -> dict:
    if not settings.downstream_api_url:
        return {"mode": "no-op", "file": str(path)}
    headers = {}
    if settings.downstream_api_token:
        headers["Authorization"] = f"Bearer {settings.downstream_api_token}"
    with path.open("rb") as fh:
        files = {"file": (logical_name or path.name, fh, "application/octet-stream")}
        r = requests.post(
            settings.downstream_api_url,
            headers=headers,
            files=files,
            timeout=settings.downstream_timeout_seconds,
        )
    r.raise_for_status()
    try:
        return r.json()
    except Exception:
        return {"status_code": r.status_code, "text": r.text[:1000]}
