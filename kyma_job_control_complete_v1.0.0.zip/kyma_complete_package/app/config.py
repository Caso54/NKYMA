from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="KYMA_", env_file=".env", extra="ignore")

    app_name: str = "kyma-job-control"
    log_level: str = "INFO"

    # HDLF/SFTP
    sftp_host: str = ""
    sftp_port: int = 22
    sftp_username: str = ""
    sftp_password: str = ""
    sftp_private_key: str = ""

    inbound_root: str = "/inbound"
    inbound_decrypted: str = "/inbound/decrypted"
    outbound_root: str = "/outbound"
    outbound_encrypted: str = "/outbound/encrypted"

    # Outbound Avaloq AS300
    as300_source_dir: str = "/outbound/DS_DL_EX_AS300/initial"
    as300_pattern: str = "part*.csv"
    as300_filename_prefix: str = "SAP_AVQ_AS300"

    # Crypto
    gpg_binary: str = "gpg"
    gpg_passphrase: str = ""

    # Downstream API, e.g. ABAP/DSP load endpoint
    downstream_api_url: str = ""
    downstream_api_token: str = ""
    downstream_timeout_seconds: int = 120

    # Central status / OData fallback / BPA callback
    status_target_url: str = ""
    status_target_token: str = ""
    bpa_callback_url: str = ""
    bpa_callback_token: str = ""

    # Runtime
    workdir: Path = Path("/tmp/kyma-job-control")
    processed_retention_days: int = 14
    max_parallel_jobs: int = 2


settings = Settings()
