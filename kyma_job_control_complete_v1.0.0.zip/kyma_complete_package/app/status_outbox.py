import json
import logging
from datetime import datetime, timezone
from pathlib import Path
import requests
from .config import settings
from .models import JobResult

log = logging.getLogger(__name__)


def _headers(token: str) -> dict[str, str]:
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    return headers


def persist_local(result: JobResult) -> Path:
    settings.workdir.mkdir(parents=True, exist_ok=True)
    outbox = settings.workdir / "status-outbox"
    outbox.mkdir(parents=True, exist_ok=True)
    path = outbox / f"{result.job_id}.json"
    path.write_text(result.model_dump_json(indent=2), encoding="utf-8")
    return path


def publish(result: JobResult) -> None:
    payload = result.model_dump(mode="json")
    payload["published_at"] = datetime.now(timezone.utc).isoformat()
    pending = persist_local(result)

    targets = [
        (settings.status_target_url, settings.status_target_token, "status-target"),
        (settings.bpa_callback_url, settings.bpa_callback_token, "bpa-callback"),
    ]
    errors = []
    for url, token, name in targets:
        if not url:
            continue
        try:
            r = requests.post(url, headers=_headers(token), data=json.dumps(payload), timeout=30)
            r.raise_for_status()
        except Exception as exc:
            errors.append(f"{name}: {exc}")
            log.exception("Status delivery failed", extra={"job_id": result.job_id, "step": name})

    if errors:
        raise RuntimeError("; ".join(errors))
    pending.unlink(missing_ok=True)


def retry_pending() -> list[str]:
    outbox = settings.workdir / "status-outbox"
    if not outbox.exists():
        return []
    delivered = []
    for p in sorted(outbox.glob("*.json")):
        result = JobResult.model_validate_json(p.read_text(encoding="utf-8"))
        try:
            publish(result)
            delivered.append(p.name)
        except Exception:
            pass
    return delivered
