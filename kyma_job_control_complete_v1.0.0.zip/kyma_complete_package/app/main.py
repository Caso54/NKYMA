from fastapi import FastAPI, Header, HTTPException
from .config import settings
from .inbound import run_inbound
from .logging_setup import configure_logging
from .outbound import run_outbound
from .status_outbox import retry_pending

configure_logging(settings.log_level)
app = FastAPI(title=settings.app_name, version="1.0.0")


def _check_token(authorization: str | None):
    # Optional lightweight endpoint protection. In productive Kyma use APIRule/OAuth2/mTLS.
    expected = settings.status_target_token
    if expected and authorization != f"Bearer {expected}":
        raise HTTPException(status_code=401, detail="Unauthorized")


@app.get("/health")
def health():
    return {"status": "UP"}


@app.post("/jobs/inbound")
def inbound(authorization: str | None = Header(default=None), base64_columns: str = ""):
    _check_token(authorization)
    columns = [c.strip() for c in base64_columns.split(",") if c.strip()]
    return run_inbound(columns).model_dump(mode="json")


@app.post("/jobs/outbound")
def outbound(authorization: str | None = Header(default=None)):
    _check_token(authorization)
    return run_outbound().model_dump(mode="json")


@app.post("/jobs/status-outbox/retry")
def status_retry(authorization: str | None = Header(default=None)):
    _check_token(authorization)
    return {"delivered": retry_pending()}
