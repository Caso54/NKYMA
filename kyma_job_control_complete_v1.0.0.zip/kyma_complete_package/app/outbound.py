import logging
import shutil
import uuid
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from .config import settings
from .crypto import encrypt_symmetric
from .models import JobResult, JobStatus
from .status_outbox import publish
from .storage import SftpStorage

log = logging.getLogger(__name__)


def _timestamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def _zip_files(files: list[Path], target: Path) -> None:
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for f in files:
            zf.write(f, arcname=f.name)


def run_outbound() -> JobResult:
    job_id = f"OUT-{datetime.now(timezone.utc):%Y%m%dT%H%M%SZ}-{uuid.uuid4().hex[:8]}"
    result = JobResult.started(job_id, "OUTBOUND")
    work = settings.workdir / job_id
    work.mkdir(parents=True, exist_ok=True)
    try:
        with SftpStorage() as sftp:
            sftp.ensure_dir(settings.outbound_encrypted)

            # 1) AS300 CSV: one DataSphere extraction can consist of several part*.csv files.
            csv_remote = sftp.list_matching(settings.as300_source_dir, settings.as300_pattern)
            if csv_remote:
                local_parts = []
                for remote in csv_remote:
                    lp = work / Path(remote).name
                    sftp.download(remote, lp)
                    local_parts.append(lp)
                base = f"{settings.as300_filename_prefix}_{_timestamp()}"
                zip_path = work / f"{base}.zip"
                _zip_files(local_parts, zip_path)
                gpg_path = work / f"{base}.zip.gpg"
                encrypt_symmetric(zip_path, gpg_path)
                remote_target = f"{settings.outbound_encrypted.rstrip('/')}/{gpg_path.name}"
                sftp.upload(gpg_path, remote_target)
                result.processed_files.extend(csv_remote)
                # Delete entire processed DataSphere extractor directory after successful upload.
                extractor_root = settings.as300_source_dir.rsplit("/", 1)[0]
                sftp.remove_tree(extractor_root)
                result.deleted_paths.append(extractor_root)

            # 2) Zipped parquet files anywhere below /outbound, excluding /outbound/encrypted.
            all_files = sftp.list_files_recursive(settings.outbound_root)
            parquet_archives = [
                p for p in all_files
                if p.lower().endswith((".zip", ".parquet.zip"))
                and not p.startswith(settings.outbound_encrypted.rstrip("/") + "/")
                and not p.startswith(settings.as300_source_dir.rsplit("/", 1)[0].rstrip("/") + "/")
            ]
            for remote in parquet_archives:
                src = work / Path(remote).name
                sftp.download(remote, src)
                stamped = work / f"{src.stem}_{_timestamp()}{src.suffix}"
                shutil.copy2(src, stamped)
                encrypted = work / f"{stamped.name}.gpg"
                encrypt_symmetric(stamped, encrypted)
                remote_target = f"{settings.outbound_encrypted.rstrip('/')}/{encrypted.name}"
                sftp.upload(encrypted, remote_target)
                sftp.remove(remote)
                result.processed_files.append(remote)
                result.deleted_paths.append(remote)

        result.status = JobStatus.SUCCESS
        result.message = f"{len(result.processed_files)} outbound file(s) processed"
    except Exception as exc:
        result.status = JobStatus.FAILED
        result.message = str(exc)
        log.exception("Outbound failed", extra={"job_id": job_id})
    finally:
        result.finished_at = datetime.now(timezone.utc)
        try:
            publish(result)
        except Exception:
            log.exception("Could not publish outbound status", extra={"job_id": job_id})
        shutil.rmtree(work, ignore_errors=True)
    return result
