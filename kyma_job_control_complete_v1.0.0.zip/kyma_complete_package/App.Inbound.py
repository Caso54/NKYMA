"""Compatibility launcher for the historic filename App.Inbound.py."""
from app.logging_setup import configure_logging
from app.config import settings
from app.inbound import run_inbound

if __name__ == "__main__":
    configure_logging(settings.log_level)
    result = run_inbound()
    print(result.model_dump_json(indent=2))
    raise SystemExit(0 if result.status.value == "SUCCESS" else 1)
