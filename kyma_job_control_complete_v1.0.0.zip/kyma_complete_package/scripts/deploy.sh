#!/usr/bin/env bash
set -euo pipefail
kubectl apply -f k8s/namespace.yaml
kubectl apply -f k8s/configmap.yaml
kubectl apply -f k8s/secret.yaml
kubectl apply -f k8s/deployment.yaml
kubectl apply -f k8s/service.yaml
# Fallback CronJobs only if SAP Job Scheduling Service / BPA is not triggering the API.
# kubectl apply -f k8s/cronjob-inbound.yaml
# kubectl apply -f k8s/cronjob-outbound.yaml
# kubectl apply -f k8s/cronjob-status-outbox.yaml
