#!/usr/bin/env bash
set -euo pipefail
IMAGE="${1:-kyma-job-control:1.0.0}"
docker build -t "$IMAGE" .
echo "Built $IMAGE"
