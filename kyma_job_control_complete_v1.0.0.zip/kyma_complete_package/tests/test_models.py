from app.models import JobResult, JobStatus

def test_started():
    r = JobResult.started("1", "INBOUND")
    assert r.status == JobStatus.STARTED
    assert r.job_type == "INBOUND"
