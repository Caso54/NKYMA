# Kyma Job Control – Complete Package

## Purpose
Central Kyma runtime for DataSphere/HDLF file processing with external scheduling by SAP Job Scheduling Service or SAP Build Process Automation. Kubernetes CronJobs are included as fallback only.

## Main components
- `app/inbound.py`: inbound GPG decryption, optional Base64 decoding, delivery to downstream API, source cleanup.
- `app/outbound.py`: AS300 CSV parts -> timestamped ZIP -> symmetric AES-256 GPG -> `/outbound/encrypted`; zipped parquet -> timestamp -> GPG -> `/outbound/encrypted`; processed sources are deleted only after successful target upload.
- `app/status_outbox.py`: durable local status outbox and callback to central status/OData/BPA endpoints.
- `app/main.py`: HTTP API to trigger jobs centrally.
- `App.Inbound.py`, `App.Outbound.py`, `app.status_outbox.py`: command-line compatibility launchers.

## HTTP endpoints
- `GET /health`
- `POST /jobs/inbound`
- `POST /jobs/outbound`
- `POST /jobs/status-outbox/retry`

These endpoints are the preferred trigger points for SAP Job Scheduling Service/BPA. Do not enable the fallback CronJobs in parallel unless duplicate execution is technically prevented.

## Outbound AS300
Source: `/outbound/DS_DL_EX_AS300/initial/part*.csv`
Target: `/outbound/encrypted/SAP_AVQ_AS300_YYYYMMDD_HHMMSS.zip.gpg`
After successful upload, `/outbound/DS_DL_EX_AS300` is deleted so a new DataSphere extraction can be handled cleanly.

## Parquet archives
Zipped parquet files found below `/outbound` (except `/outbound/encrypted`) are timestamped, symmetrically encrypted and uploaded to `/outbound/encrypted`. The source archive is deleted after successful upload.

## Secrets
Never commit `k8s/secret.yaml` or `.env`. Create them from the supplied examples.

## Build
```bash
./scripts/build.sh <REGISTRY>/kyma-job-control:1.0.0
docker push <REGISTRY>/kyma-job-control:1.0.0
```

## Deploy
1. Copy `k8s/secret.example.yaml` to `k8s/secret.yaml` and fill secrets.
2. Replace `<REGISTRY>` in deployment files.
3. Run `./scripts/deploy.sh`.

## Scheduling strategy
1. Preferred: SAP Job Scheduling Service calls `/jobs/inbound` and `/jobs/outbound`.
2. Optional orchestration: SAP Build Process Automation calls the same endpoints and receives status callbacks.
3. Fallback: Kubernetes CronJobs.
4. OData status target can be configured using `KYMA_STATUS_TARGET_URL`.

## Important production extensions
Before productive operation, add the project-specific daily/monthly completeness control table, exact extractor whitelist, OAuth2/mTLS via Kyma API exposure, persistent volume or external persistence for the status outbox, and monitoring/alerting. The included outbox is local filesystem based and therefore only durable for the lifetime of the pod unless a persistent volume is mounted.
