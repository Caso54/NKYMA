# Architecture and processing sequence

## Preferred central control

SAP Job Scheduling Service / SAP Build Process Automation
        |
        | HTTPS POST
        v
Kyma Service (`app/main.py`)
        |
        +--> `/jobs/inbound` --> HDLF `/inbound` --> decrypt/decode --> target API --> cleanup
        |
        +--> `/jobs/outbound` --> HDLF `/outbound` --> ZIP/timestamp/GPG --> `/outbound/encrypted` --> cleanup
        |
        +--> Status Outbox --> OData/central status service and/or BPA callback

Kubernetes CronJobs are supplied only as fallback.

## Error semantics
- Source data is deleted only after the required downstream/upload step succeeds.
- A failed status callback is stored in the status outbox and can be retried.
- Each execution has a unique job ID and structured JSON logs.
- Parallel duplicate runs should be prevented at scheduler level. Fallback CronJobs use `concurrencyPolicy: Forbid`.

## Production note
The local status outbox should be mounted to a PersistentVolume or replaced by a database/event store in production. Secrets must be supplied through Kubernetes Secret/Secret Store and never committed to source control.
