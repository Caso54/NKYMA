"""Compatibility launcher for status-outbox retry."""
from app.logging_setup import configure_logging
from app.config import settings
from app.status_outbox import retry_pending

if __name__ == "__main__":
    configure_logging(settings.log_level)
    print({"delivered": retry_pending()})
