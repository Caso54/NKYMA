"""CLI launcher for outbound processing."""
from app.logging_setup import configure_logging
from app.config import settings
from app.outbound import run_outbound

if __name__ == "__main__":
    configure_logging(settings.log_level)
    result = run_outbound()
    print(result.model_dump_json(indent=2))
    raise SystemExit(0 if result.status.value == "SUCCESS" else 1)
