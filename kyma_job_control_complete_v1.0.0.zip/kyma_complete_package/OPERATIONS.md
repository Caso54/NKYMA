# Operations

## Health
`GET /health` must return `{"status":"UP"}`.

## Manual execution
- Inbound: `python App.Inbound.py`
- Outbound: `python App.Outbound.py`
- Retry status outbox: `python app.status_outbox.py`

## Central scheduler
Create HTTPS jobs that invoke:
- `POST https://<KYMA-ENDPOINT>/jobs/inbound`
- `POST https://<KYMA-ENDPOINT>/jobs/outbound`

Use OAuth2/mTLS/API gateway protection in production. The simple bearer check in the sample application is not a substitute for platform-level authentication.

## Restart behavior
A failed file remains in the source location because deletion occurs only after successful processing. The next run can therefore retry it. Status callback failures are written into the outbox and retried independently.

## Logging
Logs are JSON on stdout and should be collected by the Kyma logging/observability stack. Retention is managed outside the application.
