# v4.11 test report

Result: 55 tests passed; Python compile check passed.

Additional v4.11 checks:

- Phase 1 Settings load without DSP_SQL_HOST/DSP_SQL_USER/DSP_SQL_PASSWORD/DSP_SQL_SCHEMA.
- Phase 1 SetOrchestrator uses InMemoryDeliveryRepository and InMemoryProcessRepository.
- Phase 1 does not construct central OpenSQL status repository.
- Phase 1 simulated DataSphere POST task-chain start and GET task status through SUCCESS without SQL persistence.
- Phase 2 requires OpenSQL credentials when OPENSQL_PERSISTENCE_ENABLED=true.
- Phase 3 requires OpenSQL credentials when CENTRAL_OPENSQL_STATUS_ENABLED=true.
- Import smoke test succeeds without hdbcli installed when OpenSQL is disabled.
- Existing scheduling, manual ingest, FULL/DELTA, UTF-8, LF, AS300, archive and directory-resilience regression tests remain green.
