# v4.14 – Avaloq filename timestamp compatibility

## Change
Inbound filename recognition now accepts both compact timestamps and the actual Avaloq timestamp style with separators.

Examples accepted for every configured inbound file type:

- `AVQ_SAP_REL_KEY_ACP_20260925_160506.csv.gpg`
- `AVQ_SAP_REL_KEY_ACP_2026_09_25_16_05_06.csv.gpg`
- `AVQ_SAP_REL_KEY_ACP_20260925.csv.gpg`
- `AVQ_SAP_REL_KEY_ACP_2026_09_25.csv.gpg`

The real HDLF filename is not renamed. Normalization occurs only in memory for matching and extraction-date parsing.

All v4.13 HDLF upload/audit fixes remain unchanged.
