# v4.2 – Central status reporting / OData switch

## Implemented
- `CENTRAL_STATUS_REPORTING_ENABLED` feature switch.
- `CENTRAL_STATUS_ENDPOINT` target endpoint.
- Timeout and retry configuration (`STATUS_API_TIMEOUT`, `STATUS_API_RETRY_COUNT`, `STATUS_API_RETRY_DELAY`).
- Optional bearer-token or basic-auth environment variables (`STATUS_API_BEARER_TOKEN`, `STATUS_API_USER`, `STATUS_API_PASSWORD`).
- Every normal audit event is sent centrally only when the switch is enabled.
- Central reporting result is written to `FI_IT_M_TA_AUDIT_LOG` as `PROCESS_TYPE=CENTRAL_STATUS_API`.
- Disabled reporting is audited as `DISABLED` and makes no HTTP call.
- HTTP/connection errors are retried according to configuration.
- Central status reporting failures are non-fatal and do not change file/taskchain/set outcomes.
- Reporting events are not recursively reported.

## Important
The sender uses JSON `POST` to `CENTRAL_STATUS_ENDPOINT`. The final SAP OData entity/payload contract can be adjusted later without changing the feature-switch and non-fatal retry behavior.
