# v4.11 – OpenSQL completely switchable

## New configuration

`OPENSQL_PERSISTENCE_ENABLED`

- `false`: no OpenSQL detail persistence and no HANA connection for FILE/SET/PROCESS/AUDIT state. The sets process uses process-local in-memory state. HDLF audit remains active. DataSphere task-chain REST/OAuth remains active.
- `true`: FILE/SET/PROCESS/AUDIT tables are persisted through DataSphere OpenSQL.

`CENTRAL_OPENSQL_STATUS_ENABLED` remains independent and controls only the central steering table `FI_IT_M_TA_RUN_LOG_TC`.

## Phase model

1. Phase 1: `OPENSQL_PERSISTENCE_ENABLED=false`, `CENTRAL_OPENSQL_STATUS_ENABLED=false` – test HDLF/GPG/DataSphere REST without HANA SQL.
2. Phase 2: `OPENSQL_PERSISTENCE_ENABLED=true`, `CENTRAL_OPENSQL_STATUS_ENABLED=false` – add technical OpenSQL persistence.
3. Phase 3: both `true` – additionally write central steering status.

## Important limitation of Phase 1

The in-memory state exists only for the lifetime of the pod. Cross-pod restart/idempotency based on OpenSQL status tables is therefore intentionally unavailable until Phase 2.

## Technical changes

- SQL credentials are no longer mandatory when both OpenSQL switches are false.
- OpenSQL repository imports are lazy, so Phase 1 does not load `hdbcli` repository modules.
- HDLF audit remains mandatory in all phases.
- DataSphere task-chain REST API remains active in all phases.
