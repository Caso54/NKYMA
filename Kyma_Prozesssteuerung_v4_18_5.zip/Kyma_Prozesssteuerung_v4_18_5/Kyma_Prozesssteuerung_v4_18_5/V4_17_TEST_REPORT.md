# v4.17 Test Report

## Automated regression
- 80/80 tests passed after v4.17 tests were added.
- Python compile check: OK.

## Memory simulations
### UTF-8 validation
- Simulated file size: 2 GiB.
- Result: STREAM_UTF8_2G_OK.
- Maximum resident set size measured by `/usr/bin/time -v`: ~114 MiB (116648 KiB).
- The result demonstrates bounded-memory validation; it does not represent a Kyma production benchmark.

### CSV/Base64 transform
- 1,000,000 data rows, approximately 51 MB input.
- Result: successful row-wise transform.
- Maximum resident set size: ~90 MiB (92084 KiB).
- `2026-09-25` and `2026-09-25 16:05:06` remained unchanged; `SGVsbG8=` decoded to `Hello`.

## Outbound
- Mixed CRLF/LF source parts merged successfully.
- Final output contained LF only.
- Header written once; row count preserved.

## Static review
- No active `read_bytes()` / `write_bytes()` use remains on business-payload paths.
- Small configuration JSON files still use whole-file text reads intentionally.
- `common_hldf.py` remains a locally supplied integration module. v4.17 assumes its proven download/upload functions remain chunked as in the user's current implementation.
