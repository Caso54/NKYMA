# v4.3 changes

- Added configurable HDLF completion-prefix gate:
  - `INBOUND_DONE_PREFIX_ENABLED`
  - `INBOUND_DONE_PREFIX` (default `DONE_`)
- When enabled, only prefixed files are eligible for processing.
- The prefix is stripped before filename matching and before writing the decrypted output.
- Physical source access continues to use the original `DONE_*` filename.
- Monthly FULL and DELTA files may arrive in the same HDLF scan.
- Task-chain sequence is enforced: all paired FULL chains run first; paired DELTA chains run afterwards.
- A paired DELTA is deferred if its FULL partner is missing or failed.
