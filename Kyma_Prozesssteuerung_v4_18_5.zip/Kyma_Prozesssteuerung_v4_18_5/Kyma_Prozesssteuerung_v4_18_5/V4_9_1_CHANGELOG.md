# v4.9.1 Change

- AS300 outbound filename corrected to `SAP_AVQ_AS300_BOOKING_<UTC timestamp>.csv.gpg`.
- No change to source discovery, UTF-8 handling, GPG encryption, cleanup, directory recreation, audit, scheduling, or Task Chain logic.
- Full regression: 44 tests passed.
