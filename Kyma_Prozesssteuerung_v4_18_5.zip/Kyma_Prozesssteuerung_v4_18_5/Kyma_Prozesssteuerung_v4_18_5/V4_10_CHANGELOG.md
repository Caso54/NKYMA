# v4.10 Changelog

- AS300 Ursprungsstruktur wird vor dem Löschen nach `/outbound/archiv/DS_DL_EX_AS300/initial/` archiviert.
- Originale werden nur gelöscht, wenn die Archivierung des vollständigen Start-Snapshots erfolgreich war.
- Neu während des Laufs eintreffende Dateien bleiben unangetastet.
- Neuer Parameter `HDLF_OUTBOUND_ARCHIVE_PATH`, Default `/outbound/archiv`.
- Automatische Wiederanlage der benötigten HDLF-Verzeichnisse bleibt aktiv.
- Outbound-CronJob erhält HDLF-Zertifikat, GNUPG-Home und denselben sicheren Runtime-Rahmen wie Inbound.
- Beide CronJobs sind im gelieferten Manifest `suspend: true`.
- Container-Tag auf `process-control-v4-10` aktualisiert.
- Legacy `kyma-dev-secrets/PASSPHRASE` aus dem Inbound-Manifest entfernt.
- Vollständige Einrichtungs- und Parametrierungsanleitung ergänzt.


## AS300 output filename prefix

`AS300_OUTPUT_FILENAME_PREFIX` controls the filename prefix before the UTC timestamp. Default: `SAP_AVQ_AS300_BOOKING`. Example output: `SAP_AVQ_AS300_BOOKING_20260925_120000.csv.gpg`.
