# Test mode settings v4.10.1

Configured initial integration-test mode:

```yaml
BANK_HOLIDAY_CALENDAR_ENABLED: "false"
CENTRAL_OPENSQL_STATUS_ENABLED: "false"
SCHEDULE_ENFORCEMENT_ENABLED: "false"
MANUAL_INGEST_MODE: "false"
INBOUND_DONE_PREFIX_ENABLED: "false"
INBOUND_DONE_PREFIX: "DONE_"
ARCHIVE_UNSCHEDULED_FILES: "true"
ARCHIVE_UNKNOWN_FILES: "true"
AS300_OUTPUT_FILENAME_PREFIX: "SAP_AVQ_AS300_BOOKING"
```

Effects:
- No set/file schedule enforcement during the initial tests.
- No DONE_ prefix required. Only completed `.gpg` files are processed; `.part` files remain excluded.
- Bank holiday calendar disabled.
- Central OpenSQL process-control table disabled.
- DataSphere Task Chain REST/OAuth remains active.
- HDLF audit remains active.
- Known-file validation, GPG, UTF-8, Base64, retry/timeout and task-chain mapping remain active.
