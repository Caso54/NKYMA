# v4.8 – Manual / Emergency Ingest

## Added
- `SCHEDULE_ENFORCEMENT_ENABLED` (default `true`)
- `MANUAL_INGEST_MODE` (default `false`)
- `SCHEDULE_BYPASS / WARNING` audit event in the always-on HDLF audit
- Manual batches register only the known files actually present, avoiding unrelated MISSING rows
- Unknown files remain blocked/archived in manual mode
- DONE-prefix, GPG, UTF-8, Base64, retry/timeout and restart protections remain active
- FULL is sorted before DELTA when both are present in the same manual batch
- A DELTA supplied alone is allowed as an explicit manual emergency action

## Architecture retained
- DataSphere Task Chains: REST/OAuth
- Central process steering: optional OpenSQL via `CENTRAL_OPENSQL_STATUS_ENABLED`
- No duplicate OData/REST status channel
- HDLF audit under `/auditlog` is always active
- Bank holiday calendar remains optional and disabled by default
