# v4.2 Test Report

Result: **14 tests passed**

## Central status / OData scenarios
1. Reporting disabled: no HTTP request is sent; only the original local audit event remains.
2. Reporting enabled: JSON POST is sent to `CENTRAL_STATUS_ENDPOINT`.
3. Transient HTTP 503: retry is executed, subsequent 2xx succeeds.
4. Non-retriable HTTP 400: reporting returns FAILED without raising into the business process.
5. Timeout/connection failures: retry count is honored; terminal reporting failure stays non-fatal.
6. Central reporting result is stored in `FI_IT_M_TA_AUDIT_LOG` as `CENTRAL_STATUS_API`.
7. Successful low-level DSP polling (`DSP_STATUS_API/SUCCESS`) is not forwarded centrally, to avoid status flooding.
8. Set status changes are locally audited and centrally reportable via `PROCESS_TYPE=SET_STATUS`.
9. Reporting events are not recursively reported.

## Existing v4.1 scenarios retained
- DataSphere start retry + success.
- DataSphere status polling retry + success.
- DataSphere terminal FAILED -> process/file failure.
- Set states WAITING, BLOCKED, FAILED, WAITING_PREDECESSOR, WAITING_DEPENDENCY, COMPLETED.
- Daily DELTA + monthly FULL activation logic.

## Deployment configuration
Keep reporting disabled initially:

```yaml
CENTRAL_STATUS_REPORTING_ENABLED: "false"
CENTRAL_STATUS_ENDPOINT: ""
STATUS_API_TIMEOUT: "30"
STATUS_API_RETRY_COUNT: "3"
STATUS_API_RETRY_DELAY: "10"
```

Enable only after the target OData endpoint and its payload/authentication contract are ready.

## Important HDLF note
`common_hldf.py` is intentionally not reconstructed because the proven implementation was not contained in the v4.1 package available for this build. Before building the Docker image, copy your existing proven `app/common_hldf.py` into this package, as you already did for the current local v4.x image.
