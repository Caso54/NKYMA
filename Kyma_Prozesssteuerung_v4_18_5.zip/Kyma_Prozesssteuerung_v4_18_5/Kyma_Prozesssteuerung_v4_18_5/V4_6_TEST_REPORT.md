# v4.6 test report

Result: 35 tests passed.

Covered in addition to all previous regression tests:
- WEEKDAYS schedule
- MONTH_END schedule
- file schedule overrides set schedule
- bank holiday calendar disabled -> normal weekday rule
- bank holiday calendar enabled but empty -> normal weekday rule
- maintained bank holiday -> BANK_WORKDAY excludes the date
- NTH_BANK_WORKDAY_OF_MONTH
- known but unscheduled DONE_* file -> archive + FILE_NOT_SCHEDULED/WARNING
- unknown DONE_* file -> archive + UNKNOWN_FILE/WARNING
- file without DONE_ prefix -> untouched, not archived

Existing regression coverage remains for:
- FULL before DELTA task-chain sequence
- DONE-prefix handling
- UTF-8 without BOM
- Base64 decoding
- DataSphere API retry/status
- OData central status ON/OFF and best-effort behavior
- file/set/process/audit status transitions
- late delivery/restart behavior
