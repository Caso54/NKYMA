# v4.15

- Added visible DataSphere task-chain polling heartbeat in pod logs for each poll: taskChain, logId, poll number, status, elapsed seconds, remaining timeout seconds.
- Added explicit protection for source CSV date values `YYYY-MM-DD` and timestamp values `YYYY-MM-DD HH:MM:SS`: they are never Base64-decoded or normalized.
- No changes to source date/timestamp field values are performed by the inbound pipeline.
- Existing filename timestamp normalization remains limited to filename matching only; file contents are not changed by that normalization.
