# v4.7 - Central OpenSQL status switch

Added `CENTRAL_OPENSQL_STATUS_ENABLED` as an independent switch for writes to the existing central steering table `FI_IT_M_TA_RUN_LOG_TC`.

Recommended initial test mode:

- DataSphere Task Chain REST API: active
- detailed OpenSQL FILE/SET/PROCESS/AUDIT tables: active
- central OpenSQL steering table: disabled
- central OData/REST reporting: disabled
- bank-holiday calendar: disabled

Central steering-table writes are best-effort: failures are logged but do not stop the underlying file or Task Chain process.
