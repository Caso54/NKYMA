# v4.18.1 Changelog

## Fixes

- Added `common_hldf.delete_file()` using WebHDFS `DELETE ...?op=DELETE&recursive=false`.
- DELETE treats HTTP 404 as idempotent success for safe retry semantics.
- Safe lifecycle remains `copy -> verify size/SHA-256 -> delete`; no rename fallback added.
- `DSP_SQL_PORT` is no longer parsed or validated while both OpenSQL features are disabled.
- Updated Kubernetes image tag to `process-control-v4-18-1`.

## OpenSQL off behavior

When `OPENSQL_PERSISTENCE_ENABLED=false` and `CENTRAL_OPENSQL_STATUS_ENABLED=false`, `DSP_SQL_HOST`, `DSP_SQL_PORT`, `DSP_SQL_USER`, `DSP_SQL_PASSWORD`, and `DSP_SQL_SCHEMA` are not required for startup.
