# Installation – v4.11 Phase 1 test mode

Recommended initial switches:

```yaml
OPENSQL_PERSISTENCE_ENABLED: "false"
CENTRAL_OPENSQL_STATUS_ENABLED: "false"
BANK_HOLIDAY_CALENDAR_ENABLED: "false"
SCHEDULE_ENFORCEMENT_ENABLED: "false"
MANUAL_INGEST_MODE: "false"
INBOUND_DONE_PREFIX_ENABLED: "false"
```

This Phase 1 configuration performs no HANA/OpenSQL connection. It keeps HDLF audit active and uses DataSphere REST/OAuth for task-chain execution and monitoring.

## Build

Ensure `app/common_hldf.py` is present, then:

```powershell
docker build --no-cache `
  -t ghcr.io/caso54/kyma-dev:process-control-v4-11 .

docker push ghcr.io/caso54/kyma-dev:process-control-v4-11
```

## Deploy configuration and CronJobs

```powershell
kubectl apply -f .\k8s\configmap.yaml
kubectl apply -f .\k8s\cronjob-inbound.yaml
kubectl apply -f .\k8s\cronjob-outbound.yaml
```

Keep both CronJobs suspended for manual testing.

## Phase 1

```yaml
OPENSQL_PERSISTENCE_ENABLED: "false"
CENTRAL_OPENSQL_STATUS_ENABLED: "false"
```

No OpenSQL credentials are needed by the application at runtime in this phase. Existing `datasphere-sql-secret` may remain mounted; it is not used for a connection.

## Phase 2

```yaml
OPENSQL_PERSISTENCE_ENABLED: "true"
CENTRAL_OPENSQL_STATUS_ENABLED: "false"
```

Configure `DSP_SQL_HOST`, `DSP_SQL_PORT`, `DSP_SQL_SCHEMA` and secret keys `DSP_SQL_USER`, `DSP_SQL_PASSWORD`. Technical FILE/SET/PROCESS/AUDIT tables are persisted.

## Phase 3

```yaml
OPENSQL_PERSISTENCE_ENABLED: "true"
CENTRAL_OPENSQL_STATUS_ENABLED: "true"
```

Additionally writes the central steering table `FI_IT_M_TA_RUN_LOG_TC`.
