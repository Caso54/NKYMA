# v4.18.1 Test Report

## Regression

- Existing project regression suite: **87/87 passed**.

## Targeted fixes

- `common_hldf.delete_file()` compiles and calls WebHDFS `DELETE ...?op=DELETE&recursive=false`.
- HTTP 200: accepted as successful deletion.
- HTTP 404: accepted as idempotent success for retry safety.
- Unexpected DELETE status: raises `RuntimeError`; source cleanup is not silently ignored.
- With `OPENSQL_PERSISTENCE_ENABLED=false` and `CENTRAL_OPENSQL_STATUS_ENABLED=false`, `DSP_SQL_PORT=REPLACE_SQL_PORT` no longer blocks startup; SQL settings are not required.
- When OpenSQL is enabled, an invalid SQL port still fails fast.

## Safety property retained

Archive lifecycle remains `copy -> verify size/SHA-256 -> delete`. No rename-only or delete-without-verification fallback was introduced.
