# v4.18.5 Changelog

## Fixed DataSphere decrypted filenames

Files uploaded to `/inbound/decrypted` now use a stable DataSphere-facing name.
Everything from the first `_ACP` marker onward is removed from the decrypted target filename.

Examples:

- `AVQ_SAP_NAME_INTL_ACP_2026_09_25_08_16_55.csv.gpg` -> `AVQ_SAP_NAME_INTL.csv`
- `AVQ_SAP_CLASS2_DELTA_ACP_2026_09_25_16_06_06.csv.gpg` -> `AVQ_SAP_CLASS2_DELTA.csv`
- `AVQ_SAP_BAL_DELTA_ACP_V01A_2026_09_26_04_37_46.csv.gpg` -> `AVQ_SAP_BAL_DELTA.csv`
- `AVQ_SAP_POS_BOOK_NNM_ACP_V01A_2026_09_26_02_48_01.csv.gpg` -> `AVQ_SAP_POS_BOOK_NNM.csv`

The original inbound filename remains unchanged for recognition, set logic, FULL/DELTA dependencies, audit correlation and source archiving.

The naming rule is centralized in `app/filename_utils.py` and is used by both `SetOrchestrator` and the alternative `InboundProcessor`.

Kubernetes image tag: `ghcr.io/caso54/kyma-dev:process-control-v4-18-5`.
