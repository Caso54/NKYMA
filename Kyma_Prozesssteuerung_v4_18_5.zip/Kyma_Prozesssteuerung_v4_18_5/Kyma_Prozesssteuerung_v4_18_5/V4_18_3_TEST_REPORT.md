# v4.18.3 Test Report

## Scope
Fix FULL -> DELTA sequencing when `DATASPHERE_TASKCHAIN_API_ENABLED=false` without redefining `DECRYPTED_ONLY` as a global completion state.

## Results
- Full regression suite: **93/93 passed**.
- Targeted v4.18/v4.18.2/v4.18.3 tests: **13/13 passed**.
- Python compileall: passed.
- JSON configuration validation: passed.
- Kubernetes YAML parsing: passed.
- Image tags verified: `ghcr.io/caso54/kyma-dev:process-control-v4-18-3`.

## FULL -> DELTA simulation
Simulation date: 2026-09-27.

- Taskchain API disabled + FULL status `DECRYPTED_ONLY` -> DELTA released: **PASS**.
- Taskchain API enabled + FULL status `DECRYPTED_ONLY` -> DELTA remains blocked: **PASS**.
- FULL status `COMPLETED` -> DELTA released in both modes: **PASS**.
- FULL status `FAILED` -> DELTA blocked in both modes: **PASS**.

This preserves the semantic difference between `DECRYPTED_ONLY` and a genuinely loaded/completed DataSphere process.

## Large-file streaming check
Existing 2 GiB validation payload was processed using incremental UTF-8 validation.

- Result: **PASS**
- Elapsed: ~5.0 s in the local container test environment
- Max RSS: ~114 MiB (`116648 KiB`)

This is a bounded-memory regression check, not a production throughput benchmark.
