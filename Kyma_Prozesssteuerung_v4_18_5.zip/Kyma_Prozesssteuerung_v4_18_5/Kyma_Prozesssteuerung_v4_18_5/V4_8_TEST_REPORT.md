# v4.8 Test Report

Result: **40 passed**

Additional manual-ingest coverage:
1. Normal mode archives a known but unscheduled file and writes WARNING.
2. Manual mode processes a known unscheduled file.
3. Manual mode writes `SCHEDULE_BYPASS / WARNING` to HDLF audit.
4. Global schedule-enforcement bypass is supported and explicitly audited.
5. Unknown files remain blocked/archived in manual mode.
6. DONE-prefix gate remains active in manual mode.
7. Manual DELTA alone is allowed.
8. FULL and DELTA in the same manual batch are ordered FULL then DELTA.
9. Full regression: DONE, UTF-8, Base64, schedules, bank calendar, archive rules, Task Chain API, central OpenSQL toggle and HDLF audit.
10. `python -m compileall` completed successfully.
