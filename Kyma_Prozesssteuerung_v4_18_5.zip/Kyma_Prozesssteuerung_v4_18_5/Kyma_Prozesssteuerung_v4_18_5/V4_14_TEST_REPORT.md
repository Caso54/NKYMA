# v4.14 Test Report

## Scope
Central inbound filename normalization for Avaloq timestamp variants, while retaining all v4.13 HDLF upload/audit fixes and the current Phase-1 configuration.

## Supported filename examples
- `AVQ_SAP_REL_KEY_ACP_20260925_160506.csv.gpg`
- `AVQ_SAP_REL_KEY_ACP_2026_09_25_16_05_06.csv.gpg`
- `AVQ_SAP_REL_KEY_ACP_20260925.csv.gpg`
- `AVQ_SAP_REL_KEY_ACP_2026_09_25.csv.gpg`

## Verification
- Python compile check: PASS
- Full pytest regression: 68/68 PASS
- All configured inbound file types simulated with `YYYY_MM_DD_HH_MM_SS`: 42/42 PASS
- Exact reported filename `AVQ_SAP_REL_KEY_ACP_2026_09_25_16_05_06.csv.gpg`: PASS
- Extracted date from exact filename: 2026-09-25
- Original HDLF filename is not renamed; normalization is matching-only.
- Current ConfigMap retained.
- CronJob application image tag updated to `process-control-v4-14`.
