# v4.18.5 Test Report

## Result

PASS

## Verification performed

- Python compile check: PASS
- Full regression suite: 102/102 PASS
- v4.18.5 filename tests: 6/6 PASS
- Actual SetOrchestrator upload-path test: PASS
- Simulation against 40 unique regular inbound filenames from the latest runtime log: 40/40 mapped successfully
- DataSphere target names still containing `_ACP`: 0
- Unique target names in that simulation: 40/40
- JSON configuration validation: PASS
- Kubernetes YAML validation: PASS
- Inbound and outbound image tags: `process-control-v4-18-5`

## Required example

`AVQ_SAP_NAME_INTL_ACP_2026_09_25_08_16_55.csv.gpg`
becomes
`/inbound/decrypted/AVQ_SAP_NAME_INTL.csv`.

## Regression scope

Existing functionality remains covered, including Base64 AUTO_STRICT, UTF-8 validation, archive lifecycle, extraction-date toggle, FULL-before-DELTA behavior with taskchain API disabled, inbound aliases and duplicate-file handling.
