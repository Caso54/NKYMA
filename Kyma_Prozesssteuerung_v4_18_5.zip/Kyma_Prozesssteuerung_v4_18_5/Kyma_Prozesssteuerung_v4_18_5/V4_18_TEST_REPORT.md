# v4.18 Test Report

## Regression
- 87/87 automatisierte Tests bestanden.
- `python -m compileall app`: erfolgreich.

## Base64 / CSV
- `AUTO_STRICT` ohne Base64: Originaldatei wird als Upload-Quelle weiterverwendet; keine zweite CSV wird erzeugt.
- Automatisch erkannte Base64-Spalte: nur diese Spalte wird decodiert.
- Feld-Fallback: konfigurierte Header-Spalten werden gezielt als Decode-Kandidaten behandelt.
- Datum `YYYY-MM-DD` und Timestamp `YYYY-MM-DD HH:MM:SS` bleiben unverändert.
- Legacy-Modus bleibt über `ALL/LEGACY` verfügbar.

## 2-GB-Streaming-Simulation
- Testdatei: exakt 2 GiB (Sparse-Testdatei mit gültigem UTF-8-Inhalt).
- Streaming-UTF-8-Prüfung: erfolgreich (`STREAM_UTF8_2GB_OK`).
- Gemessener Max-RSS: ca. 114 MiB (`116636 KiB`).
- AUTO_STRICT-Analyse auf der 2-GiB-Datei, begrenzt auf 10.000 Datenzeilen: erfolgreich.
- AUTO_STRICT Max-RSS: ca. 90 MiB (`92332 KiB`).
- Ergebnis: `rewrite_required=False`, d. h. keine unnötige CSV-Neuschreibung.
- Hinweis: Sparse-Datei und Container-I/O sind kein produktiver Durchsatzbenchmark. Die Messung belegt bounded-memory/Streaming-Verhalten, nicht eine garantierte 15–20-GB/Tag-Laufzeit.

## Lifecycle / Archive / Move
- `KEEP`: keine Remote-Dateioperation.
- `DELETE`: Quelle wird gezielt gelöscht.
- `ARCHIVE`: Quelle herunterladen -> SHA-256 + Größe -> Archiv hochladen -> Archiv frisch herunterladen -> SHA-256 + Größe vergleichen -> erst dann Quelle löschen.
- Simulierter Archiv-Korruptionsfall: Verify schlägt fehl, Quelle bleibt erhalten.
- Outbound-Snapshot-Test: nach Snapshot neu eintreffende Datei bleibt unberührt.
- Archivierungsfehler: erzeugtes verschlüsseltes Outbound-Ziel bleibt bestehen, Originalquelle wird nicht gelöscht.

## Statische Prüfung
- Keine aktiven `read_bytes()`/`write_bytes()`-Vollzugriffe auf Business-Payloads im Anwendungscode eingeführt.
- Große Dateien werden über Iteratoren/Chunks verarbeitet.
- `common_hldf.py` ist weiterhin die kundenspezifische HDLF-Integrationskomponente und wird wie in v4.17 nicht mitgeliefert.
