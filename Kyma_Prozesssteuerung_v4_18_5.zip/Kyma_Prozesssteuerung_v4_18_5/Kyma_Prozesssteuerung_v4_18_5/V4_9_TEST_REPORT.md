# v4.9 Test Report

## Result
- 44 tests passed
- Python compile check passed

## Outbound AS-300 simulations
1. Exact source path `/outbound/DS_DL_EX_AS300/initial/part-*.csv` is used.
2. Output filename is `SAP_AVQ_AS300_BOOKING_<UTC timestamp>.csv.gpg`.
3. ZIP packaging is not used.
4. UTF-8 content with umlauts is accepted and the generated CSV is UTF-8 without BOM.
5. Multiple part files are merged in lexical order with one header.
6. Source files are deleted only after successful encrypted upload and target existence check.
7. A new file that arrives after the initial source snapshot is not deleted by the running job.
8. Cleanup failure is logged as warning; the successfully generated encrypted target is retained.
9. Required HDLF directories are re-created before and after outbound processing.
10. HDLF audit directory is re-created before audit writes when the storage adapter supports `mkdirs`.

## Regression
Existing inbound, set scheduling, bank calendar, DONE prefix, manual ingest, FULL-before-DELTA, UTF-8, Base64, DataSphere REST/API, OpenSQL switch and HDLF audit tests remain successful.

## Deployment dependency
`app/common_hldf.py` is intentionally not embedded. For outbound source cleanup it must expose a delete primitive under one of these compatible names:
- `delete_file(path)`
- `delete(path)`
- `remove_file(path)`
- `remove(path)`

The adapter fails explicitly if no delete primitive exists, rather than silently leaving source files behind.
