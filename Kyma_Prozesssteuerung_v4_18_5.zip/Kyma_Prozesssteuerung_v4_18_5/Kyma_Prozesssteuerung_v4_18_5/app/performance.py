from __future__ import annotations

import logging
import os
from pathlib import Path


def rss_mib() -> float | None:
    """Return current resident set size in MiB on Linux, if available."""
    try:
        with open("/proc/self/status", "r", encoding="ascii") as fh:
            for line in fh:
                if line.startswith("VmRSS:"):
                    return int(line.split()[1]) / 1024.0
    except Exception:
        return None
    return None


def file_mib(path: str | os.PathLike[str]) -> float | None:
    try:
        return Path(path).stat().st_size / (1024.0 * 1024.0)
    except OSError:
        return None


def log_stage(logger: logging.Logger, stage: str, *, path: str | None = None, rows: int | None = None, extra: str | None = None) -> None:
    rss = rss_mib()
    size = file_mib(path) if path else None
    parts = [f"stage={stage}"]
    if path:
        parts.append(f"file={Path(path).name}")
    if size is not None:
        parts.append(f"sizeMiB={size:.1f}")
    if rows is not None:
        parts.append(f"rows={rows}")
    if rss is not None:
        parts.append(f"rssMiB={rss:.1f}")
    if extra:
        parts.append(extra)
    logger.info("PERF %s", " ".join(parts))
