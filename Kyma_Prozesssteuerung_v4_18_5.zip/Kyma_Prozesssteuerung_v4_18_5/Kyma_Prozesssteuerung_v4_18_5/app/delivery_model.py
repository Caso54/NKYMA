from __future__ import annotations
import calendar
import json
import re
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from .utf8_utils import read_utf8_text
from zoneinfo import ZoneInfo

DAY_NAMES = {"MON":0,"TUE":1,"WED":2,"THU":3,"FRI":4,"SAT":5,"SUN":6}


def normalize_inbound_filename_for_matching(filename: str) -> str:
    """Normalize only a trailing Avaloq timestamp for configured filename matching.

    Supported source forms include both compact timestamps
    (YYYYMMDD_HHMMSS) and separated timestamps
    (YYYY_MM_DD_HH_MM_SS). The actual HDLF filename is never changed.
    """
    pattern = re.compile(
        r"(?P<prefix>.*?)(?P<date>\d{4}[_-]\d{2}[_-]\d{2})"
        r"(?:[_-](?P<time>\d{2}[_-]\d{2}[_-]\d{2}))?"
        r"(?P<suffix>(?:\.csv)?(?:\.gpg)?)$",
        re.IGNORECASE,
    )
    match = pattern.match(filename)
    if not match:
        return filename
    compact_date = re.sub(r"[_-]", "", match.group("date"))
    raw_time = match.group("time")
    compact_time = re.sub(r"[_-]", "", raw_time) if raw_time else None
    timestamp = compact_date + ("_" + compact_time if compact_time else "")
    return f"{match.group('prefix')}{timestamp}{match.group('suffix')}"


def _month_end(d: date) -> bool:
    return d.day == calendar.monthrange(d.year, d.month)[1]


@dataclass(frozen=True)
class ExpectedFile:
    file_id: str
    role: str
    pattern: str
    required_mode: str
    active_when: str
    required: bool
    task_chain_id: str | None
    task_chain_endpoint: str | None
    dsp_dataflow: str | None
    pair_id: str | None
    schedule: dict | None = None

    def parse(self, filename: str, default_extraction_date: date | None = None):
        match_name = normalize_inbound_filename_for_matching(filename)
        m = re.search(self.pattern, match_name, re.IGNORECASE)
        if not m:
            return None
        gd = m.groupdict()
        raw = gd.get("extract_date")
        extraction_date = default_extraction_date
        if raw:
            extraction_date = datetime.strptime(raw, "%Y%m%d").date()
        if extraction_date is None:
            raise RuntimeError(f"Pattern for {self.file_id} did not provide extract_date and no default date was supplied")
        return {"extraction_date": extraction_date, "mode": (gd.get("mode") or self.required_mode).upper()}


@dataclass(frozen=True)
class SetDefinition:
    set_id: str
    space_id: str
    task_chain_strategy: str
    depends_on_sets: tuple[str, ...]
    required_files: tuple[ExpectedFile, ...]
    optional_files: tuple[ExpectedFile, ...]
    schedule: dict | None = None


@dataclass(frozen=True)
class DeliveryModel:
    timezone: str
    monthly_full_rule: str
    sets: tuple[SetDefinition, ...]
    allowed_extraction_offsets: tuple[int, ...]
    bank_holiday_calendar_enabled: bool = False
    bank_holidays: frozenset[date] = frozenset()

    @classmethod
    def load(cls, path: str, *, bank_holiday_calendar_enabled: bool = False, bank_holiday_calendar_file: str | None = None):
        raw = json.loads(read_utf8_text(path, allow_bom=True))
        rules = raw.get("rules", {})
        monthly_rule = rules.get("monthly_full_rule") or raw.get("monthly_full_rule", {})
        if isinstance(monthly_rule, dict):
            monthly_rule = monthly_rule.get("type", "FIRST_CALENDAR_DAY_OF_NEXT_MONTH")

        holidays = set()
        if bank_holiday_calendar_enabled and bank_holiday_calendar_file:
            try:
                raw_calendar = read_utf8_text(bank_holiday_calendar_file, allow_bom=True).strip()
                cal = json.loads(raw_calendar) if raw_calendar else {"holidays": []}
                for value in cal.get("holidays", []):
                    holidays.add(date.fromisoformat(str(value)))
            except FileNotFoundError:
                holidays = set()

        def make_file(f: dict, required_default: bool) -> ExpectedFile:
            mode = (f.get("fixed_mode") or f.get("required_mode") or "DELTA").upper()
            return ExpectedFile(
                file_id=f["file_id"], role=f.get("role", "NORMAL"), pattern=f["pattern"],
                required_mode=mode, active_when=f.get("active_when", "ALWAYS").upper(),
                required=bool(f.get("required", required_default)), task_chain_id=f.get("task_chain_id"),
                task_chain_endpoint=f.get("task_chain_endpoint"), dsp_dataflow=f.get("dsp_dataflow"),
                pair_id=f.get("pair_id"), schedule=f.get("schedule"),
            )

        sets = []
        for item in raw["sets"]:
            if not item.get("enabled", True):
                continue
            sets.append(SetDefinition(
                set_id=item["set_id"], space_id=item.get("space_id") or raw.get("space_id") or "DS_DL",
                task_chain_strategy=item.get("task_chain_strategy", "PER_FILE").upper(),
                depends_on_sets=tuple(item.get("depends_on_sets", [])),
                required_files=tuple(make_file(f, True) for f in item.get("required_files", [])),
                optional_files=tuple(make_file(f, False) for f in item.get("optional_files", [])),
                schedule=item.get("schedule"),
            ))
        offsets = tuple(int(x) for x in rules.get("allowed_extraction_date_offset_days", [0, -1]))
        return cls(raw.get("timezone", "Europe/Zurich"), str(monthly_rule or "FIRST_CALENDAR_DAY_OF_NEXT_MONTH"),
                   tuple(sets), offsets, bank_holiday_calendar_enabled, frozenset(holidays))

    def today(self) -> date:
        return datetime.now(ZoneInfo(self.timezone)).date()

    def is_monthly_full_day(self, set_date: date) -> bool:
        return self.monthly_full_rule == "FIRST_CALENDAR_DAY_OF_NEXT_MONTH" and set_date.day == 1

    def _legacy_active(self, f: ExpectedFile, set_date: date) -> bool:
        if f.active_when == "ALWAYS": return True
        if f.active_when in {"MONTHLY_FULL", "MONTHLY"}: return self.is_monthly_full_day(set_date)
        return False

    def _is_bank_holiday(self, d: date) -> bool:
        return self.bank_holiday_calendar_enabled and bool(self.bank_holidays) and d in self.bank_holidays

    def _bank_workday(self, d: date) -> bool:
        return d.weekday() < 5 and not self._is_bank_holiday(d)

    def _nth_bank_workday(self, d: date, n: int) -> bool:
        if n < 1 or not self._bank_workday(d): return False
        count = 0
        for day in range(1, d.day + 1):
            x = date(d.year, d.month, day)
            if self._bank_workday(x): count += 1
        return count == n

    def schedule_matches(self, schedule: dict | None, d: date) -> bool:
        if not schedule:
            return True
        typ = str(schedule.get("type", "DAILY")).upper()
        if typ == "DAILY": ok = True
        elif typ == "WEEKDAYS": ok = d.weekday() < 5
        elif typ == "DAYS_OF_WEEK":
            days = {DAY_NAMES[x.upper()] for x in schedule.get("days", []) if str(x).upper() in DAY_NAMES}
            ok = d.weekday() in days
        elif typ == "MONTH_END": ok = _month_end(d)
        elif typ in {"MONTH_END_PLUS_1", "FIRST_DAY_OF_MONTH"}: ok = d.day == 1
        elif typ == "NTH_DAY_OF_MONTH": ok = d.day == int(schedule.get("day", 1))
        elif typ == "DAILY_EXCEPT_MONTH_END": ok = not _month_end(d)
        elif typ == "BANK_WORKDAY": ok = self._bank_workday(d)
        elif typ == "NTH_BANK_WORKDAY_OF_MONTH": ok = self._nth_bank_workday(d, int(schedule.get("n", 1)))
        elif typ == "MANUAL": ok = False
        else: raise ValueError(f"Unknown schedule type: {typ}")
        if ok and bool(schedule.get("exclude_bank_holidays", False)) and self._is_bank_holiday(d):
            ok = False
        return ok

    def file_active(self, set_def: SetDefinition, f: ExpectedFile, set_date: date) -> bool:
        # File schedule overrides set schedule. If neither exists, preserve legacy active_when behavior.
        if f.schedule is not None:
            return self.schedule_matches(f.schedule, set_date)
        if set_def.schedule is not None:
            return self.schedule_matches(set_def.schedule, set_date)
        return self._legacy_active(f, set_date)

    def active_required_files(self, set_def: SetDefinition, set_date: date) -> tuple[ExpectedFile, ...]:
        return tuple(f for f in set_def.required_files if self.file_active(set_def, f, set_date))

    def active_optional_files(self, set_def: SetDefinition, set_date: date) -> tuple[ExpectedFile, ...]:
        return tuple(f for f in set_def.optional_files if self.file_active(set_def, f, set_date))

    def all_active_files(self, set_def: SetDefinition, set_date: date) -> tuple[ExpectedFile, ...]:
        return self.active_required_files(set_def, set_date) + self.active_optional_files(set_def, set_date)

    def extraction_date_valid(self, extraction_date: date, reference_date: date) -> bool:
        return any(extraction_date == reference_date + timedelta(days=o) for o in self.allowed_extraction_offsets)
