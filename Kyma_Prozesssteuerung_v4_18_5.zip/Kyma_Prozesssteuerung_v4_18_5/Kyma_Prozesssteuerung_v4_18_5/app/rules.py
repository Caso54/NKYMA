\
from __future__ import annotations
import re
from dataclasses import dataclass
from typing import Any

@dataclass(frozen=True)
class ProcessRule:
    file_pattern: str
    space_id: str
    task_chain_id: str
    tc_group_id: str
    object_nr: str
    object_type: str = "TASK_CHAIN"
    decode_base64: bool = False
    base64_mode: str | None = None
    base64_fallback_fields: tuple[str, ...] = ()
    input_parameters: dict[str, Any] | None = None

    @classmethod
    def from_dict(cls, d):
        return cls(
            file_pattern=d["file_pattern"],
            space_id=d["space_id"],
            task_chain_id=d["task_chain_id"],
            tc_group_id=str(d.get("tc_group_id", "001")),
            object_nr=str(d.get("object_nr", "001")),
            object_type=d.get("object_type", "TASK_CHAIN"),
            decode_base64=bool(d.get("decode_base64", False)),
            base64_mode=(str(d.get("base64_mode")).strip().upper() if d.get("base64_mode") is not None else None),
            base64_fallback_fields=tuple(str(x) for x in d.get("base64_fallback_fields", []) if str(x).strip()),
            input_parameters=d.get("input_parameters"),
        )

    def matches(self, filename: str) -> bool:
        return re.search(self.file_pattern, filename, re.IGNORECASE) is not None
