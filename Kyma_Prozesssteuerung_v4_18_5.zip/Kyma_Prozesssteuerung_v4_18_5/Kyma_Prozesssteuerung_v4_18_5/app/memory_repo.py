from __future__ import annotations
from datetime import datetime, timezone
import uuid


def now_utc():
    return datetime.now(timezone.utc)


class InMemoryDeliveryRepository:
    """Process-local replacement for OpenSQL delivery state.

    Used only when OPENSQL_PERSISTENCE_ENABLED=false. It preserves orchestration
    semantics for the current pod/run but deliberately provides no restart
    persistence across pods.
    """
    def __init__(self):
        self.sets = {}
        self.files = {}

    def ensure_set(self, set_id, set_date, predecessor, expected_files):
        self.sets.setdefault((set_id, set_date), {
            "status": "WAITING", "predecessor": predecessor, "expected": expected_files,
            "received": 0, "success": 0, "missing": expected_files, "failed": 0,
            "message": "Set initialized", "start": now_utc(), "end": None,
        })

    def ensure_expected_file(self, set_id, set_date, file_id, file_role, file_mode):
        self.files.setdefault((set_id, set_date, file_id), {
            "status": "MISSING", "role": file_role, "mode": file_mode, "run_uuid": None,
        })

    def upsert_file(self, **k):
        self.files[(k["set_id"], k["set_date"], k["file_id"])] = {
            "status": k["file_status"], "role": k["file_role"], "mode": k["file_mode"],
            "run_uuid": k["run_uuid"], "file_name": k["file_name"],
            "delivery_date": k["delivery_date"], "extraction_date": k["extraction_date"],
        }

    def update_file_status(self, *, set_id, set_date, file_id, run_uuid, status,
                           dsp_log_id=None, error_message=None, end=False):
        rec = self.files.setdefault((set_id, set_date, file_id), {"run_uuid": run_uuid})
        rec.update(status=status, run_uuid=run_uuid)
        if dsp_log_id is not None: rec["dsp_log_id"] = dsp_log_id
        if error_message is not None: rec["error_message"] = str(error_message)
        if end: rec["end"] = now_utc()

    def file_success_exists(self, set_id, set_date, file_id):
        rec = self.files.get((set_id, set_date, file_id))
        return bool(rec and str(rec.get("status", "")).upper() in {"LOADED", "COMPLETED"})

    def file_status(self, set_id, set_date, file_id):
        rec = self.files.get((set_id, set_date, file_id))
        return str(rec.get("status", "")).upper() if rec else None

    def oldest_open_missing_set(self, set_id, file_id):
        dates = []
        for (sid, sdate), rec in self.sets.items():
            if sid != set_id or str(rec.get("status", "")).upper() not in {
                "WAITING", "PARTIAL", "BLOCKED", "WAITING_PREDECESSOR", "FAILED"
            }:
                continue
            if not self.file_success_exists(set_id, sdate, file_id):
                dates.append(sdate)
        return min(dates) if dates else None

    def predecessor_completed(self, set_id, set_date):
        earlier = [(d, rec) for (sid, d), rec in self.sets.items()
                   if sid == set_id and d < set_date and int(rec.get("expected", 0)) > 0]
        if not earlier:
            return True
        _, rec = max(earlier, key=lambda x: x[0])
        return str(rec.get("status", "")).upper() == "COMPLETED"

    def summarize_set(self, set_id, set_date, ids):
        statuses = {}
        for fid in ids:
            rec = self.files.get((set_id, set_date, fid))
            if rec:
                statuses[fid] = str(rec.get("status", "MISSING")).upper()
        received = sum(1 for fid in ids if statuses.get(fid, "MISSING") != "MISSING")
        success = sum(1 for fid in ids if statuses.get(fid) == "COMPLETED")
        failed = sum(1 for fid in ids if statuses.get(fid) == "FAILED")
        return {"expected": len(ids), "received": received, "success": success,
                "missing": len(ids) - success, "failed": failed}

    def set_status(self, set_id, set_date):
        rec = self.sets.get((set_id, set_date))
        return str(rec.get("status", "")).upper() if rec else None

    def dependencies_completed(self, dependency_ids, set_date):
        return all(self.set_status(dep, set_date) == "COMPLETED" for dep in dependency_ids)

    def update_set(self, set_id, set_date, status, summary, message="", end=False):
        rec = self.sets.setdefault((set_id, set_date), {})
        rec.update(status=status, expected=summary["expected"], received=summary["received"],
                   success=summary["success"], missing=summary["missing"], failed=summary["failed"],
                   message=message)
        if end: rec["end"] = now_utc()


class InMemoryProcessRepository:
    def __init__(self):
        self.processes = {}

    def create(self, *, run_uuid, set_id, set_date, file_id, task_chain_id):
        pid = str(uuid.uuid4())
        self.processes[pid] = {
            "run_uuid": run_uuid, "set_id": set_id, "set_date": set_date,
            "file_id": file_id, "task_chain_id": task_chain_id, "status": "CREATED",
            "start": now_utc(),
        }
        return pid

    def update(self, process_uuid, *, status, dsp_log_id=None, http_status=None,
               retry_count=None, error_code=None, error_message=None, end=False):
        rec = self.processes.setdefault(process_uuid, {})
        rec["status"] = status
        rec["last"] = now_utc()
        if dsp_log_id is not None: rec["dsp_log_id"] = dsp_log_id
        if http_status is not None: rec["http_status"] = http_status
        if retry_count is not None: rec["retry_count"] = retry_count
        if error_code is not None: rec["error_code"] = str(error_code)
        if error_message is not None: rec["error_message"] = str(error_message)
        if end: rec["end"] = now_utc()
