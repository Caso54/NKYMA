\
from __future__ import annotations
import logging
import os
import tempfile
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from .config import Settings, load_process_rules
from .crypto_gpg import decrypt_symmetric
from .csv_transform import prepare_csv_payload
from .datasphere import DataSphereClient, DataSphereHTTPError
from .hldf_audit import HldfAuditLogger
from .retry import retry_call
from .rules import ProcessRule
from .storage import HldfStorage
from .utf8_utils import validate_utf8_file
from .performance import log_stage
from .file_lifecycle import apply_remote_lifecycle, normalize_lifecycle
from .filename_utils import build_decrypted_filename

LOG = logging.getLogger("kyma.inbound")

class InboundProcessor:
    def __init__(self, cfg: Settings):
        self.cfg = cfg
        self.storage = HldfStorage()
        if cfg.central_opensql_status_enabled:
            from .status_repo import StatusRepository
            self.repo = StatusRepository(
                cfg.sql_host, cfg.sql_port, cfg.sql_user, cfg.sql_password,
                cfg.sql_schema, cfg.sql_status_table
            )
        else:
            self.repo = None
        self.hldf_audit = HldfAuditLogger(self.storage, cfg.audit_log_path, "INBOUND")
        self.dsp = (
            DataSphereClient(cfg.dsp_host, cfg.dsp_token_url, cfg.dsp_client_id, cfg.dsp_client_secret)
            if cfg.datasphere_taskchain_api_enabled else None
        )
        self.rules = [ProcessRule.from_dict(x) for x in load_process_rules(cfg.process_rules_file)]

    @staticmethod
    def _filename(item):
        if isinstance(item, str):
            return item.rsplit("/", 1)[-1]
        if isinstance(item, dict):
            return str(item.get("name") or item.get("path") or "").rsplit("/", 1)[-1]
        return str(item).rsplit("/", 1)[-1]

    def _remote_path(self, item):
        if isinstance(item, str) and item.startswith("/"):
            return item
        if isinstance(item, dict) and item.get("path"):
            return item["path"]
        return self.cfg.inbound_path.rstrip("/") + "/" + self._filename(item)

    def _find_rule(self, filename: str):
        for rule in self.rules:
            if rule.matches(filename):
                return rule
        return None

    def discover(self):
        files = self.storage.list_files(self.cfg.inbound_path)
        candidates = []
        for item in files:
            name = self._filename(item)
            if name.endswith(".part"):
                continue
            if not name.lower().endswith(".gpg"):
                continue
            rule = self._find_rule(name)
            if rule:
                candidates.append((self._remote_path(item), name, rule))
            else:
                LOG.warning("No process rule found for %s; skipped.", name)
        return sorted(candidates, key=lambda x: x[1])

    def run(self):
        self.storage.ensure_dirs(
            self.cfg.inbound_path, self.cfg.decrypted_path,
            self.cfg.inbound_archive_path, self.cfg.audit_log_path,
        )
        items = self.discover()
        LOG.info("Inbound candidates: %s", len(items))
        with ThreadPoolExecutor(max_workers=self.cfg.max_workers) as pool:
            futures = [pool.submit(self.process_one, *x) for x in items]
            for f in as_completed(futures):
                f.result()

    def process_one(self, remote_path: str, filename: str, rule: ProcessRule):
        if self.repo is not None and self.repo.has_completed_file(
            space_id=rule.space_id, object_type=rule.object_type,
            object_id=rule.task_chain_id, file_name=filename
        ):
            LOG.info("Already completed: %s", filename)
            return

        run_uuid = str(uuid.uuid4())
        if self.repo is not None:
            self.repo.create_run(
                space_id=rule.space_id,
                object_type=rule.object_type,
                tc_group_id=rule.tc_group_id,
                object_id=rule.task_chain_id,
                run_uuid=run_uuid,
                kyma_status="STARTED",
                dsp_status=None,
                message="Inbound processing started",
                object_nr=rule.object_nr,
                file_name=filename,
            )
        self.hldf_audit.write(run_uuid=run_uuid, process_type="INBOUND", status="STARTED", message=filename, details={"step": "START"})

        try:
            if not self.cfg.inbound_gpg_passphrase:
                raise RuntimeError("INBOUND_GPG_PASSPHRASE is missing.")

            with tempfile.TemporaryDirectory(prefix="kyma-in-") as td:
                encrypted = str(Path(td) / filename)
                plain_name = filename[:-4] if filename.lower().endswith(".gpg") else filename + ".plain"
                plain = str(Path(td) / plain_name)
                transformed = str(Path(td) / ("decoded_" + plain_name))

                log_stage(LOG, "DOWNLOAD_START", extra=f"remote={remote_path}")
                self.storage.download(remote_path, encrypted)
                log_stage(LOG, "DOWNLOAD_DONE", path=encrypted)
                log_stage(LOG, "DECRYPT_START", path=encrypted)
                decrypt_symmetric(encrypted, plain, self.cfg.inbound_gpg_passphrase)
                log_stage(LOG, "DECRYPT_DONE", path=plain)

                row_count = None
                upload_source = plain
                base64_decision = None
                if rule.decode_base64 and plain_name.lower().endswith(".csv"):
                    mode = rule.base64_mode or getattr(self.cfg, "base64_mode", "AUTO_STRICT")
                    fields = rule.base64_fallback_fields or getattr(self.cfg, "base64_fallback_fields", ())
                    upload_source, row_count, base64_decision = prepare_csv_payload(
                        plain, transformed, mode=mode, fallback_fields=fields
                    )
                    if upload_source != plain:
                        try:
                            Path(plain).unlink()
                        except OSError:
                            pass
                    else:
                        validate_utf8_file(plain, allow_bom=False)
                else:
                    validate_utf8_file(plain, allow_bom=False)

                decrypted_name = build_decrypted_filename(plain_name)
                target = self.cfg.decrypted_path.rstrip("/") + "/" + decrypted_name
                log_stage(LOG, "UPLOAD_START", path=upload_source, extra=f"remote={target}")
                self.storage.upload(upload_source, target)
                log_stage(LOG, "UPLOAD_DONE", path=upload_source, extra=f"remote={target}")

                if self.repo is not None:
                    self.repo.update_run(
                        space_id=rule.space_id, object_type=rule.object_type,
                    tc_group_id=rule.tc_group_id, object_id=rule.task_chain_id,
                    run_uuid=run_uuid, kyma_status="FILE_READY",
                    message=f"Decrypted file available: {target}", row_count=row_count
                )

                lifecycle = normalize_lifecycle(getattr(self.cfg, "inbound_success_lifecycle", "KEEP"))
                if lifecycle != "KEEP":
                    archive_target = self.cfg.inbound_archive_path.rstrip("/") + "/" + filename
                    result = apply_remote_lifecycle(
                        self.storage, remote_path, lifecycle, archive_target=archive_target, temp_dir=td
                    )
                    self.hldf_audit.write(
                        run_uuid=run_uuid, process_type="INBOUND_LIFECYCLE", status="SUCCESS",
                        message=f"{lifecycle}: {filename}",
                        details={"action": lifecycle, "archive_target": result.archive_target,
                                 "size": result.integrity.size if result.integrity else None,
                                 "sha256": result.integrity.sha256 if result.integrity else None},
                    )

                if not self.cfg.datasphere_taskchain_api_enabled:
                    LOG.info("DataSphere taskchain API disabled; file left for inspection: %s", target)
                    self.hldf_audit.write(
                        run_uuid=run_uuid, process_type="TASKCHAIN_API_SKIPPED", status="SUCCESS",
                        message="DataSphere taskchain API disabled; processing stopped after decrypted HDLF upload",
                        details={"source_plain_file": plain_name, "decrypted_file": decrypted_name},
                    )
                    return

                params = dict(rule.input_parameters or {})
                params.setdefault("RUN_UUID", run_uuid)

                def start():
                    return self.dsp.run_task_chain(rule.space_id, rule.task_chain_id, params)
                task = retry_call(
                    start, self.cfg.max_retries, self.cfg.retry_wait_seconds,
                    lambda e: isinstance(e, DataSphereHTTPError) and e.retriable
                )

                if self.repo is not None:
                    self.repo.update_run(
                        space_id=rule.space_id, object_type=rule.object_type,
                    tc_group_id=rule.tc_group_id, object_id=rule.task_chain_id,
                    run_uuid=run_uuid, kyma_status="DSP_STARTED",
                    dsp_status="SUBMITTED",
                    message=f"DataSphere logId={task.log_id}"
                )

                def on_status(status):
                    LOG.info("DataSphere taskchain status: taskChain=%s logId=%s status=%s", rule.task_chain_id, task.log_id, status)
                    if self.repo is not None:
                        self.repo.update_run(
                            space_id=rule.space_id, object_type=rule.object_type,
                            tc_group_id=rule.tc_group_id, object_id=rule.task_chain_id,
                            run_uuid=run_uuid, dsp_status=status,
                            message=f"DataSphere logId={task.log_id}; status={status}"
                        )

                final_status = self.dsp.wait_for_task(
                    rule.space_id, task.log_id,
                    self.cfg.poll_interval_seconds,
                    self.cfg.poll_timeout_seconds,
                    on_status=on_status,
                )

                if self.repo is not None:
                    self.repo.update_run(
                        space_id=rule.space_id, object_type=rule.object_type,
                    tc_group_id=rule.tc_group_id, object_id=rule.task_chain_id,
                    run_uuid=run_uuid, kyma_status="COMPLETED",
                    dsp_status=final_status, end=True,
                    message=f"Completed; DataSphere logId={task.log_id}",
                    row_count=row_count
                )
                self.hldf_audit.write(run_uuid=run_uuid, process_type="INBOUND", status="COMPLETED", message=filename, details={"step": "END"})

        except Exception as exc:
            LOG.exception("Inbound failed for %s", filename)
            try:
                if self.repo is not None:
                    self.repo.update_run(
                        space_id=rule.space_id, object_type=rule.object_type,
                    tc_group_id=rule.tc_group_id, object_id=rule.task_chain_id,
                    run_uuid=run_uuid, kyma_status="FAILED", end=True,
                    message=str(exc)
                )
            finally:
                self.hldf_audit.write(run_uuid=run_uuid, process_type="INBOUND", status="FAILED", error_code=type(exc).__name__, error_message=str(exc), details={"step": "ERROR"})
            raise
