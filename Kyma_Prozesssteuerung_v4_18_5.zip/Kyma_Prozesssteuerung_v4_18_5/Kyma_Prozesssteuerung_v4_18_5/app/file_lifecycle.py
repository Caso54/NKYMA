from __future__ import annotations
import tempfile
from dataclasses import dataclass
from pathlib import Path
from .file_integrity import FileIntegrity, file_integrity

VALID_LIFECYCLES = {"KEEP", "ARCHIVE", "DELETE"}

@dataclass(frozen=True)
class LifecycleResult:
    action: str
    source: str
    archive_target: str | None
    integrity: FileIntegrity | None


def normalize_lifecycle(value: str | None, default: str = "KEEP") -> str:
    action = (value or default).strip().upper()
    if action not in VALID_LIFECYCLES:
        raise ValueError(f"Invalid lifecycle '{value}'. Expected KEEP, ARCHIVE or DELETE.")
    return action


def apply_remote_lifecycle(storage, source: str, action: str, *, archive_target: str | None = None, temp_dir: str | None = None) -> LifecycleResult:
    """Apply KEEP/ARCHIVE/DELETE. ARCHIVE is always copy -> verify -> delete.

    Verification compares both byte size and SHA-256 of the downloaded source with a
    fresh download of the uploaded archive target. The source is deleted only after
    both values match.
    """
    action = normalize_lifecycle(action)
    if action == "KEEP":
        return LifecycleResult(action, source, None, None)
    if action == "DELETE":
        storage.delete_file(source)
        return LifecycleResult(action, source, None, None)
    if not archive_target:
        raise ValueError("archive_target is required for ARCHIVE lifecycle")

    owned_td = None
    if temp_dir is None:
        owned_td = tempfile.TemporaryDirectory(prefix="kyma-life-")
        temp_dir = owned_td.name
    try:
        src_local = str(Path(temp_dir) / ("src_" + Path(source).name))
        verify_local = str(Path(temp_dir) / ("verify_" + Path(archive_target).name))
        storage.download(source, src_local)
        expected = file_integrity(src_local)
        storage.upload(src_local, archive_target)
        if not storage.exists(archive_target):
            raise RuntimeError(f"Archive target not found after upload: {archive_target}")
        storage.download(archive_target, verify_local)
        actual = file_integrity(verify_local)
        if actual != expected:
            raise RuntimeError(
                f"Archive integrity mismatch for {source}: "
                f"source(size={expected.size},sha256={expected.sha256}) != "
                f"archive(size={actual.size},sha256={actual.sha256})"
            )
        storage.delete_file(source)
        return LifecycleResult(action, source, archive_target, expected)
    finally:
        if owned_td is not None:
            owned_td.cleanup()
