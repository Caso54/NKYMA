from __future__ import annotations
import json
import uuid
from datetime import datetime, timezone
from hdbcli import dbapi


def now_utc():
    return datetime.now(timezone.utc)


# Python str values are Unicode; hdbcli sends them as Unicode to HANA.
def _safe_json(value):
    if value is None:
        return None
    try:
        return json.dumps(value, ensure_ascii=False, default=str)[:4000]
    except Exception:
        return str(value)[:4000]


class AuditRepository:
    def __init__(self, host, port, user, password, schema, audit_table):
        self.host = host
        self.port = port
        self.user = user
        self.password = password
        self.schema = schema
        self.audit_table = audit_table

    def connect(self):
        return dbapi.connect(
            address=self.host,
            port=self.port,
            user=self.user,
            password=self.password,
            encrypt=True,
        )

    def fq(self, name):
        return f'"{self.schema}"."{name}"'

    def write(self, *, run_uuid=None, set_id=None, set_date=None, file_id=None,
              process_type, status, message=None, task_chain_id=None, dsp_log_id=None,
              http_method=None, http_status=None, api_endpoint=None, retry_no=0,
              duration_ms=None, error_code=None, error_message=None, details=None):
        sql = (
            f'INSERT INTO {self.fq(self.audit_table)} '
            '("AUDIT_UUID","RUN_UUID","SET_ID","SET_DATE","FILE_ID","PROCESS_TYPE",'
            '"TASK_CHAIN_ID","DSP_LOG_ID","EVENT_TIMESTAMP","STATUS","HTTP_METHOD",'
            '"HTTP_STATUS","API_ENDPOINT","RETRY_NO","DURATION_MS","MESSAGE",'
            '"ERROR_CODE","ERROR_MESSAGE","DETAILS_JSON") '
            'VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)'
        )
        vals = (
            str(uuid.uuid4()), run_uuid, set_id, set_date, file_id, process_type,
            task_chain_id, dsp_log_id, now_utc(), status, http_method,
            http_status, api_endpoint, retry_no, duration_ms,
            (message or "")[:1000], (error_code or "")[:100],
            (error_message or "")[:2000], _safe_json(details),
        )
        c = self.connect()
        try:
            c.cursor().execute(sql, vals)
            c.commit()
        finally:
            c.close()
