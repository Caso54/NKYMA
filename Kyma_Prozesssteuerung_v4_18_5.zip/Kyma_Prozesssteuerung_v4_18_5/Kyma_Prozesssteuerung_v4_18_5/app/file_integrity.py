from __future__ import annotations
import hashlib
from dataclasses import dataclass
from pathlib import Path

CHUNK_SIZE = 8 * 1024 * 1024

@dataclass(frozen=True)
class FileIntegrity:
    size: int
    sha256: str


def file_integrity(path: str | Path, chunk_size: int = CHUNK_SIZE) -> FileIntegrity:
    p = Path(path)
    h = hashlib.sha256()
    size = 0
    with p.open("rb") as fh:
        while True:
            chunk = fh.read(chunk_size)
            if not chunk:
                break
            size += len(chunk)
            h.update(chunk)
    return FileIntegrity(size=size, sha256=h.hexdigest())
