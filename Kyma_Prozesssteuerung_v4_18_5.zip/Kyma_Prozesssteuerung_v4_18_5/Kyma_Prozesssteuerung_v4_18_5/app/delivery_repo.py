from __future__ import annotations
from datetime import datetime, timezone
from hdbcli import dbapi


def now_utc():
    return datetime.now(timezone.utc)


class DeliveryRepository:
    def __init__(self, host, port, user, password, schema, file_table, set_table):
        self.host = host
        self.port = port
        self.user = user
        self.password = password
        self.schema = schema
        self.file_table = file_table
        self.set_table = set_table

    def connect(self):
        return dbapi.connect(
            address=self.host,
            port=self.port,
            user=self.user,
            password=self.password,
            encrypt=True,
        )

    def fq(self, name):
        return f'"{self.schema}"."{name}"'

    def ensure_set(self, set_id, set_date, predecessor, expected_files):
        # Idempotent creation: never overwrite an existing set on the next CronJob run.
        check = f'SELECT COUNT(*) FROM {self.fq(self.set_table)} WHERE "SET_ID"=? AND "SET_DATE"=?'
        insert = (
            f'INSERT INTO {self.fq(self.set_table)} '
            '("SET_ID","SET_DATE","SET_STATUS","PREDECESSOR_SET_DATE","EXPECTED_FILES",'
            '"RECEIVED_FILES","SUCCESSFUL_FILES","MISSING_FILES","FAILED_FILES","START_TIMESTAMP","MESSAGE") '
            'VALUES (?,?,?,?,?,?,?,?,?,?,?)'
        )
        vals = (set_id, set_date, "WAITING", predecessor, expected_files, 0, 0, expected_files, 0, now_utc(), "Set initialized")
        c = self.connect()
        try:
            cur = c.cursor()
            cur.execute(check, (set_id, set_date))
            if int(cur.fetchone()[0]) == 0:
                cur.execute(insert, vals)
                c.commit()
        finally:
            c.close()

    def ensure_expected_file(self, set_id, set_date, file_id, file_role, file_mode):
        check = (f'SELECT COUNT(*) FROM {self.fq(self.file_table)} '
                 'WHERE "SET_ID"=? AND "SET_DATE"=? AND "FILE_ID"=?')
        insert = (f'INSERT INTO {self.fq(self.file_table)} '
                  '("SET_ID","SET_DATE","FILE_ID","FILE_ROLE","FILE_MODE","FILE_STATUS","START_TIMESTAMP") '
                  'VALUES (?,?,?,?,?,?,?)')
        c = self.connect()
        try:
            cur = c.cursor(); cur.execute(check, (set_id, set_date, file_id))
            if int(cur.fetchone()[0]) == 0:
                cur.execute(insert, (set_id, set_date, file_id, file_role, file_mode, "MISSING", now_utc()))
                c.commit()
        finally:
            c.close()

    def upsert_file(self, **k):
        sql = (
            f'UPSERT {self.fq(self.file_table)} '
            '("SET_ID","SET_DATE","FILE_ID","RUN_UUID","DELIVERY_DATE","EXTRACTION_DATE","FILE_NAME",'
            '"FILE_ROLE","FILE_MODE","FILE_STATUS","START_TIMESTAMP","END_TIMESTAMP","ERROR_MESSAGE") '
            'VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?) WITH PRIMARY KEY'
        )
        vals = (
            k["set_id"], k["set_date"], k["file_id"], k["run_uuid"],
            k["delivery_date"], k["extraction_date"], k["file_name"],
            k["file_role"], k["file_mode"], k["file_status"], now_utc(), None, None,
        )
        c = self.connect()
        try:
            c.cursor().execute(sql, vals)
            c.commit()
        finally:
            c.close()

    def update_file_status(self, *, set_id, set_date, file_id, run_uuid, status, dsp_log_id=None, error_message=None, end=False):
        assigns = ['"FILE_STATUS"=?']
        vals = [status]
        if dsp_log_id is not None:
            assigns.append('"DSP_LOG_ID"=?')
            vals.append(dsp_log_id)
        if error_message is not None:
            assigns.append('"ERROR_MESSAGE"=?')
            vals.append(error_message[:1000])
        if end:
            assigns.append('"END_TIMESTAMP"=?')
            vals.append(now_utc())
        sql = (
            f'UPDATE {self.fq(self.file_table)} SET {", ".join(assigns)} '
            'WHERE "SET_ID"=? AND "SET_DATE"=? AND "FILE_ID"=? AND "RUN_UUID"=?'
        )
        vals += [set_id, set_date, file_id, run_uuid]
        c = self.connect()
        try:
            c.cursor().execute(sql, tuple(vals))
            c.commit()
        finally:
            c.close()

    def file_success_exists(self, set_id, set_date, file_id):
        sql = (
            f'SELECT COUNT(*) FROM {self.fq(self.file_table)} '
            'WHERE "SET_ID"=? AND "SET_DATE"=? AND "FILE_ID"=? '
            'AND "FILE_STATUS" IN (\'LOADED\',\'COMPLETED\')'
        )
        c = self.connect()
        try:
            cur = c.cursor()
            cur.execute(sql, (set_id, set_date, file_id))
            return int(cur.fetchone()[0]) > 0
        finally:
            c.close()

    def file_status(self, set_id, set_date, file_id):
        sql = (
            f'SELECT "FILE_STATUS" FROM {self.fq(self.file_table)} '
            'WHERE "SET_ID"=? AND "SET_DATE"=? AND "FILE_ID"=? '
            'ORDER BY "START_TIMESTAMP" DESC LIMIT 1'
        )
        c = self.connect()
        try:
            cur = c.cursor()
            cur.execute(sql, (set_id, set_date, file_id))
            row = cur.fetchone()
            return str(row[0]).upper() if row and row[0] is not None else None
        finally:
            c.close()

    def oldest_open_missing_set(self, set_id, file_id):
        sql = (
            f'SELECT S."SET_DATE" FROM {self.fq(self.set_table)} S '
            'WHERE S."SET_ID"=? AND S."SET_STATUS" IN (\'WAITING\',\'PARTIAL\',\'BLOCKED\',\'WAITING_PREDECESSOR\',\'FAILED\') '
            f'AND NOT EXISTS (SELECT 1 FROM {self.fq(self.file_table)} F '
            'WHERE F."SET_ID"=S."SET_ID" AND F."SET_DATE"=S."SET_DATE" '
            'AND F."FILE_ID"=? AND F."FILE_STATUS" IN (\'LOADED\',\'COMPLETED\')) '
            'ORDER BY S."SET_DATE" ASC LIMIT 1'
        )
        c = self.connect()
        try:
            cur = c.cursor()
            cur.execute(sql, (set_id, file_id))
            row = cur.fetchone()
            return row[0] if row else None
        finally:
            c.close()

    def predecessor_completed(self, set_id, set_date):
        sql = (
            f'SELECT "SET_STATUS" FROM {self.fq(self.set_table)} '
            'WHERE "SET_ID"=? AND "SET_DATE"<? AND COALESCE("EXPECTED_FILES",0)>0 ORDER BY "SET_DATE" DESC LIMIT 1'
        )
        c = self.connect()
        try:
            cur = c.cursor()
            cur.execute(sql, (set_id, set_date))
            row = cur.fetchone()
            return row is None or str(row[0]).upper() == "COMPLETED"
        finally:
            c.close()

    def summarize_set(self, set_id, set_date, ids):
        ph = ",".join(["?"] * len(ids))
        sql = (
            f'SELECT "FILE_ID","FILE_STATUS" FROM {self.fq(self.file_table)} '
            f'WHERE "SET_ID"=? AND "SET_DATE"=? AND "FILE_ID" IN ({ph})'
        )
        c = self.connect()
        try:
            cur = c.cursor()
            cur.execute(sql, tuple([set_id, set_date] + ids))
            rows = cur.fetchall()
        finally:
            c.close()
        st = {}
        for fid, status in rows:
            st.setdefault(str(fid), []).append(str(status).upper())
        received = sum(1 for fid in ids if any(x != "MISSING" for x in st.get(fid, [])))
        success = sum(1 for fid in ids if any(s == "COMPLETED" for s in st.get(fid, [])))
        failed = sum(1 for fid in ids if any(s == "FAILED" for s in st.get(fid, [])))
        return {"expected": len(ids), "received": received, "success": success, "missing": len(ids)-success, "failed": failed}

    def set_status(self, set_id, set_date):
        sql = f'SELECT "SET_STATUS" FROM {self.fq(self.set_table)} WHERE "SET_ID"=? AND "SET_DATE"=?'
        c = self.connect()
        try:
            cur = c.cursor()
            cur.execute(sql, (set_id, set_date))
            row = cur.fetchone()
            return str(row[0]).upper() if row else None
        finally:
            c.close()


    def dependencies_completed(self, dependency_ids, set_date):
        if not dependency_ids:
            return True
        ph = ",".join(["?"] * len(dependency_ids))
        sql = (f'SELECT COUNT(*) FROM {self.fq(self.set_table)} '
               f'WHERE "SET_DATE"=? AND "SET_ID" IN ({ph}) AND "SET_STATUS"=\'COMPLETED\'')
        c = self.connect()
        try:
            cur = c.cursor(); cur.execute(sql, tuple([set_date] + list(dependency_ids)))
            return int(cur.fetchone()[0]) == len(dependency_ids)
        finally:
            c.close()
    def update_set(self, set_id, set_date, status, summary, message="", end=False):
        sql = (
            f'UPDATE {self.fq(self.set_table)} SET "SET_STATUS"=?,"EXPECTED_FILES"=?,"RECEIVED_FILES"=?, '
            '"SUCCESSFUL_FILES"=?,"MISSING_FILES"=?,"FAILED_FILES"=?,"MESSAGE"=?,"END_TIMESTAMP"=? '
            'WHERE "SET_ID"=? AND "SET_DATE"=?'
        )
        vals = (
            status, summary["expected"], summary["received"], summary["success"], summary["missing"],
            summary["failed"], message[:1000], now_utc() if end else None, set_id, set_date,
        )
        c = self.connect()
        try:
            c.cursor().execute(sql, vals)
            c.commit()
        finally:
            c.close()
