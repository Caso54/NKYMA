from __future__ import annotations
import csv
import logging
import tempfile
import uuid
from datetime import datetime, timezone
from pathlib import Path

from .utf8_utils import UTF8, UTF8_SIG, validate_utf8_file
from .config import Settings
from .crypto_gpg import encrypt_symmetric
from .hldf_audit import HldfAuditLogger
from .storage import HldfStorage
from .performance import log_stage
from .file_lifecycle import apply_remote_lifecycle, normalize_lifecycle

LOG = logging.getLogger("kyma.outbound")


class OutboundAS300:
    """AS-300 outbound processing.

    DataSphere creates one or more ``part-*.csv`` files under the configured
    ``.../DS_DL_EX_AS300/initial`` directory. They are converted into one UTF-8
    CSV (single part = direct content, multiple parts = header-safe merge), then
    symmetrically GPG-encrypted as::

        <AS300_OUTPUT_FILENAME_PREFIX>_<UTC timestamp>.csv.gpg

    Only after the encrypted target was uploaded successfully are the source
    files that belonged to this run deleted. A newly arrived file that was not
    part of the initial snapshot is never deleted by that run.
    """

    def __init__(self, cfg: Settings):
        self.cfg = cfg
        self.storage = HldfStorage()
        if cfg.central_opensql_status_enabled:
            from .status_repo import StatusRepository
            self.repo = StatusRepository(
                cfg.sql_host, cfg.sql_port, cfg.sql_user, cfg.sql_password,
                cfg.sql_schema, cfg.sql_status_table,
            )
        else:
            self.repo = None
        self.hldf_audit = HldfAuditLogger(self.storage, cfg.audit_log_path, "OUTBOUND_AS300")

    def _ensure_required_dirs(self):
        self.storage.ensure_dirs(
            self.cfg.outbound_path,
            self.cfg.outbound_source_path,
            self.cfg.encrypted_path,
            self.cfg.outbound_archive_path,
            self.cfg.audit_log_path,
        )

    @staticmethod
    def _remote_path(root: str, item) -> str | None:
        path = item if isinstance(item, str) else item.get("path") or item.get("name")
        if not path:
            return None
        path = str(path)
        return path if path.startswith("/") else root.rstrip("/") + "/" + path

    def _source_snapshot(self) -> tuple[list[str], list[str]]:
        """Return (all_files, part_csv_files) present when this run starts."""
        root = self.cfg.outbound_source_path
        all_files: list[str] = []
        parts: list[str] = []
        for item in self.storage.list_files(root):
            remote = self._remote_path(root, item)
            if not remote:
                continue
            all_files.append(remote)
            name = Path(remote).name.lower()
            if name.startswith("part-") and name.endswith(".csv"):
                parts.append(remote)
        return sorted(set(all_files)), sorted(set(parts))

    def run(self):
        if not self.cfg.outbound_gpg_passphrase:
            raise RuntimeError("OUTBOUND_GPG_PASSPHRASE is missing.")

        self._ensure_required_dirs()
        source_snapshot, parts = self._source_snapshot()
        if not parts:
            LOG.info("No AS-300 part-*.csv files found in %s", self.cfg.outbound_source_path)
            self._ensure_required_dirs()
            return

        run_uuid = str(uuid.uuid4())
        stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        output_name = f"{self.cfg.as300_output_filename_prefix}_{stamp}.csv.gpg"

        if self.repo is not None:
            self.repo.create_run(
                space_id=self.cfg.dsp_space_id,
                object_type="KYMA_OUTBOUND",
                tc_group_id="AS300",
                object_id="AS-300",
                run_uuid=run_uuid,
                kyma_status="STARTED",
                dsp_status=None,
                message=f"AS-300 processing started with {len(parts)} part file(s)",
                object_nr="300",
                file_name=output_name,
            )
        self.hldf_audit.write(
            run_uuid=run_uuid, process_type="OUTBOUND_AS300", status="STARTED",
            message=f"{len(parts)} part file(s)",
            details={"step": "START", "source_path": self.cfg.outbound_source_path, "parts": parts},
        )

        try:
            with tempfile.TemporaryDirectory(prefix="kyma-as300-") as td:
                plain_csv = str(Path(td) / output_name.removesuffix(".gpg"))
                rows = self._merge_remote_csv(parts, plain_csv, td)
                # Writer emits UTF-8 without BOM and LF directly; validation is streaming.
                validate_utf8_file(plain_csv, allow_bom=False)
                self.hldf_audit.write(
                    run_uuid=run_uuid, process_type="OUTBOUND_LINE_ENDINGS", status="SUCCESS",
                    message="AS-300 CSV line endings normalized to LF",
                    details={"step": "NORMALIZE_LF", "line_separator": "LF"},
                )

                gpg_path = plain_csv + ".gpg"
                encrypt_symmetric(plain_csv, gpg_path, self.cfg.outbound_gpg_passphrase)

                remote_target = self.cfg.encrypted_path.rstrip("/") + "/" + output_name
                self.storage.upload(gpg_path, remote_target)
                if not self.storage.exists(remote_target):
                    raise RuntimeError(f"Encrypted AS-300 target not found after upload: {remote_target}")

                # Apply the configured lifecycle to the exact source snapshot.
                # ARCHIVE is always copy -> size/SHA-256 verify -> delete. New files
                # arriving after the initial snapshot are never touched by this run.
                lifecycle = normalize_lifecycle(getattr(self.cfg, "outbound_source_lifecycle", "ARCHIVE"), "ARCHIVE")
                lifecycle_errors = []
                archived_targets = []
                integrity_details = []
                outbound_root = self.cfg.outbound_path.rstrip("/") + "/"
                for remote in source_snapshot:
                    try:
                        if remote.startswith(outbound_root):
                            relative = remote[len(outbound_root):]
                        else:
                            relative = Path(remote).name
                        archive_remote = self.cfg.outbound_archive_path.rstrip("/") + "/" + relative.lstrip("/")
                        result = apply_remote_lifecycle(
                            self.storage, remote, lifecycle,
                            archive_target=archive_remote if lifecycle == "ARCHIVE" else None,
                            temp_dir=td,
                        )
                        if result.archive_target:
                            archived_targets.append(result.archive_target)
                        if result.integrity:
                            integrity_details.append({
                                "source": remote, "archive": result.archive_target,
                                "size": result.integrity.size, "sha256": result.integrity.sha256,
                            })
                    except Exception as exc:
                        lifecycle_errors.append(f"{remote}: {exc}")

                if lifecycle_errors:
                    self.hldf_audit.write(
                        run_uuid=run_uuid, process_type=("OUTBOUND_ARCHIVE" if lifecycle == "ARCHIVE" else "OUTBOUND_LIFECYCLE"), status=("FAILED" if lifecycle == "ARCHIVE" else "WARNING"),
                        message=f"AS-300 target created; {lifecycle} lifecycle incomplete; failed sources were kept where possible",
                        error_code="SOURCE_LIFECYCLE_INCOMPLETE",
                        error_message=" | ".join(lifecycle_errors)[:2000],
                        details={"target": remote_target, "action": lifecycle, "errors": lifecycle_errors,
                                 "archived": archived_targets, "integrity": integrity_details},
                    )
                    LOG.warning("AS-300 target created; source lifecycle incomplete: %s", lifecycle_errors)
                else:
                    self.hldf_audit.write(
                        run_uuid=run_uuid, process_type=("OUTBOUND_ARCHIVE" if lifecycle == "ARCHIVE" else "OUTBOUND_LIFECYCLE"), status="SUCCESS",
                        message=f"DataSphere outbound source lifecycle completed: {lifecycle}",
                        details={"action": lifecycle, "archived_files": archived_targets,
                                 "archive_root": self.cfg.outbound_archive_path, "integrity": integrity_details},
                    )

                # HDLF may remove empty directory structures automatically. Re-create
                # every required directory immediately after archive/cleanup.
                self._ensure_required_dirs()

                if self.repo is not None:
                    self.repo.update_run(
                        space_id=self.cfg.dsp_space_id,
                        object_type="KYMA_OUTBOUND",
                        tc_group_id="AS300",
                        object_id="AS-300",
                        run_uuid=run_uuid,
                        kyma_status="COMPLETED",
                        ext_status="ENCRYPTED",
                        end=True,
                        message=f"Uploaded {remote_target}",
                        row_count=rows,
                    )
                self.hldf_audit.write(
                    run_uuid=run_uuid, process_type="OUTBOUND_AS300", status="COMPLETED",
                    message=remote_target,
                    details={"step": "END", "row_count": rows, "source_parts": len(parts)},
                )

        except Exception as exc:
            LOG.exception("AS-300 failed")
            # Re-create required paths even after failures.
            try:
                self._ensure_required_dirs()
            except Exception:
                LOG.exception("Could not re-create required HDLF directories after AS-300 failure")
            try:
                if self.repo is not None:
                    self.repo.update_run(
                        space_id=self.cfg.dsp_space_id,
                        object_type="KYMA_OUTBOUND",
                        tc_group_id="AS300",
                        object_id="AS-300",
                        run_uuid=run_uuid,
                        kyma_status="FAILED",
                        end=True,
                        message=str(exc),
                    )
            finally:
                self.hldf_audit.write(
                    run_uuid=run_uuid, process_type="OUTBOUND_AS300", status="FAILED",
                    error_code=type(exc).__name__, error_message=str(exc), details={"step": "ERROR"},
                )
            raise


    def _merge_remote_csv(self, parts: list[str], target: str, temp_dir: str) -> int:
        """Download and merge one source part at a time with bounded RAM/temp usage.

        CSV decoding itself validates UTF-8 strictly. Output is written directly with
        LF line endings, avoiding the former full-file ``read_bytes()/replace`` pass.
        """
        rows = 0
        header = None
        Path(target).parent.mkdir(parents=True, exist_ok=True)
        with open(target, "w", encoding=UTF8, errors="strict", newline="") as out:
            writer = csv.writer(out, delimiter=";", quoting=csv.QUOTE_MINIMAL, lineterminator="\n")
            for i, remote in enumerate(parts):
                local = Path(temp_dir) / f"part_{i:05d}.csv"
                log_stage(LOG, "OUTBOUND_PART_DOWNLOAD_START", extra=f"remote={remote}")
                self.storage.download(remote, str(local))
                log_stage(LOG, "OUTBOUND_PART_DOWNLOAD_DONE", path=str(local), extra=f"remote={remote}")
                try:
                    with local.open("r", encoding=UTF8_SIG, errors="strict", newline="") as f:
                        reader = csv.reader(f, delimiter=";")
                        try:
                            current_header = next(reader)
                        except StopIteration:
                            continue
                        if header is None:
                            header = current_header
                            writer.writerow(header)
                        elif current_header != header:
                            raise RuntimeError(f"CSV header mismatch in {remote}")
                        for row in reader:
                            writer.writerow(row)
                            rows += 1
                            if rows % 100000 == 0:
                                log_stage(LOG, "OUTBOUND_MERGE_PROGRESS", path=target, rows=rows)
                finally:
                    try:
                        local.unlink()
                    except OSError:
                        pass
        log_stage(LOG, "OUTBOUND_MERGE_DONE", path=target, rows=rows)
        return rows

    @staticmethod
    def _normalize_lf_file(path: str) -> None:
        """Backward-compatible streaming line-ending normalizer.

        New AS-300 output is already written with LF by ``_merge_remote_csv``. This
        method remains for compatibility/tests and never loads the full file in RAM.
        """
        src = Path(path)
        tmp = src.with_name(src.name + ".lf.tmp")
        pending_cr = False
        with src.open("rb") as fin, tmp.open("wb") as fout:
            while True:
                chunk = fin.read(8 * 1024 * 1024)
                if not chunk:
                    break
                if pending_cr:
                    chunk = b"\r" + chunk
                    pending_cr = False
                if chunk.endswith(b"\r"):
                    chunk = chunk[:-1]
                    pending_cr = True
                chunk = chunk.replace(b"\r\n", b"\n").replace(b"\r", b"\n")
                fout.write(chunk)
            if pending_cr:
                fout.write(b"\n")
        tmp.replace(src)

    @staticmethod
    def _merge_csv(parts: list[str], target: str) -> int:
        """Compatibility helper for local tests; streaming and LF-native."""
        rows = 0
        header = None
        with open(target, "w", encoding=UTF8, errors="strict", newline="") as out:
            writer = csv.writer(out, delimiter=";", quoting=csv.QUOTE_MINIMAL, lineterminator="\n")
            for part in parts:
                with open(part, "r", encoding=UTF8_SIG, errors="strict", newline="") as f:
                    reader = csv.reader(f, delimiter=";")
                    try:
                        current_header = next(reader)
                    except StopIteration:
                        continue
                    if header is None:
                        header = current_header
                        writer.writerow(header)
                    elif current_header != header:
                        raise RuntimeError(f"CSV header mismatch in {part}")
                    for row in reader:
                        writer.writerow(row)
                        rows += 1
        return rows
