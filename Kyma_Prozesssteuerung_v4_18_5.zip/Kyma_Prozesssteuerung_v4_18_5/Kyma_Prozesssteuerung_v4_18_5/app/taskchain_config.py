from __future__ import annotations
import json
from pathlib import Path
from .utf8_utils import read_utf8_text


class TaskChainCatalog:
    def __init__(self, entries: dict[tuple[str, str], dict]):
        self.entries = entries

    @classmethod
    def load(cls, path: str):
        p = Path(path)
        if not p.exists():
            return cls({})
        raw = json.loads(read_utf8_text(p, allow_bom=True))
        entries = {}
        for item in raw.get("taskchains", []):
            set_id = str(item.get("file_set_id") or "")
            file_id = str(item.get("sap_file_name") or item.get("source_file") or "")
            if set_id and file_id:
                entries[(set_id, file_id)] = item
        return cls(entries)

    def get(self, set_id: str, file_id: str) -> dict | None:
        return self.entries.get((set_id, file_id))
