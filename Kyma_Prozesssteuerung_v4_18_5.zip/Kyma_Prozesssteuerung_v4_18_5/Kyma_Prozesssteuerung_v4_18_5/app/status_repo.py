\
from __future__ import annotations
from datetime import datetime, timezone
from hdbcli import dbapi

def utc_ts():
    return datetime.now(timezone.utc)

class StatusRepository:
    """
    Repository for the existing Open SQL table FI_IT_M_TA_RUN_LOG_TC.

    Primary key:
      DS_Space_ID, DS_Object_Type, DS_TC_Group_ID, DS_Object_ID, DS_Run_UUID
    """
    def __init__(self, host: str, port: int, user: str, password: str, schema: str, table: str):
        self.host = host
        self.port = port
        self.user = user
        self.password = password
        self.schema = schema
        self.table = table

    @property
    def fqtn(self) -> str:
        # schema/table are deployment config, not user input.
        return f'"{self.schema}"."{self.table}"'

    def connect(self):
        return dbapi.connect(
            address=self.host,
            port=self.port,
            user=self.user,
            password=self.password,
            encrypt=True,
        )

    def create_run(self, *, space_id: str, object_type: str, tc_group_id: str, object_id: str,
                   run_uuid: str, kyma_status: str, dsp_status: str | None = None,
                   ext_status: str | None = None, message: str | None = None,
                   object_nr: str | None = None, file_name: str | None = None,
                   row_count: int | None = None) -> None:
        sql = f"""
        INSERT INTO {self.fqtn}
        ("DS_Space_ID","DS_Object_Type","DS_TC_Group_ID","DS_Object_ID","DS_Run_UUID",
         "DS_Run_Start_Timestamp","DS_Run_Status_DSP","DS_Run_Status_Kyma","DS_Run_Status_Ext",
         "DS_Run_End_Timestamp","DS_Run_Message","DS_Object_NR","DS_File_Name","DS_Run_Row_Count")
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """
        values = (
            space_id, object_type, tc_group_id, object_id, run_uuid,
            utc_ts(), dsp_status, kyma_status, ext_status,
            None, (message or "")[:250], object_nr, (file_name or "")[:100], row_count
        )
        conn = self.connect()
        try:
            cur = conn.cursor()
            cur.execute(sql, values)
            conn.commit()
        finally:
            conn.close()

    def update_run(self, *, space_id: str, object_type: str, tc_group_id: str, object_id: str,
                   run_uuid: str, kyma_status: str | None = None, dsp_status: str | None = None,
                   ext_status: str | None = None, message: str | None = None,
                   end: bool = False, row_count: int | None = None) -> None:
        sets, values = [], []
        mapping = {
            "DS_Run_Status_Kyma": kyma_status,
            "DS_Run_Status_DSP": dsp_status,
            "DS_Run_Status_Ext": ext_status,
            "DS_Run_Message": (message[:250] if message is not None else None),
            "DS_Run_Row_Count": row_count,
        }
        for col, value in mapping.items():
            if value is not None:
                sets.append(f'"{col}"=?')
                values.append(value)
        if end:
            sets.append('"DS_Run_End_Timestamp"=?')
            # column is cds.String(100) in current model
            values.append(utc_ts().isoformat())
        if not sets:
            return
        sql = f"""
        UPDATE {self.fqtn}
        SET {", ".join(sets)}
        WHERE "DS_Space_ID"=? AND "DS_Object_Type"=? AND "DS_TC_Group_ID"=?
          AND "DS_Object_ID"=? AND "DS_Run_UUID"=?
        """
        values += [space_id, object_type, tc_group_id, object_id, run_uuid]
        conn = self.connect()
        try:
            cur = conn.cursor()
            cur.execute(sql, tuple(values))
            conn.commit()
        finally:
            conn.close()

    def has_completed_file(self, *, space_id: str, object_type: str, object_id: str, file_name: str) -> bool:
        sql = f"""
        SELECT COUNT(*)
        FROM {self.fqtn}
        WHERE "DS_Space_ID"=? AND "DS_Object_Type"=? AND "DS_Object_ID"=?
          AND "DS_File_Name"=? AND "DS_Run_Status_Kyma"='COMPLETED'
        """
        conn = self.connect()
        try:
            cur = conn.cursor()
            cur.execute(sql, (space_id, object_type, object_id, file_name))
            return int(cur.fetchone()[0]) > 0
        finally:
            conn.close()
