from __future__ import annotations
import argparse
from .config import Settings
from .logging_utils import configure_logging

def main():
    configure_logging()
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["inbound", "sets", "outbound-as300"])
    args = parser.parse_args()
    cfg = Settings.from_env()

    if args.mode == "inbound":
        from .inbound import InboundProcessor
        InboundProcessor(cfg).run()
    elif args.mode == "sets":
        from .set_orchestrator import SetOrchestrator
        SetOrchestrator(cfg).ingest_available_files()
    else:
        from .outbound import OutboundAS300
        OutboundAS300(cfg).run()

if __name__ == "__main__":
    main()
