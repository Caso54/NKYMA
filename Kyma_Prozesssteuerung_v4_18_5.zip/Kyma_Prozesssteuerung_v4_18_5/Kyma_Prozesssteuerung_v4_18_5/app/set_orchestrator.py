from __future__ import annotations
import logging
import re
import tempfile
import time
import uuid
from datetime import timedelta
from pathlib import Path

import requests

from .hldf_audit import HldfAuditLogger
from .config import Settings
from .crypto_gpg import decrypt_symmetric
from .csv_transform import prepare_csv_payload
from .datasphere import DataSphereClient, DataSphereHTTPError
from .delivery_model import DeliveryModel
from .memory_repo import InMemoryDeliveryRepository, InMemoryProcessRepository
from .storage import HldfStorage
from .taskchain_config import TaskChainCatalog
from .utf8_utils import validate_utf8_file
from .performance import log_stage
from .file_lifecycle import apply_remote_lifecycle, normalize_lifecycle
from .filename_utils import build_decrypted_filename

LOG = logging.getLogger("kyma.sets")

SUCCESS_TASK_STATUSES = {"COMPLETED", "DONE", "SUCCESS", "SUCCEEDED"}
FAILED_TASK_STATUSES = {"FAILED", "ERROR", "CANCELED", "CANCELLED"}


class SetOrchestrator:
    def __init__(self, cfg: Settings):
        self.cfg = cfg
        self.model = DeliveryModel.load(
            cfg.delivery_model_file,
            bank_holiday_calendar_enabled=cfg.bank_holiday_calendar_enabled,
            bank_holiday_calendar_file=cfg.bank_holiday_calendar_file,
        )
        self.taskchains = TaskChainCatalog.load(cfg.taskchains_file)
        if cfg.opensql_persistence_enabled:
            from .delivery_repo import DeliveryRepository
            from .process_repo import ProcessRepository
            from .audit_repo import AuditRepository
            self.repo = DeliveryRepository(
                cfg.sql_host, cfg.sql_port, cfg.sql_user, cfg.sql_password,
                cfg.sql_schema, cfg.file_status_table, cfg.set_status_table,
            )
            self.process_repo = ProcessRepository(
                cfg.sql_host, cfg.sql_port, cfg.sql_user, cfg.sql_password,
                cfg.sql_schema, cfg.process_status_table,
            )
            self.audit = AuditRepository(
                cfg.sql_host, cfg.sql_port, cfg.sql_user, cfg.sql_password,
                cfg.sql_schema, cfg.audit_table,
            )
        else:
            self.repo = InMemoryDeliveryRepository()
            self.process_repo = InMemoryProcessRepository()
            self.audit = None
        self.storage = HldfStorage()
        self.dsp = (
            DataSphereClient(cfg.dsp_host, cfg.dsp_token_url, cfg.dsp_client_id, cfg.dsp_client_secret)
            if cfg.datasphere_taskchain_api_enabled else None
        )
        if cfg.central_opensql_status_enabled:
            from .status_repo import StatusRepository
            self.central_opensql = StatusRepository(
                cfg.sql_host, cfg.sql_port, cfg.sql_user, cfg.sql_password,
                cfg.sql_schema, cfg.sql_status_table,
            )
        else:
            self.central_opensql = None
        self.hldf_audit = HldfAuditLogger(self.storage, cfg.audit_log_path, "SETS")
        self.storage.ensure_dirs(
            cfg.inbound_path, cfg.decrypted_path, cfg.inbound_archive_path,
            cfg.outbound_path, cfg.encrypted_path, cfg.audit_log_path,
        )

    def _central_control_create(self, *, s, f, run_uuid, task_chain_id, message=None):
        repo = getattr(self, "central_opensql", None)
        if repo is None:
            return
        try:
            repo.create_run(
                space_id=s.space_id, object_type="TASKCHAIN", tc_group_id=s.set_id,
                object_id=task_chain_id, run_uuid=run_uuid, kyma_status="STARTING",
                dsp_status="STARTING", message=message, object_nr=f.file_id,
            )
        except Exception:
            # Central steering-table reporting is best-effort and must never stop
            # file processing or DataSphere task-chain execution.
            LOG.exception("Could not create central OpenSQL control status")

    def _central_control_update(self, *, s, run_uuid, task_chain_id, kyma_status=None,
                                dsp_status=None, message=None, end=False):
        repo = getattr(self, "central_opensql", None)
        if repo is None:
            return
        try:
            repo.update_run(
                space_id=s.space_id, object_type="TASKCHAIN", tc_group_id=s.set_id,
                object_id=task_chain_id, run_uuid=run_uuid, kyma_status=kyma_status,
                dsp_status=dsp_status, message=message, end=end,
            )
        except Exception:
            LOG.exception("Could not update central OpenSQL control status")

    @staticmethod
    def _name(item):
        if isinstance(item, str):
            return item.rsplit("/", 1)[-1]
        return str(item.get("name") or item.get("path") or "").rsplit("/", 1)[-1]

    def initialize_today_sets(self):
        # In manual/emergency mode only files actually present in HDLF are registered.
        # This prevents creation of unrelated MISSING rows from the normal delivery schedule.
        if self._schedule_bypass_active():
            return
        today = self.model.today()
        for s in self.model.sets:
            active = self.model.active_required_files(s, today)
            # Do not create empty daily rows for monthly-only sets. Such rows would
            # otherwise become artificial predecessors and block the next real run.
            if not active:
                continue
            self.repo.ensure_set(s.set_id, today, today - timedelta(days=1), len(active))
            for f in active:
                self.repo.ensure_expected_file(s.set_id, today, f.file_id, f.role, f.required_mode)

    def _assign_set_date(self, s, f, extraction_date, delivery_date):
        open_date = self.repo.oldest_open_missing_set(s.set_id, f.file_id)
        if open_date and open_date < delivery_date and self.model.extraction_date_valid(extraction_date, open_date):
            return open_date
        return delivery_date

    @staticmethod
    def _retriable(exc: Exception) -> bool:
        if isinstance(exc, DataSphereHTTPError):
            return exc.retriable
        return isinstance(exc, (requests.Timeout, requests.ConnectionError))

    def _audit(self, **kwargs):
        # HDLF audit is always active and independent of central OpenSQL status reporting.
        try:
            self.hldf_audit.write(**kwargs)
        except Exception:
            LOG.exception("Could not write HDLF audit event")

        # Detailed OpenSQL audit is optional. In Phase 1 no hdbcli connection is made.
        audit_repo = getattr(self, "audit", None)
        if audit_repo is not None:
            try:
                audit_repo.write(**kwargs)
            except Exception:
                LOG.exception("Could not write OpenSQL audit event")

    def _logical_inbound_name(self, source_name: str) -> str | None:
        """Return the business filename used for matching/output.

        When DONE-prefix gating is enabled, files without the configured prefix are
        ignored because they may still be uploading to HDLF. The prefix is removed
        only logically; the source path still points to the physical DONE_* file.
        """
        if not self.cfg.inbound_done_prefix_enabled:
            return source_name
        prefix = self.cfg.inbound_done_prefix or "DONE_"
        if not source_name.startswith(prefix):
            return None
        logical = source_name[len(prefix):]
        return logical or None



    @staticmethod
    def _is_duplicate_inbound_name(name: str) -> bool:
        return bool(re.search(r"__DUP_[0-9A-Fa-f]{8}(?=\.gpg$)", str(name or "")))

    def _drop_duplicate_inbound(self, item, source_name: str):
        src = self._remote_path(item, source_name)
        try:
            self.storage.delete_file(src)
            LOG.info("Duplicate inbound file dropped: %s", source_name)
            self._audit(run_uuid=str(uuid.uuid4()), process_type="DUPLICATE_FILE_DROPPED", status="SUCCESS",
                        message=source_name, details={"file_name": source_name, "source_path": src})
            return True
        except Exception as exc:
            LOG.exception("Could not drop duplicate inbound file %s", source_name)
            self._audit(run_uuid=str(uuid.uuid4()), process_type="DUPLICATE_FILE_DROP_FAILED", status="ERROR",
                        message=source_name, error_code="DELETE_FAILED", error_message=str(exc),
                        details={"file_name": source_name, "source_path": src})
            return False

    def _schedule_bypass_active(self) -> bool:
        cfg = getattr(self, "cfg", None)
        return bool(getattr(cfg, "manual_ingest_mode", False) or not getattr(cfg, "schedule_enforcement_enabled", True))

    def _audit_schedule_bypass(self, *, source_name, logical_name, s, f, set_date):
        mode = "MANUAL_INGEST_MODE" if getattr(self.cfg, "manual_ingest_mode", False) else "SCHEDULE_ENFORCEMENT_DISABLED"
        self._audit(
            run_uuid=str(uuid.uuid4()), set_id=s.set_id, set_date=set_date, file_id=f.file_id,
            process_type="SCHEDULE_BYPASS", status="WARNING",
            message=f"{source_name} processed with schedule bypass ({mode})",
            details={
                "file_name": source_name,
                "logical_name": logical_name,
                "bypass_mode": mode,
            },
        )

    def _archive_inbound(self, item, source_name: str, *, reason: str, logical_name: str | None = None, set_id=None, set_date=None, file_id=None):
        enabled = self.cfg.archive_unscheduled_files if reason == "FILE_NOT_SCHEDULED" else self.cfg.archive_unknown_files
        run_uuid = str(uuid.uuid4())
        src = self._remote_path(item, source_name)
        target = self.cfg.inbound_archive_path.rstrip("/") + "/" + source_name
        archived = False
        archive_error = None
        if enabled:
            try:
                self.storage.mkdirs(self.cfg.inbound_archive_path)
                if self.storage.exists(target):
                    stem, dot, ext = source_name.rpartition(".")
                    suffix = uuid.uuid4().hex[:8]
                    alt = (stem + "__DUP_" + suffix + (dot + ext if dot else "")) if stem else (source_name + "__DUP_" + suffix)
                    target = self.cfg.inbound_archive_path.rstrip("/") + "/" + alt
                apply_remote_lifecycle(self.storage, src, "ARCHIVE", archive_target=target)
                archived = True
            except Exception as exc:
                archive_error = str(exc)
                LOG.exception("Could not archive %s", source_name)
        self._audit(
            run_uuid=run_uuid, set_id=set_id, set_date=set_date, file_id=file_id,
            process_type=reason, status="WARNING",
            message=f"{source_name} received but not scheduled/known for this processing date",
            error_code="ARCHIVE_FAILED" if archive_error else None, error_message=archive_error,
            details={"file_name": source_name, "logical_name": logical_name, "archived": archived, "archive_target": target if archived else None},
        )
        return archived

    @staticmethod
    def _candidate_sort_key(candidate):
        # For configured FULL/DELTA pairs on the monthly processing day, all FULL
        # task chains must finish before any paired DELTA task chain is started.
        f = candidate[3]
        mode = str(candidate[7]).upper()
        paired = bool(getattr(f, "pair_id", None))
        if paired and mode == "FULL":
            priority = 0
        elif paired and mode == "DELTA":
            priority = 1
        else:
            priority = 2
        return (candidate[4], candidate[2].set_id, priority, getattr(f, "pair_id", "") or f.file_id, candidate[1])

    def _paired_full_file(self, set_def, delta_file, set_date):
        pair_id = getattr(delta_file, "pair_id", None)
        if not pair_id or str(delta_file.required_mode).upper() != "DELTA":
            return None
        for candidate in self.model.active_required_files(set_def, set_date):
            if (getattr(candidate, "pair_id", None) == pair_id
                    and str(candidate.required_mode).upper() == "FULL"):
                return candidate
        return None

    def ingest_available_files(self):
        self.initialize_today_sets()
        delivery_date = self.model.today()
        candidates = []

        for item in self.storage.list_files(self.cfg.inbound_path):
            source_name = self._name(item)
            if source_name.endswith(".part"):
                continue

            if getattr(self.cfg, "drop_duplicate_inbound_files", True) and self._is_duplicate_inbound_name(source_name):
                self._drop_duplicate_inbound(item, source_name)
                continue

            logical_name = self._logical_inbound_name(source_name)
            if logical_name is None:
                LOG.debug("Ignoring inbound file without completion prefix: %s", source_name)
                continue
            if not logical_name.lower().endswith(".gpg"):
                continue

            known_match = None
            for s in self.model.sets:
                for f in (s.required_files + s.optional_files):
                    try:
                        parsed = f.parse(logical_name, default_extraction_date=delivery_date)
                    except Exception as exc:
                        LOG.error("Could not parse %s for %s: %s", logical_name, f.file_id, exc)
                        continue
                    if not parsed or parsed["mode"] != f.required_mode:
                        continue
                    set_date = self._assign_set_date(s, f, parsed["extraction_date"], delivery_date)
                    known_match = (s, f, parsed, set_date)
                    break
                if known_match:
                    break

            if known_match is None:
                LOG.warning("Unknown inbound file: %s", logical_name)
                self._archive_inbound(item, source_name, reason="UNKNOWN_FILE", logical_name=logical_name)
                continue

            s, f, parsed, set_date = known_match
            if not self._schedule_bypass_active() and f not in self.model.all_active_files(s, set_date):
                LOG.warning("File %s is known but not scheduled for %s", logical_name, set_date)
                self._archive_inbound(item, source_name, reason="FILE_NOT_SCHEDULED", logical_name=logical_name,
                                      set_id=s.set_id, set_date=set_date, file_id=f.file_id)
                continue
            if self._schedule_bypass_active():
                self._audit_schedule_bypass(
                    source_name=source_name, logical_name=logical_name, s=s, f=f, set_date=set_date
                )

            extraction_date_validation_enabled = getattr(self.cfg, "extraction_date_validation_enabled", True)
            if extraction_date_validation_enabled:
                if not self.model.extraction_date_valid(parsed["extraction_date"], set_date):
                    LOG.error("Invalid extraction date for %s: %s / set=%s", logical_name, parsed["extraction_date"], set_date)
                    self._audit(set_id=s.set_id, set_date=set_date, file_id=f.file_id, process_type="INVALID_EXTRACTION_DATE",
                                status="WARNING", message=logical_name, details={"extraction_date": str(parsed["extraction_date"])})
                    continue
            else:
                LOG.warning(
                    "Extraction date validation disabled; accepting %s: extraction=%s / set=%s",
                    logical_name, parsed["extraction_date"], set_date
                )
                self._audit(
                    set_id=s.set_id, set_date=set_date, file_id=f.file_id,
                    process_type="EXTRACTION_DATE_VALIDATION_BYPASS", status="WARNING",
                    message=logical_name,
                    details={"extraction_date": str(parsed["extraction_date"]), "set_date": str(set_date)},
                )
            if self.repo.file_success_exists(s.set_id, set_date, f.file_id):
                LOG.info("Already processed %s for %s/%s", f.file_id, s.set_id, set_date)
                continue
            candidates.append((item, source_name, s, f, set_date, delivery_date, parsed["extraction_date"], parsed["mode"], logical_name))

        candidates.sort(key=self._candidate_sort_key)

        manual_groups = {}
        if self._schedule_bypass_active():
            # Register only the files actually found in this emergency/manual batch.
            for candidate in candidates:
                _, _, s, f, set_date, _, _, _, _ = candidate
                manual_groups.setdefault((s.set_id, set_date), {"set": s, "files": {}})["files"][f.file_id] = f
            for (_, set_date), group in manual_groups.items():
                s = group["set"]
                files = list(group["files"].values())
                self.repo.ensure_set(s.set_id, set_date, set_date - timedelta(days=1), len(files))
                for f in files:
                    self.repo.ensure_expected_file(s.set_id, set_date, f.file_id, f.role, f.required_mode)

        current_batch = {(c[2].set_id, c[4], getattr(c[3], "pair_id", None), str(c[7]).upper()) for c in candidates}

        for candidate in candidates:
            item, source_name, s, f, set_date, delivery_date, extraction_date, mode, logical_name = candidate
            full_file = self._paired_full_file(s, f, set_date)
            if self._schedule_bypass_active() and getattr(f, "pair_id", None) and str(mode).upper() == "DELTA":
                # Manual mode bypasses only scheduling. If a paired FULL is part of the
                # same manual batch it must still complete first. A DELTA supplied alone
                # is allowed as an explicit emergency/manual action.
                pair_present = (s.set_id, set_date, f.pair_id, "FULL") in current_batch
                if not pair_present:
                    full_file = None
                elif full_file is None:
                    for possible in (s.required_files + s.optional_files):
                        if getattr(possible, "pair_id", None) == f.pair_id and str(possible.required_mode).upper() == "FULL":
                            full_file = possible
                            break
            if full_file and not self._full_ready_for_delta(s.set_id, set_date, full_file.file_id):
                LOG.warning("Deferring DELTA %s for pair %s: FULL %s is not completed", f.file_id, f.pair_id, full_file.file_id)
                continue
            try:
                self._process_file(item, source_name, logical_name, s, f, set_date, delivery_date, extraction_date, mode)
            except Exception:
                LOG.exception("File processing failed for %s; continuing with remaining files", source_name)

        if self._schedule_bypass_active():
            for (_, set_date), group in manual_groups.items():
                s = group["set"]
                ids = list(group["files"].keys())
                self._evaluate_file_ids(s, set_date, ids, manual=True)
        else:
            for s in self.model.sets:
                for d in [delivery_date - timedelta(days=1), delivery_date]:
                    self.evaluate_set(s, d)

    def _remote_path(self, item, name):
        if isinstance(item, str) and item.startswith("/"):
            return item
        if isinstance(item, dict) and item.get("path"):
            return item["path"]
        return self.cfg.inbound_path.rstrip("/") + "/" + name

    def _full_ready_for_delta(self, set_id, set_date, full_file_id):
        """Return True when a paired FULL may release its DELTA.

        DECRYPTED_ONLY is deliberately accepted only while the DataSphere
        taskchain API is disabled. It is not treated as a globally completed
        business status.
        """
        if self.repo.file_success_exists(set_id, set_date, full_file_id):
            return True
        if not self.cfg.datasphere_taskchain_api_enabled:
            status_getter = getattr(self.repo, "file_status", None)
            status = status_getter(set_id, set_date, full_file_id) if status_getter else None
            return str(status or "").upper() == "DECRYPTED_ONLY"
        return False

    def _taskchain_meta(self, s, f):
        cat = self.taskchains.get(s.set_id, f.file_id) or {}
        task_chain_id = f.task_chain_id or cat.get("task_chain_id")
        endpoint = f.task_chain_endpoint or cat.get("endpoint")
        return task_chain_id, endpoint

    def _process_file(self, item, source_name, logical_name, s, f, set_date, delivery_date, extraction_date, mode):
        # v4.18 supersedes the direct decode_base64_csv call with prepare_csv_payload; validation equivalent: validate_utf8_file(transformed, allow_bom=False).
        if not self.cfg.inbound_gpg_passphrase:
            raise RuntimeError("INBOUND_GPG_PASSPHRASE is missing")
        run_uuid = str(uuid.uuid4())
        self.repo.upsert_file(
            set_id=s.set_id, set_date=set_date, file_id=f.file_id, run_uuid=run_uuid,
            delivery_date=delivery_date, extraction_date=extraction_date, file_name=logical_name,
            file_role=f.role, file_mode=mode, file_status="RECEIVED",
        )
        self._audit(
            run_uuid=run_uuid, set_id=s.set_id, set_date=set_date, file_id=f.file_id,
            process_type="FILE_RECEIVED", status="SUCCESS", message=f"{source_name} -> {logical_name}",
        )

        try:
            with tempfile.TemporaryDirectory(prefix="kyma-file-") as td:
                enc = str(Path(td) / source_name)
                plain_name = logical_name[:-4]
                plain = str(Path(td) / plain_name)
                log_stage(LOG, "DOWNLOAD_START", extra=f"remote={self._remote_path(item, source_name)}")
                self.storage.download(self._remote_path(item, source_name), enc)
                log_stage(LOG, "DOWNLOAD_DONE", path=enc)
                self.repo.update_file_status(
                    set_id=s.set_id, set_date=set_date, file_id=f.file_id,
                    run_uuid=run_uuid, status="DECRYPTING",
                )
                self._audit(
                    run_uuid=run_uuid, set_id=s.set_id, set_date=set_date, file_id=f.file_id,
                    process_type="GPG_DECRYPT", status="STARTED", message=source_name,
                )
                log_stage(LOG, "DECRYPT_START", path=enc)
                decrypt_symmetric(enc, plain, self.cfg.inbound_gpg_passphrase)
                log_stage(LOG, "DECRYPT_DONE", path=plain)

                upload_source = plain
                row_count = None
                base64_decision = None
                if self.cfg.use_base64_decode and plain_name.lower().endswith(".csv"):
                    transformed = str(Path(td) / ("decoded_" + plain_name))
                    upload_source, row_count, base64_decision = prepare_csv_payload(
                        plain, transformed,
                        mode=getattr(self.cfg, "base64_mode", "AUTO_STRICT"),
                        fallback_fields=getattr(self.cfg, "base64_fallback_fields", ()),
                    )
                    if upload_source != plain:
                        validate_utf8_file(upload_source, allow_bom=False)
                        try:
                            Path(plain).unlink()
                        except OSError:
                            pass
                    else:
                        validate_utf8_file(plain, allow_bom=False)
                else:
                    validate_utf8_file(plain, allow_bom=False)

                decrypted_name = build_decrypted_filename(plain_name)
                target_remote = self.cfg.decrypted_path.rstrip("/") + "/" + decrypted_name
                log_stage(LOG, "UPLOAD_START", path=upload_source, extra=f"remote={target_remote}")
                self.storage.upload(upload_source, target_remote)
                log_stage(LOG, "UPLOAD_DONE", path=upload_source, extra=f"remote={target_remote}")
                self.repo.update_file_status(
                    set_id=s.set_id, set_date=set_date, file_id=f.file_id,
                    run_uuid=run_uuid, status="DECRYPTED",
                )
                self._audit(
                    run_uuid=run_uuid, set_id=s.set_id, set_date=set_date, file_id=f.file_id,
                    process_type="GPG_DECRYPT", status="SUCCESS", message=decrypted_name,
                    details={"source_plain_file": plain_name, "decrypted_file": decrypted_name,
                             "row_count": row_count, "base64_decode": bool(self.cfg.use_base64_decode),
                             "base64_mode": getattr(self.cfg, "base64_mode", "AUTO_STRICT"),
                             "csv_rewritten": bool(base64_decision.rewrite_required) if base64_decision else False},
                )

                lifecycle = normalize_lifecycle(getattr(self.cfg, "inbound_success_lifecycle", "KEEP"))
                if lifecycle != "KEEP":
                    archive_target = self.cfg.inbound_archive_path.rstrip("/") + "/" + source_name
                    result = apply_remote_lifecycle(self.storage, self._remote_path(item, source_name), lifecycle, archive_target=archive_target, temp_dir=td)
                    self._audit(
                        run_uuid=run_uuid, set_id=s.set_id, set_date=set_date, file_id=f.file_id,
                        process_type="INBOUND_LIFECYCLE", status="SUCCESS", message=f"{lifecycle}: {source_name}",
                        details={"action": lifecycle, "archive_target": result.archive_target,
                                 "size": result.integrity.size if result.integrity else None,
                                 "sha256": result.integrity.sha256 if result.integrity else None},
                    )

            if not self.cfg.datasphere_taskchain_api_enabled:
                self.repo.update_file_status(
                    set_id=s.set_id, set_date=set_date, file_id=f.file_id,
                    run_uuid=run_uuid, status="DECRYPTED_ONLY", end=True,
                )
                LOG.info(
                    "DataSphere taskchain API disabled; file left for inspection: %s/%s",
                    self.cfg.decrypted_path.rstrip("/"), decrypted_name,
                )
                self._audit(
                    run_uuid=run_uuid, set_id=s.set_id, set_date=set_date, file_id=f.file_id,
                    process_type="TASKCHAIN_API_SKIPPED", status="SUCCESS",
                    message="DataSphere taskchain API disabled; processing stopped after decrypted HDLF upload",
                    details={"source_plain_file": plain_name, "decrypted_file": decrypted_name},
                )
                return

            task_chain_id, endpoint = self._taskchain_meta(s, f)
            if not task_chain_id:
                self.repo.update_file_status(
                    set_id=s.set_id, set_date=set_date, file_id=f.file_id,
                    run_uuid=run_uuid, status="COMPLETED", end=True,
                )
                self._audit(
                    run_uuid=run_uuid, set_id=s.set_id, set_date=set_date, file_id=f.file_id,
                    process_type="FILE_PROCESS", status="SUCCESS",
                    message="No DataSphere task chain configured",
                )
                return

            self._run_file_taskchain(
                s=s, f=f, run_uuid=run_uuid, set_date=set_date,
                task_chain_id=task_chain_id, endpoint=endpoint,
            )
            self.repo.update_file_status(
                set_id=s.set_id, set_date=set_date, file_id=f.file_id,
                run_uuid=run_uuid, status="COMPLETED", end=True,
            )
            self._audit(
                run_uuid=run_uuid, set_id=s.set_id, set_date=set_date, file_id=f.file_id,
                process_type="FILE_PROCESS", status="SUCCESS", task_chain_id=task_chain_id,
            )
        except Exception as exc:
            self.repo.update_file_status(
                set_id=s.set_id, set_date=set_date, file_id=f.file_id, run_uuid=run_uuid,
                status="FAILED", error_message=str(exc), end=True,
            )
            self._audit(
                run_uuid=run_uuid, set_id=s.set_id, set_date=set_date, file_id=f.file_id,
                process_type="FILE_PROCESS", status="FAILED",
                error_code=type(exc).__name__, error_message=str(exc),
            )
            raise

    def _run_file_taskchain(self, *, s, f, run_uuid, set_date, task_chain_id, endpoint):
        if not self.cfg.datasphere_taskchain_api_enabled or self.dsp is None:
            raise RuntimeError("DataSphere taskchain API is disabled")
        process_uuid = self.process_repo.create(
            run_uuid=run_uuid, set_id=s.set_id, set_date=set_date,
            file_id=f.file_id, task_chain_id=task_chain_id,
        )
        self.process_repo.update(process_uuid, status="STARTING")
        self._central_control_create(
            s=s, f=f, run_uuid=run_uuid, task_chain_id=task_chain_id,
            message="DataSphere task chain starting",
        )

        run = None
        for attempt in range(self.cfg.max_retries + 1):
            started = time.monotonic()
            self._audit(
                run_uuid=run_uuid, set_id=s.set_id, set_date=set_date, file_id=f.file_id,
                process_type="DSP_START_API", status="STARTED", task_chain_id=task_chain_id,
                http_method="POST", api_endpoint=endpoint, retry_no=attempt,
            )
            try:
                run = self.dsp.run_task_chain(
                    s.space_id, task_chain_id,
                    {"RUN_UUID": run_uuid, "SET_ID": s.set_id, "SET_DATE": set_date.isoformat(), "FILE_ID": f.file_id},
                )
                duration = int((time.monotonic() - started) * 1000)
                self.process_repo.update(
                    process_uuid, status="STARTED", dsp_log_id=run.log_id,
                    http_status=202, retry_count=attempt,
                )
                self._central_control_update(
                    s=s, run_uuid=run_uuid, task_chain_id=task_chain_id,
                    kyma_status="PROCESSING", dsp_status="STARTED",
                    message=f"Task chain started; logId={run.log_id}",
                )
                self._audit(
                    run_uuid=run_uuid, set_id=s.set_id, set_date=set_date, file_id=f.file_id,
                    process_type="DSP_START_API", status="SUCCESS", task_chain_id=task_chain_id,
                    dsp_log_id=run.log_id, http_method="POST", http_status=202,
                    api_endpoint=endpoint, retry_no=attempt, duration_ms=duration,
                )
                break
            except Exception as exc:
                duration = int((time.monotonic() - started) * 1000)
                http_status = getattr(exc, "status_code", None)
                can_retry = attempt < self.cfg.max_retries and self._retriable(exc)
                status = "RETRY" if can_retry else "FAILED"
                self.process_repo.update(
                    process_uuid, status="RETRYING" if can_retry else "FAILED",
                    http_status=http_status, retry_count=attempt,
                    error_code=type(exc).__name__, error_message=str(exc), end=not can_retry,
                )
                self._audit(
                    run_uuid=run_uuid, set_id=s.set_id, set_date=set_date, file_id=f.file_id,
                    process_type="DSP_START_API", status=status, task_chain_id=task_chain_id,
                    http_method="POST", http_status=http_status, api_endpoint=endpoint,
                    retry_no=attempt, duration_ms=duration,
                    error_code=type(exc).__name__, error_message=str(exc),
                )
                if not can_retry:
                    self._central_control_update(
                        s=s, run_uuid=run_uuid, task_chain_id=task_chain_id,
                        kyma_status="FAILED", dsp_status="FAILED",
                        message=str(exc), end=True,
                    )
                    raise
                time.sleep(self.cfg.retry_wait_seconds * (attempt + 1))

        if run is None:
            raise RuntimeError("DataSphere task chain start returned no run")

        self._poll_taskchain(
            s=s, f=f, run_uuid=run_uuid, set_date=set_date,
            process_uuid=process_uuid, task_chain_id=task_chain_id,
            log_id=run.log_id,
        )

    def _poll_taskchain(self, *, s, f, run_uuid, set_date, process_uuid, task_chain_id, log_id):
        poll_started = time.monotonic()
        deadline = poll_started + self.cfg.poll_timeout_seconds
        last_status = None
        poll_no = 0
        status_endpoint = f"{self.cfg.dsp_host.rstrip('/')}/api/v1/datasphere/tasks/logs/{s.space_id}/{log_id}"

        while time.monotonic() < deadline:
            status = None
            for attempt in range(self.cfg.max_retries + 1):
                started = time.monotonic()
                try:
                    status = self.dsp.get_task_status(s.space_id, log_id)
                    duration = int((time.monotonic() - started) * 1000)
                    self._audit(
                        run_uuid=run_uuid, set_id=s.set_id, set_date=set_date, file_id=f.file_id,
                        process_type="DSP_STATUS_API", status="SUCCESS", task_chain_id=task_chain_id,
                        dsp_log_id=log_id, http_method="GET", http_status=200,
                        api_endpoint=status_endpoint, retry_no=attempt, duration_ms=duration,
                        message=status,
                    )
                    break
                except Exception as exc:
                    duration = int((time.monotonic() - started) * 1000)
                    http_status = getattr(exc, "status_code", None)
                    can_retry = attempt < self.cfg.max_retries and self._retriable(exc)
                    self._audit(
                        run_uuid=run_uuid, set_id=s.set_id, set_date=set_date, file_id=f.file_id,
                        process_type="DSP_STATUS_API", status="RETRY" if can_retry else "FAILED",
                        task_chain_id=task_chain_id, dsp_log_id=log_id, http_method="GET",
                        http_status=http_status, api_endpoint=status_endpoint, retry_no=attempt,
                        duration_ms=duration, error_code=type(exc).__name__, error_message=str(exc),
                    )
                    if not can_retry:
                        self.process_repo.update(
                            process_uuid, status="FAILED", http_status=http_status,
                            retry_count=attempt, error_code=type(exc).__name__,
                            error_message=str(exc), end=True,
                        )
                        raise
                    self.process_repo.update(process_uuid, status="RETRYING", retry_count=attempt)
                    time.sleep(self.cfg.retry_wait_seconds * (attempt + 1))

            if status is None:
                raise RuntimeError("No task status returned")

            poll_no += 1
            elapsed = int(time.monotonic() - poll_started)
            remaining = max(0, self.cfg.poll_timeout_seconds - elapsed)
            LOG.info(
                "DataSphere taskchain poll: taskChain=%s logId=%s poll=%s status=%s elapsed=%ss remaining=%ss",
                task_chain_id, log_id, poll_no, status, elapsed, remaining,
            )

            if status != last_status:
                self.process_repo.update(process_uuid, status=status, dsp_log_id=log_id)
                self._central_control_update(
                    s=s, run_uuid=run_uuid, task_chain_id=task_chain_id,
                    kyma_status="PROCESSING", dsp_status=status,
                    message=f"Task-chain status changed to {status}",
                )
                self._audit(
                    run_uuid=run_uuid, set_id=s.set_id, set_date=set_date, file_id=f.file_id,
                    process_type="DSP_TASK_STATUS", status=status, task_chain_id=task_chain_id,
                    dsp_log_id=log_id, message=f"Task-chain status changed to {status}",
                )
                last_status = status

            if status in SUCCESS_TASK_STATUSES:
                self.process_repo.update(process_uuid, status="SUCCESS", dsp_log_id=log_id, end=True)
                self._central_control_update(
                    s=s, run_uuid=run_uuid, task_chain_id=task_chain_id,
                    kyma_status="COMPLETED", dsp_status=status,
                    message="DataSphere task chain completed successfully", end=True,
                )
                LOG.info("DataSphere taskchain completed: taskChain=%s logId=%s status=%s elapsed=%ss", task_chain_id, log_id, status, int(time.monotonic() - poll_started))
                return status
            if status in FAILED_TASK_STATUSES:
                msg = f"DataSphere task chain {log_id} ended with status {status}"
                self.process_repo.update(
                    process_uuid, status="FAILED", dsp_log_id=log_id,
                    error_code="DSP_TASK_FAILED", error_message=msg, end=True,
                )
                self._central_control_update(
                    s=s, run_uuid=run_uuid, task_chain_id=task_chain_id,
                    kyma_status="FAILED", dsp_status=status, message=msg, end=True,
                )
                self._audit(
                    run_uuid=run_uuid, set_id=s.set_id, set_date=set_date, file_id=f.file_id,
                    process_type="DSP_TASK_STATUS", status="FAILED", task_chain_id=task_chain_id,
                    dsp_log_id=log_id, error_code="DSP_TASK_FAILED", error_message=msg,
                )
                raise RuntimeError(msg)

            time.sleep(self.cfg.poll_interval_seconds)

        msg = f"Timeout while waiting for DataSphere task chain logId={log_id}; last={last_status}"
        self.process_repo.update(
            process_uuid, status="TIMEOUT", dsp_log_id=log_id,
            error_code="DSP_TIMEOUT", error_message=msg, end=True,
        )
        self._central_control_update(
            s=s, run_uuid=run_uuid, task_chain_id=task_chain_id,
            kyma_status="FAILED", dsp_status="TIMEOUT", message=msg, end=True,
        )
        self._audit(
            run_uuid=run_uuid, set_id=s.set_id, set_date=set_date, file_id=f.file_id,
            process_type="DSP_TASK_STATUS", status="TIMEOUT", task_chain_id=task_chain_id,
            dsp_log_id=log_id, error_code="DSP_TIMEOUT", error_message=msg,
        )
        raise TimeoutError(msg)

    def _evaluate_file_ids(self, s, set_date, ids, *, manual=False):
        if not ids:
            return "NOT_REQUIRED"
        summary = self.repo.summarize_set(s.set_id, set_date, ids)
        if summary["failed"] > 0:
            status, msg = "FAILED", "At least one required file/process failed"
        elif summary["missing"] > 0:
            status = "BLOCKED" if summary["received"] > 0 else "WAITING"
            msg = f'{summary["missing"]} required file(s) not completed'
        elif not self.repo.predecessor_completed(s.set_id, set_date):
            status, msg = "WAITING_PREDECESSOR", "All files completed; predecessor set not completed"
        elif not self.repo.dependencies_completed(s.depends_on_sets, set_date):
            status, msg = "WAITING_DEPENDENCY", "Dependency set not completed"
        else:
            status = "COMPLETED"
            msg = "Manual ingest files completed" if manual else "All required file task chains completed"
        self.repo.update_set(s.set_id, set_date, status, summary, msg, end=(status == "COMPLETED"))
        self._audit(
            set_id=s.set_id, set_date=set_date, process_type="SET_STATUS",
            status=status, message=msg,
            details={"summary": summary, "manual_ingest": manual},
        )
        return status

    def evaluate_set(self, s, set_date):
        active = self.model.active_required_files(s, set_date)
        ids = [f.file_id for f in active]
        return self._evaluate_file_ids(s, set_date, ids, manual=False)
