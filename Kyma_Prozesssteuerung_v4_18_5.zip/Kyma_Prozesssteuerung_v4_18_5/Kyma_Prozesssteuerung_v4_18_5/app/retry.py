from __future__ import annotations
import time
from collections.abc import Callable

RETRIABLE_HTTP = {429, 500, 502, 503, 504}

def retry_call(fn: Callable, max_retries: int, wait_seconds: int, is_retriable: Callable[[Exception], bool]):
    last = None
    for attempt in range(max_retries + 1):
        try:
            return fn()
        except Exception as exc:
            last = exc
            if attempt >= max_retries or not is_retriable(exc):
                raise
            time.sleep(wait_seconds * (attempt + 1))
    raise last
