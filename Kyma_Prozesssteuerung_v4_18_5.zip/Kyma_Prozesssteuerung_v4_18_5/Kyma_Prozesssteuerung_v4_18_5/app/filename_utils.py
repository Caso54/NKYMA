from __future__ import annotations


def build_decrypted_filename(filename: str) -> str:
    """Build the fixed DataSphere-facing filename for /inbound/decrypted.

    Avaloq inbound names use the marker ``_ACP`` before delivery/version/timestamp
    metadata. DataSphere expects a stable CSV name, so everything from the first
    ``_ACP`` onward is removed.

    Examples:
      AVQ_SAP_NAME_INTL_ACP_2026_09_25_08_16_55.csv.gpg -> AVQ_SAP_NAME_INTL.csv
      AVQ_SAP_BAL_DELTA_ACP_V01A_2026_09_26_04_37_46.csv.gpg -> AVQ_SAP_BAL_DELTA.csv

    Names without ``_ACP`` keep their previous decrypted name.
    """
    name = str(filename).rsplit("/", 1)[-1]
    if name.lower().endswith(".gpg"):
        name = name[:-4]

    marker_pos = name.find("_ACP")
    if marker_pos < 0:
        return name

    prefix = name[:marker_pos]
    # Inbound payloads are CSVs. Keep the stable DataSphere contract explicit.
    return prefix + ".csv"
