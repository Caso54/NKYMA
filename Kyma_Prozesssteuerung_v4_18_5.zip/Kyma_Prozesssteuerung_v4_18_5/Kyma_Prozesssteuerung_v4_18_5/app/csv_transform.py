from __future__ import annotations
import base64
import csv
import logging
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable
from .utf8_utils import UTF8, UTF8_SIG
from .performance import log_stage

LOG = logging.getLogger("kyma.csv")
DATE_VALUE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
TIMESTAMP_VALUE_RE = re.compile(r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$")
BASE64_RE = re.compile(r"^[A-Za-z0-9+/]*={0,2}$")
PROGRESS_ROWS = 100_000
AUTO_SAMPLE_ROWS = 10_000


def _canonical_b64(value: str) -> bool:
    """Return True only for canonical standard Base64 text.

    This intentionally rejects malformed/loosely padded strings so AUTO_STRICT does
    not reinterpret ordinary source values merely because b64decode happens to accept
    them.
    """
    if not value or len(value) % 4 != 0 or not BASE64_RE.fullmatch(value):
        return False
    try:
        raw = base64.b64decode(value, validate=True)
    except Exception:
        return False
    return base64.b64encode(raw).decode("ascii") == value


def _decode_candidate(value: str) -> str:
    if value == "":
        return value
    if DATE_VALUE_RE.fullmatch(value) or TIMESTAMP_VALUE_RE.fullmatch(value):
        return value
    if not _canonical_b64(value):
        return value
    try:
        raw = base64.b64decode(value, validate=True)
        decoded = raw.decode("utf-8")
        if decoded and all(ch.isprintable() or ch in "\r\n\t" for ch in decoded):
            return decoded
    except Exception:
        pass
    return value


def _is_strong_base64(value: str) -> bool:
    """Conservative detector used by AUTO_STRICT.

    A value must be canonical Base64, produce printable UTF-8 and carry at least one
    strong encoding signal (padding, +, /, or a meaningful decoded value). Short
    numeric encodings such as ``MzY=`` remain supported because padding is present.
    """
    decoded = _decode_candidate(value)
    if decoded == value:
        return False
    return value.endswith("=") or "+" in value or "/" in value or len(value) >= 8


def _normalize_fields(fields: Iterable[str] | None) -> set[str]:
    return {str(x).strip().upper() for x in (fields or []) if str(x).strip()}


@dataclass(frozen=True)
class CsvTransformDecision:
    rewrite_required: bool
    decode_fields: tuple[str, ...]
    sampled_rows: int
    reason: str


def analyze_base64_csv(
    src: str,
    *,
    delimiter: str = ";",
    fallback_fields: Iterable[str] | None = None,
    sample_rows: int = AUTO_SAMPLE_ROWS,
) -> CsvTransformDecision:
    """Inspect a bounded number of rows without rewriting the file.

    AUTO_STRICT selects a column automatically only when all observed non-empty,
    non-date values in that column are strong Base64 candidates. Configured fallback
    fields are always selected when present in the header. The scan is streaming and
    bounded by ``sample_rows`` rows.
    """
    fallback = _normalize_fields(fallback_fields)
    log_stage(LOG, "BASE64_ANALYZE_START", path=src)
    with open(src, "r", encoding=UTF8_SIG, errors="strict", newline="") as fin:
        reader = csv.reader(fin, delimiter=delimiter)
        try:
            header = next(reader)
        except StopIteration:
            return CsvTransformDecision(False, (), 0, "EMPTY_FILE")
        header_u = [h.strip().upper() for h in header]
        forced_idx = {i for i, name in enumerate(header_u) if name in fallback}
        seen = [0] * len(header)
        strong = [0] * len(header)
        sampled = 0
        for row in reader:
            sampled += 1
            for i, value in enumerate(row[:len(header)]):
                if i in forced_idx or value == "" or DATE_VALUE_RE.fullmatch(value) or TIMESTAMP_VALUE_RE.fullmatch(value):
                    continue
                seen[i] += 1
                if _is_strong_base64(value):
                    strong[i] += 1
            if sampled >= sample_rows:
                break

    auto_idx = {
        i for i in range(len(header))
        if seen[i] > 0 and strong[i] == seen[i]
    }
    selected = forced_idx | auto_idx
    fields = tuple(header[i] for i in sorted(selected))
    reason = "NO_BASE64_DETECTED" if not selected else ("FALLBACK_OR_AUTO" if forced_idx else "AUTO_STRICT")
    log_stage(LOG, "BASE64_ANALYZE_DONE", path=src, rows=sampled, extra=f"decodeFields={','.join(fields) if fields else '-'}")
    return CsvTransformDecision(bool(selected), fields, sampled, reason)


def decode_base64_csv(
    src: str,
    dst: str,
    delimiter: str = ";",
    *,
    fields: Iterable[str] | None = None,
) -> int:
    """Transform a CSV one row at a time with bounded memory.

    When ``fields`` is provided, only named columns are decoded. With ``fields=None``
    legacy behavior is preserved and every field is considered.
    """
    Path(dst).parent.mkdir(parents=True, exist_ok=True)
    wanted = None if fields is None else _normalize_fields(fields)
    rows = 0
    log_stage(LOG, "CSV_TRANSFORM_START", path=src)
    with open(src, "r", encoding=UTF8_SIG, errors="strict", newline="") as fin, \
         open(dst, "w", encoding=UTF8, errors="strict", newline="") as fout:
        reader = csv.reader(fin, delimiter=delimiter)
        writer = csv.writer(fout, delimiter=delimiter, quoting=csv.QUOTE_MINIMAL, lineterminator="\n")
        try:
            header = next(reader)
        except StopIteration:
            return 0
        writer.writerow(header)
        if wanted is None:
            indexes = None
        else:
            indexes = {i for i, name in enumerate(header) if name.strip().upper() in wanted}
        rows = 1
        for row in reader:
            if indexes is None:
                out = [_decode_candidate(v) for v in row]
            else:
                out = [(_decode_candidate(v) if i in indexes else v) for i, v in enumerate(row)]
            writer.writerow(out)
            rows += 1
            if rows % PROGRESS_ROWS == 0:
                log_stage(LOG, "CSV_TRANSFORM_PROGRESS", path=src, rows=rows)
    data_rows = max(0, rows - 1)
    log_stage(LOG, "CSV_TRANSFORM_DONE", path=dst, rows=data_rows)
    return data_rows


def prepare_csv_payload(
    src: str,
    dst: str,
    *,
    mode: str = "AUTO_STRICT",
    fallback_fields: Iterable[str] | None = None,
    delimiter: str = ";",
) -> tuple[str, int | None, CsvTransformDecision]:
    """Return the file to upload, avoiding a rewrite when no transform is needed."""
    normalized = (mode or "AUTO_STRICT").strip().upper()
    if normalized in {"OFF", "DISABLED", "FALSE", "0", "NONE"}:
        decision = CsvTransformDecision(False, (), 0, "DISABLED")
        return src, None, decision
    if normalized in {"ALL", "ON", "ENABLED", "TRUE", "1", "LEGACY"}:
        rows = decode_base64_csv(src, dst, delimiter=delimiter)
        decision = CsvTransformDecision(True, (), 0, "LEGACY_ALL_FIELDS")
        return dst, rows, decision
    if normalized != "AUTO_STRICT":
        raise ValueError(f"Unsupported BASE64_MODE: {mode}")

    decision = analyze_base64_csv(src, delimiter=delimiter, fallback_fields=fallback_fields)
    if not decision.rewrite_required:
        return src, None, decision
    rows = decode_base64_csv(src, dst, delimiter=delimiter, fields=decision.decode_fields)
    return dst, rows, decision
