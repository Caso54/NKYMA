from __future__ import annotations

import codecs
import json
from pathlib import Path
from typing import Any

UTF8 = "utf-8"
UTF8_SIG = "utf-8-sig"
DEFAULT_CHUNK_SIZE = 8 * 1024 * 1024


def validate_utf8_file(path: str | Path, *, allow_bom: bool = True, chunk_size: int = DEFAULT_CHUNK_SIZE) -> None:
    """Validate UTF-8 incrementally with bounded memory.

    The previous implementation used ``Path.read_bytes()`` and therefore loaded the
    complete file into memory. This implementation keeps memory consumption bounded
    regardless of file size. A BOM is tolerated only when ``allow_bom`` is True.
    """
    p = Path(path)
    decoder = codecs.getincrementaldecoder(UTF8)(errors="strict")
    first = True
    with p.open("rb") as fh:
        while True:
            chunk = fh.read(chunk_size)
            if not chunk:
                break
            if first:
                first = False
                if chunk.startswith(b"\xef\xbb\xbf"):
                    if not allow_bom:
                        raise UnicodeError(f"UTF-8 BOM is not allowed: {p}")
                    chunk = chunk[3:]
            decoder.decode(chunk, final=False)
        decoder.decode(b"", final=True)


def read_utf8_text(path: str | Path, *, allow_bom: bool = True) -> str:
    """Read small configuration text as UTF-8.

    This helper intentionally remains whole-file because it is used for small JSON
    configuration files, not business payloads.
    """
    encoding = UTF8_SIG if allow_bom else UTF8
    return Path(path).read_text(encoding=encoding, errors="strict")


def write_utf8_text(path: str | Path, text: str) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text, encoding=UTF8, errors="strict", newline="")


def json_utf8_bytes(value: Any) -> bytes:
    """Serialize small API JSON payloads as explicit UTF-8 bytes."""
    return json.dumps(value, ensure_ascii=False, default=str, separators=(",", ":")).encode(UTF8)
