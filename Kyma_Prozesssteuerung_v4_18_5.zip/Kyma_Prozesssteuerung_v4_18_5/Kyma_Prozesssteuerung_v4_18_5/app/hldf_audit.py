from __future__ import annotations
import csv
import json
import logging
import tempfile
import threading
from datetime import datetime, timezone
from pathlib import Path

from .utf8_utils import UTF8

LOG = logging.getLogger("kyma.audit")

_FIELDS = [
    "TIMESTAMP_UTC", "RUN_UUID", "SET_ID", "SET_DATE", "FILE_ID",
    "PROCESS_TYPE", "STATUS", "MESSAGE", "TASK_CHAIN_ID", "DSP_LOG_ID",
    "HTTP_METHOD", "HTTP_STATUS", "API_ENDPOINT", "RETRY_NO", "DURATION_MS",
    "ERROR_CODE", "ERROR_MESSAGE", "DETAILS_JSON",
]


class HldfAuditLogger:
    """Always-on UTF-8 CSV audit persisted in HDLF.

    The current daily audit file is cached locally for the lifetime of the pod. This
    avoids downloading the same growing HDLF audit file before every event. Each event
    is still uploaded immediately, preserving the prior durability behavior.
    """
    def __init__(self, storage, remote_dir: str = "/auditlog", process_family: str = "KYMA"):
        self.storage = storage
        self.remote_dir = (remote_dir or "/auditlog").rstrip("/")
        self.process_family = self._safe(process_family).lower()
        self._lock = threading.Lock()
        self._cache_dir = Path(tempfile.mkdtemp(prefix="kyma-audit-cache-"))
        self._initialized: set[str] = set()

    @staticmethod
    def _safe(value: str) -> str:
        return "".join(c if c.isalnum() or c in "-_" else "_" for c in str(value))

    def remote_path(self, now=None) -> str:
        now = now or datetime.now(timezone.utc)
        return f"{self.remote_dir}/audit_{self.process_family}_{now:%Y%m%d}.csv"

    def _local_path(self, remote: str) -> Path:
        return self._cache_dir / Path(remote).name

    def write(self, *, run_uuid=None, set_id=None, set_date=None, file_id=None,
              process_type, status, message=None, task_chain_id=None, dsp_log_id=None,
              http_method=None, http_status=None, api_endpoint=None, retry_no=0,
              duration_ms=None, error_code=None, error_message=None, details=None):
        now = datetime.now(timezone.utc)
        remote = self.remote_path(now)
        row = {
            "TIMESTAMP_UTC": now.isoformat(),
            "RUN_UUID": run_uuid or "",
            "SET_ID": set_id or "",
            "SET_DATE": set_date.isoformat() if hasattr(set_date, "isoformat") else (set_date or ""),
            "FILE_ID": file_id or "",
            "PROCESS_TYPE": process_type,
            "STATUS": status,
            "MESSAGE": (message or "")[:1000],
            "TASK_CHAIN_ID": task_chain_id or "",
            "DSP_LOG_ID": dsp_log_id or "",
            "HTTP_METHOD": http_method or "",
            "HTTP_STATUS": "" if http_status is None else http_status,
            "API_ENDPOINT": api_endpoint or "",
            "RETRY_NO": retry_no,
            "DURATION_MS": "" if duration_ms is None else duration_ms,
            "ERROR_CODE": error_code or "",
            "ERROR_MESSAGE": (error_message or "")[:2000],
            "DETAILS_JSON": json.dumps(details, ensure_ascii=False, default=str) if details is not None else "",
        }
        try:
            with self._lock:
                local = self._local_path(remote)
                if remote not in self._initialized:
                    if self.storage.exists(remote):
                        self.storage.download(remote, str(local))
                    self._initialized.add(remote)
                new = not local.exists() or local.stat().st_size == 0
                with local.open("a", encoding=UTF8, errors="strict", newline="") as fh:
                    writer = csv.DictWriter(fh, fieldnames=_FIELDS, delimiter=";", lineterminator="\n")
                    if new:
                        writer.writeheader()
                    writer.writerow(row)
                self.storage.upload(str(local), remote)
            return remote
        except Exception as exc:
            # Audit is always attempted, but an audit transport problem must not
            # abort the business process. The failure remains visible in pod logs.
            LOG.warning("HDLF audit write failed for %s: %s", remote, exc, exc_info=True)
            return None
