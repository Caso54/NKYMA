\
from __future__ import annotations
import csv
import logging
from datetime import datetime, timezone
from pathlib import Path
from threading import Lock
from .utf8_utils import UTF8

_LOG = logging.getLogger("kyma")
_AUDIT_LOCK = Lock()

def configure_logging() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
    )

def audit(path: str, run_uuid: str, process: str, step: str, status: str, message: str = "") -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with _AUDIT_LOCK:
        new = not p.exists()
        with p.open("a", encoding=UTF8, errors="strict", newline="") as f:
            w = csv.writer(f, delimiter=";")
            if new:
                w.writerow(["TIMESTAMP_UTC", "RUN_UUID", "PROCESS", "STEP", "STATUS", "MESSAGE"])
            w.writerow([
                datetime.now(timezone.utc).isoformat(),
                run_uuid, process, step, status, message[:500]
            ])
