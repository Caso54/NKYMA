from __future__ import annotations
from pathlib import Path


def normalize_hldf_path(path: str) -> str:
    """Normalize an HDLF/WebHDFS path to exactly one leading slash.

    HDLF exposes directory-like prefixes rather than durable empty directories.
    Keeping one canonical representation avoids requests such as ``//inbound``.
    """
    if path is None:
        return "/"
    raw = str(path).strip().replace("\\", "/")
    parts = [part for part in raw.split("/") if part not in ("", ".")]
    if not parts:
        return "/"
    return "/" + "/".join(parts)


def _not_found(exc: Exception) -> bool:
    """Return True for backend errors that mean an HDLF prefix is currently absent."""
    for attr in ("status_code", "status", "http_status", "code"):
        try:
            if int(getattr(exc, attr, -1)) == 404:
                return True
        except (TypeError, ValueError):
            pass
    text = str(exc).lower()
    return (
        "filenotfoundexception" in text
        or "file-not-found" in text
        or "file not found" in text
        or "http 404" in text
        or "status 404" in text
    )


class HldfStorage:
    """Adapter around the proven ``common_hldf`` module.

    SAP HANA Data Lake Files treats directories largely as virtual prefixes. An
    empty prefix may disappear and LISTSTATUS can then return 404. Therefore this
    adapter never depends on MKDIRS. A missing prefix is treated as an empty list,
    while uploads/renames use the complete target path and thereby recreate the
    prefix when the backend stores the file.
    """

    def __init__(self):
        try:
            from . import common_hldf as hldf
        except ImportError as exc:
            raise RuntimeError(
                "app/common_hldf.py is missing. Copy the existing proven HDLF module "
                "into the new image."
            ) from exc
        self.h = hldf

    @staticmethod
    def normalize(path: str) -> str:
        return normalize_hldf_path(path)

    def list_files(self, path: str):
        path = self.normalize(path)
        try:
            return self.h.list_files(path)
        except Exception as exc:
            if _not_found(exc):
                return []
            raise

    def list_dirs(self, path: str):
        path = self.normalize(path)
        try:
            return self.h.list_dirs(path)
        except Exception as exc:
            if _not_found(exc):
                return []
            raise

    def mkdirs(self, path: str):
        """Compatibility no-op.

        Empty HDLF prefixes are not durable and the deployed backend does not
        support MKDIRS. Callers may keep invoking this method, but no backend
        request is made and no warning is emitted.
        """
        return self.normalize(path) if path else None

    def ensure_dirs(self, *paths: str):
        # Intentional no-op: target prefixes are recreated implicitly by upload.
        return [self.normalize(path) for path in paths if path]

    def exists(self, path: str):
        path = self.normalize(path)
        try:
            return self.h.exists(path)
        except Exception as exc:
            if _not_found(exc):
                return False
            raise

    def rename(self, src: str, dst: str):
        return self.h.rename(self.normalize(src), self.normalize(dst))

    def download(self, remote: str, local: str):
        Path(local).parent.mkdir(parents=True, exist_ok=True)
        return self.h.download_to_file(self.normalize(remote), local)

    def upload(self, local: str, remote: str):
        # Do not issue MKDIRS. Uploading to the complete path creates/recreates
        # the virtual HDLF prefix as soon as a file exists below it.
        return self.h.upload_file_chunked(self.normalize(remote), local)

    def delete_file(self, path: str):
        """Delete one remote file using the delete primitive of common_hldf."""
        path = self.normalize(path)
        for name in ("delete_file", "delete", "remove_file", "remove"):
            fn = getattr(self.h, name, None)
            if callable(fn):
                return fn(path)
        raise RuntimeError(
            "common_hldf.py does not expose a delete operation. "
            "Add delete_file(path) (or delete/remove_file/remove) to enable safe outbound cleanup."
        )

    def create_empty_file(self, path: str):
        return self.h.create_empty_file(self.normalize(path))
