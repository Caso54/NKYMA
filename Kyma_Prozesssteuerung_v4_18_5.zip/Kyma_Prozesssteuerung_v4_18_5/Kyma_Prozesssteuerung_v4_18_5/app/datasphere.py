from __future__ import annotations
import time
import requests
from dataclasses import dataclass
from typing import Any
from .retry import RETRIABLE_HTTP
from .utf8_utils import json_utf8_bytes

class DataSphereHTTPError(RuntimeError):
    def __init__(self, status_code: int, message: str):
        super().__init__(f"DataSphere HTTP {status_code}: {message}")
        self.status_code = status_code

    @property
    def retriable(self) -> bool:
        return self.status_code in RETRIABLE_HTTP

@dataclass
class TaskRun:
    log_id: str

class DataSphereClient:
    def __init__(self, host: str, token_url: str, client_id: str, client_secret: str, timeout: int = 60):
        self.host = host.rstrip("/")
        self.token_url = token_url
        self.client_id = client_id
        self.client_secret = client_secret
        self.timeout = timeout
        self._token: str | None = None
        self._token_expires_at = 0.0

    def _request_token(self) -> str:
        r = requests.post(
            self.token_url,
            data={"grant_type": "client_credentials"},
            auth=(self.client_id, self.client_secret),
            timeout=self.timeout,
        )
        if not r.ok:
            raise DataSphereHTTPError(r.status_code, r.text[:1000])
        payload = r.json()
        self._token = payload["access_token"]
        expires_in = int(payload.get("expires_in", 3600))
        self._token_expires_at = time.time() + max(60, expires_in - 60)
        return self._token

    def token(self) -> str:
        if not self._token or time.time() >= self._token_expires_at:
            return self._request_token()
        return self._token

    def _headers(self, accept: str = "application/json") -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self.token()}",
            "Accept": accept,
            "Content-Type": "application/json; charset=utf-8",
        }

    def run_task_chain(self, space_id: str, object_id: str, input_parameters: dict[str, Any] | None = None) -> TaskRun:
        url = f"{self.host}/api/v1/datasphere/tasks/chains/{space_id}/run/{object_id}"
        body = {}
        if input_parameters:
            body["inputParameters"] = input_parameters
        r = requests.post(url, data=json_utf8_bytes(body), headers=self._headers(), timeout=self.timeout)
        if not r.ok:
            raise DataSphereHTTPError(r.status_code, r.text[:1000])
        log_id = r.json().get("logId")
        if log_id is None:
            raise RuntimeError(f"DataSphere response contains no logId: {r.text[:1000]}")
        return TaskRun(str(log_id))

    def get_task_status(self, space_id: str, log_id: str) -> str:
        url = f"{self.host}/api/v1/datasphere/tasks/logs/{space_id}/{log_id}"
        accept = "application/vnd.sap.datasphere.task.log.status.object+json"
        r = requests.get(url, headers=self._headers(accept), timeout=self.timeout)
        if not r.ok:
            raise DataSphereHTTPError(r.status_code, r.text[:1000])
        payload = r.json()
        if isinstance(payload, dict):
            status = payload.get("status")
        elif isinstance(payload, str):
            status = payload
        else:
            status = None
        if not status:
            raise RuntimeError(f"Unexpected task status response: {payload!r}")
        return str(status).upper()

    def wait_for_task(self, space_id: str, log_id: str, poll_seconds: int, timeout_seconds: int,
                      on_status=None) -> str:
        terminal_success = {"COMPLETED", "DONE", "SUCCESS", "SUCCEEDED"}
        terminal_failed = {"FAILED", "ERROR", "CANCELED", "CANCELLED"}
        deadline = time.time() + timeout_seconds
        last = None
        while time.time() < deadline:
            status = self.get_task_status(space_id, log_id)
            if status != last and on_status:
                on_status(status)
            last = status
            if status in terminal_success:
                return status
            if status in terminal_failed:
                raise RuntimeError(f"DataSphere task chain {log_id} ended with status {status}")
            time.sleep(poll_seconds)
        raise TimeoutError(f"Timeout while waiting for DataSphere task chain logId={log_id}; last={last}")
