from __future__ import annotations
import json
import os
from dataclasses import dataclass
from pathlib import Path
from .utf8_utils import read_utf8_text
from typing import Any


def required(name: str) -> str:
    value = os.getenv(name)
    if value is None or value == "":
        raise RuntimeError(f"Required environment variable '{name}' is missing.")
    return value


def env_int(name: str, default: int) -> int:
    return int(os.getenv(name, str(default)))


def env_bool(name: str, default: bool = False) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.lower() in {"1", "true", "yes", "y"}


@dataclass(frozen=True)
class Settings:
    dsp_host: str
    dsp_token_url: str
    dsp_client_id: str
    dsp_client_secret: str
    dsp_space_id: str

    sql_host: str
    sql_port: int
    sql_user: str
    sql_password: str
    sql_schema: str
    sql_status_table: str

    inbound_path: str
    decrypted_path: str
    outbound_path: str
    outbound_source_path: str
    encrypted_path: str
    outbound_archive_path: str
    as300_output_filename_prefix: str

    inbound_gpg_passphrase: str | None
    outbound_gpg_passphrase: str | None

    max_workers: int
    poll_interval_seconds: int
    poll_timeout_seconds: int
    max_retries: int
    retry_wait_seconds: int
    process_rules_file: str
    audit_log_path: str
    audit_log_retention_days: int
    delivery_model_file: str
    taskchains_file: str
    file_status_table: str
    set_status_table: str
    process_status_table: str
    audit_table: str

    opensql_persistence_enabled: bool
    central_opensql_status_enabled: bool
    datasphere_taskchain_api_enabled: bool
    inbound_done_prefix_enabled: bool
    inbound_done_prefix: str
    use_base64_decode: bool
    base64_mode: str
    base64_fallback_fields: tuple[str, ...]
    inbound_success_lifecycle: str
    outbound_source_lifecycle: str

    inbound_archive_path: str
    archive_unscheduled_files: bool
    archive_unknown_files: bool
    bank_holiday_calendar_enabled: bool
    bank_holiday_calendar_file: str
    schedule_enforcement_enabled: bool
    manual_ingest_mode: bool
    extraction_date_validation_enabled: bool
    drop_duplicate_inbound_files: bool

    @classmethod
    def from_env(cls) -> "Settings":
        opensql_persistence_enabled = env_bool("OPENSQL_PERSISTENCE_ENABLED", False)
        central_opensql_status_enabled = env_bool("CENTRAL_OPENSQL_STATUS_ENABLED", False)
        datasphere_taskchain_api_enabled = env_bool("DATASPHERE_TASKCHAIN_API_ENABLED", False)
        sql_required = opensql_persistence_enabled or central_opensql_status_enabled

        return cls(
            dsp_host=required("DSP_HOST").rstrip("/"),
            dsp_token_url=required("DSP_TOKEN_URL"),
            dsp_client_id=required("DSP_CLIENT_ID"),
            dsp_client_secret=required("DSP_CLIENT_SECRET"),
            dsp_space_id=required("DSP_SPACE_ID"),

            sql_host=required("DSP_SQL_HOST") if sql_required else os.getenv("DSP_SQL_HOST", ""),
            sql_port=env_int("DSP_SQL_PORT", 443) if sql_required else 443,
            sql_user=required("DSP_SQL_USER") if sql_required else os.getenv("DSP_SQL_USER", ""),
            sql_password=required("DSP_SQL_PASSWORD") if sql_required else os.getenv("DSP_SQL_PASSWORD", ""),
            sql_schema=required("DSP_SQL_SCHEMA") if sql_required else os.getenv("DSP_SQL_SCHEMA", ""),
            sql_status_table=os.getenv("DSP_STATUS_TABLE", "FI_IT_M_TA_RUN_LOG_TC"),

            inbound_path=os.getenv("HDLF_INBOUND_PATH", "/inbound"),
            decrypted_path=os.getenv("HDLF_DECRYPTED_PATH", "/inbound/decrypted"),
            outbound_path=os.getenv("HDLF_OUTBOUND_PATH", "/outbound"),
            outbound_source_path=os.getenv("HDLF_OUTBOUND_AS300_SOURCE_PATH", "/outbound/DS_DL_EX_AS300/initial"),
            encrypted_path=os.getenv("HDLF_ENCRYPTED_PATH", "/outbound/encrypted"),
            outbound_archive_path=os.getenv("HDLF_OUTBOUND_ARCHIVE_PATH", "/outbound/archiv"),
            as300_output_filename_prefix=os.getenv("AS300_OUTPUT_FILENAME_PREFIX", "SAP_AVQ_AS300_BOOKING").strip() or "SAP_AVQ_AS300_BOOKING",

            inbound_gpg_passphrase=os.getenv("INBOUND_GPG_PASSPHRASE"),
            outbound_gpg_passphrase=os.getenv("OUTBOUND_GPG_PASSPHRASE"),

            max_workers=env_int("MAX_WORKERS", 2),
            poll_interval_seconds=env_int("POLL_INTERVAL_SECONDS", 15),
            poll_timeout_seconds=env_int("POLL_TIMEOUT_SECONDS", 7200),
            max_retries=env_int("MAX_RETRIES", 3),
            retry_wait_seconds=env_int("RETRY_WAIT_SECONDS", 10),
            process_rules_file=os.getenv("PROCESS_RULES_FILE", "/opt/app/config/process_rules.json"),
            audit_log_path=os.getenv("AUDIT_LOG_PATH", "/auditlog"),
            audit_log_retention_days=env_int("AUDIT_LOG_RETENTION_DAYS", 90),
            delivery_model_file=os.getenv("DELIVERY_MODEL_FILE", "/opt/app/config/delivery_model.json"),
            taskchains_file=os.getenv("TASKCHAINS_FILE", "/opt/app/config/datasphere_taskchains.json"),
            file_status_table=os.getenv("DSP_FILE_STATUS_TABLE", "FI_IT_M_TA_FILE_STATUS"),
            set_status_table=os.getenv("DSP_SET_STATUS_TABLE", "FI_IT_M_TA_SET_STATUS"),
            process_status_table=os.getenv("DSP_PROCESS_STATUS_TABLE", "FI_IT_M_TA_PROCESS_STATUS"),
            audit_table=os.getenv("DSP_AUDIT_TABLE", "FI_IT_M_TA_AUDIT_LOG"),

            opensql_persistence_enabled=opensql_persistence_enabled,
            central_opensql_status_enabled=central_opensql_status_enabled,
            datasphere_taskchain_api_enabled=datasphere_taskchain_api_enabled,
            inbound_done_prefix_enabled=env_bool("INBOUND_DONE_PREFIX_ENABLED", False),
            inbound_done_prefix=os.getenv("INBOUND_DONE_PREFIX", "DONE_"),
            use_base64_decode=env_bool("USE_BASE64_DECODE", True),
            base64_mode=os.getenv("BASE64_MODE", "AUTO_STRICT").strip().upper(),
            base64_fallback_fields=tuple(x.strip() for x in os.getenv("BASE64_FALLBACK_FIELDS", "").split(",") if x.strip()),
            inbound_success_lifecycle=os.getenv("INBOUND_SUCCESS_LIFECYCLE", "KEEP").strip().upper(),
            outbound_source_lifecycle=os.getenv("OUTBOUND_SOURCE_LIFECYCLE", "ARCHIVE").strip().upper(),

            inbound_archive_path=os.getenv("HDLF_INBOUND_ARCHIVE_PATH", "/inbound/archiv"),
            archive_unscheduled_files=env_bool("ARCHIVE_UNSCHEDULED_FILES", True),
            archive_unknown_files=env_bool("ARCHIVE_UNKNOWN_FILES", True),
            bank_holiday_calendar_enabled=env_bool("BANK_HOLIDAY_CALENDAR_ENABLED", False),
            bank_holiday_calendar_file=os.getenv("BANK_HOLIDAY_CALENDAR_FILE", "/opt/app/config/bank_holidays.json"),
            schedule_enforcement_enabled=env_bool("SCHEDULE_ENFORCEMENT_ENABLED", True),
            manual_ingest_mode=env_bool("MANUAL_INGEST_MODE", False),
            extraction_date_validation_enabled=env_bool("EXTRACTION_DATE_VALIDATION_ENABLED", True),
            drop_duplicate_inbound_files=env_bool("DROP_DUPLICATE_INBOUND_FILES", True),
        )


def load_process_rules(path: str) -> list[dict[str, Any]]:
    data = json.loads(read_utf8_text(path, allow_bom=True))
    if not isinstance(data, list):
        raise RuntimeError("PROCESS_RULES_FILE must contain a JSON array.")
    return [r for r in data if r.get("enabled", True)]
