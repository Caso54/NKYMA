import http.client
import ssl
import os
import json
import time
import socket
import tempfile
from urllib.parse import urlparse
from typing import List, Dict, Optional, Tuple

FILES_REST_API = os.getenv("FILES_REST_API", "")
CONTAINER      = os.getenv("CONTAINER", "")

CRT_PATH = os.getenv("CRT_PATH", "clientblkb.crt")
KEY_PATH = os.getenv("KEY_PATH", "clientblkb.key")

HTTP_TIMEOUT = int(os.getenv("HTTP_TIMEOUT", "600"))
RETRIES = int(os.getenv("RETRIES", "4"))
RETRY_BASE_DELAY_S = float(os.getenv("RETRY_BASE_DELAY_S", "1.0"))
CHUNK_SIZE = int(os.getenv("CHUNK_SIZE", str(1024 * 1024)))
OVERWRITE_OUTPUT = os.getenv("OVERWRITE_OUTPUT", "true").lower() in ("1", "true", "yes", "y")

TLS_VERIFY = os.getenv("TLS_VERIFY", "false").lower() in ("1", "true", "yes", "y")
CA_CERT_PATH = os.getenv("CA_CERT_PATH", "").strip() or None

_RETRYABLE_STATUSES = {429, 500, 502, 503, 504}

class RetryableHttpError(RuntimeError):
    pass

def _build_ssl_context() -> ssl.SSLContext:
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    if os.path.exists(CRT_PATH) and os.path.exists(KEY_PATH):
        ctx.load_cert_chain(certfile=CRT_PATH, keyfile=KEY_PATH)

    if TLS_VERIFY:
        if CA_CERT_PATH:
            ctx.load_verify_locations(CA_CERT_PATH)
        else:
            ctx.load_default_certs()
        ctx.verify_mode = ssl.CERT_REQUIRED
        ctx.check_hostname = True
    else:
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

    return ctx

_SSL_CTX = _build_ssl_context()

def _conn():
    if not FILES_REST_API:
        raise RuntimeError("FILES_REST_API is empty (set env FILES_REST_API).")
    return http.client.HTTPSConnection(FILES_REST_API, timeout=HTTP_TIMEOUT, context=_SSL_CTX)

def _run_with_retry(fn, retries=RETRIES, base_delay=RETRY_BASE_DELAY_S):
    delay = base_delay
    for i in range(retries):
        try:
            return fn()
        except (RetryableHttpError, ConnectionResetError, TimeoutError, socket.timeout, OSError):
            if i == retries - 1:
                raise
            time.sleep(delay)
            delay *= 2

def _request_json(method: str, path: str, body: bytes = b"", headers: Optional[Dict[str,str]] = None) -> Tuple[int, bytes]:
    if not CONTAINER:
        raise RuntimeError("CONTAINER is empty (set env CONTAINER).")
    headers = headers or {}
    headers["x-sap-filecontainer"] = CONTAINER

    def _do():
        c = _conn()
        try:
            c.request(method, path, body=body, headers=headers)
            r = c.getresponse()
            data = r.read()
            status = r.status
            r.close()

            if status in _RETRYABLE_STATUSES:
                raise RetryableHttpError(f"{method} retryable: {status} {data[:200]!r}")
            return status, data
        finally:
            c.close()

    return _run_with_retry(_do)

def mkdirs(path_no_leading_slash: str):
    """
    Best-effort: some SAP HD* / HLDF WebHDFS gateways do NOT support MKDIRS and respond with 500
    'Webhdfs Operation [MKDIRS] not supported'. In that case we log a warning and continue.

    If the backend supports MKDIRS, it will return 200/201.
    """
    if not path_no_leading_slash:
        return

    def _do():
        c = _conn()
        try:
            c.request(
                "PUT",
                f"/webhdfs/v1/{path_no_leading_slash}?op=MKDIRS",
                headers={"x-sap-filecontainer": CONTAINER}
            )
            r = c.getresponse()
            data = r.read()
            status = r.status
            r.close()

            # If MKDIRS is not supported, continue (directory must exist already)
            if status == 500 and b"MKDIRS" in data and b"not supported" in data.lower():
                print(f"[WARN] MKDIRS not supported by backend; assuming exists: /{path_no_leading_slash}")
                return

            if status in _RETRYABLE_STATUSES:
                raise RetryableHttpError(f"MKDIRS retryable: {status} {data[:200]!r}")

            if status not in (200, 201):
                raise RuntimeError(f"MKDIRS failed {path_no_leading_slash}: {status} {data[:200]!r}")
        finally:
            c.close()

    _run_with_retry(_do)

def rename(src_no_leading_slash: str, dst_no_leading_slash: str):
    status, data = _request_json("PUT", f"/webhdfs/v1/{src_no_leading_slash}?op=RENAME&destination=/{dst_no_leading_slash}")
    if status not in (200, 201):
        raise RuntimeError(f"RENAME failed {src_no_leading_slash} -> {dst_no_leading_slash}: {status} {data[:200]!r}")

def liststatus(path_no_leading_slash: str) -> List[Dict]:
    status, data = _request_json("GET", f"/webhdfs/v1/{path_no_leading_slash}?op=LISTSTATUS")
    if status != 200:
        raise RuntimeError(f"LISTSTATUS failed {path_no_leading_slash}: {status} {data[:200]!r}")
    obj = json.loads(data.decode("utf-8"))
    return obj.get("FileStatuses", {}).get("FileStatus", [])

def list_files(path_no_leading_slash: str) -> List[str]:
    out = []
    for st in liststatus(path_no_leading_slash):
        if st.get("type") == "FILE":
            out.append(st.get("pathSuffix", ""))
    return sorted([x for x in out if x])

def list_dirs(path_no_leading_slash: str) -> List[str]:
    out = []
    for st in liststatus(path_no_leading_slash):
        if st.get("type") == "DIRECTORY":
            out.append(st.get("pathSuffix", ""))
    return sorted([x for x in out if x])

def download_to_file(remote_path_no_leading_slash: str, local_path: str):
    def _do():
        c = _conn()
        try:
            c.request("GET", f"/webhdfs/v1/{remote_path_no_leading_slash}?op=OPEN",
                      headers={"x-sap-filecontainer": CONTAINER})
            r = c.getresponse()
            status = r.status

            if status in _RETRYABLE_STATUSES:
                data = r.read(); r.close()
                raise RetryableHttpError(f"GET retryable: {status} {data[:200]!r}")
            if status != 200:
                data = r.read()
                r.close()
                raise RuntimeError(f"GET failed {remote_path_no_leading_slash}: {status} {data[:200]!r}")

            with open(local_path, "wb") as f:
                while True:
                    chunk = r.read(CHUNK_SIZE)
                    if not chunk:
                        break
                    f.write(chunk)
            r.close()
        finally:
            c.close()
    _run_with_retry(_do)

def upload_file_chunked(remote_path_no_leading_slash: str, file_path: str):
    """
    Robust WebHDFS-style upload.

    Many WebHDFS implementations require a 2-step protocol:
      1) PUT ...?op=CREATE&overwrite=... (no body) -> 307 Redirect with Location
      2) PUT to Location with the file bytes

    This avoids unstable behaviour (often HTTP 500) when using CREATE&data=true in a single request.
    """
    overwrite = OVERWRITE_OUTPUT
    size = os.path.getsize(file_path)

    def _create_get_location():
        c = _conn()
        try:
            path = f"/webhdfs/v1/{remote_path_no_leading_slash}?op=CREATE&overwrite={'true' if overwrite else 'false'}"
            c.putrequest("PUT", path)
            c.putheader("x-sap-filecontainer", CONTAINER)
            c.putheader("Content-Length", "0")
            c.putheader("Connection", "close")
            c.endheaders()

            r = c.getresponse()
            data = r.read()
            status = r.status
            location = r.getheader("Location")
            r.close()
            return status, data, location
        finally:
            c.close()

    def _put_to_location(location: str):
        u = urlparse(location)
        if u.scheme and u.netloc:
            host = u.netloc
            path = (u.path or "/") + (("?" + u.query) if u.query else "")
            c = http.client.HTTPSConnection(host, timeout=HTTP_TIMEOUT, context=_SSL_CTX)
        else:
            path = location
            c = _conn()

        try:
            c.putrequest("PUT", path)
            c.putheader("x-sap-filecontainer", CONTAINER)
            c.putheader("Content-Type", "application/octet-stream")
            c.putheader("Content-Length", str(size))
            c.putheader("Connection", "close")
            c.endheaders()

            with open(file_path, "rb") as f:
                while True:
                    chunk = f.read(CHUNK_SIZE)
                    if not chunk:
                        break
                    c.send(chunk)

            r = c.getresponse()
            data = r.read()
            status = r.status
            r.close()

            if status in _RETRYABLE_STATUSES:
                raise RetryableHttpError(f"PUT retryable: {status} {data[:200]!r}")
            if status not in (200, 201):
                raise RuntimeError(f"PUT failed {remote_path_no_leading_slash}: {status} {data[:200]!r}")
        finally:
            c.close()

    def _do():
        status, data, location = _create_get_location()

        if status in _RETRYABLE_STATUSES:
            raise RetryableHttpError(f"CREATE retryable: {status} {data[:200]!r}")

        if status in (301, 302, 307):
            if not location:
                raise RuntimeError(f"CREATE redirect without Location: {status} {data[:200]!r}")
            _put_to_location(location)
            return

        if status in (200, 201):
            if location:
                _put_to_location(location)
                return
            raise RuntimeError(f"CREATE returned {status} without Location; upload cannot continue. Body={data[:200]!r}")

        raise RuntimeError(f"CREATE failed {remote_path_no_leading_slash}: {status} {data[:200]!r}")

    _run_with_retry(_do)

def exists(path_no_leading_slash: str) -> bool:
    status, data = _request_json("GET", f"/webhdfs/v1/{path_no_leading_slash}?op=GETFILESTATUS")
    if status == 200:
        return True
    if status == 404:
        return False
    raise RuntimeError(f"GETFILESTATUS failed {path_no_leading_slash}: {status} {data[:200]!r}")


def delete_file(path_no_leading_slash: str):
    """Delete one file from HDLF via WebHDFS.

    DELETE is idempotent for the lifecycle use case: HTTP 404 is treated as
    success because a retry may occur after the backend deleted the file but
    before the client received the response.
    """
    status, data = _request_json(
        "DELETE",
        f"/webhdfs/v1/{path_no_leading_slash}?op=DELETE&recursive=false",
    )
    if status in (200, 404):
        return
    raise RuntimeError(
        f"DELETE failed {path_no_leading_slash}: {status} {data[:200]!r}"
    )

def create_empty_file(remote_path_no_leading_slash: str):
    with tempfile.NamedTemporaryFile(delete=True) as tmp:
        upload_file_chunked(remote_path_no_leading_slash, tmp.name)