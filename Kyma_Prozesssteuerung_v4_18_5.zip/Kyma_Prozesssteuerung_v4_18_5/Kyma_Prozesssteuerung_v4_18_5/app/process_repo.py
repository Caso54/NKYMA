from __future__ import annotations
import uuid
from datetime import datetime, timezone
from hdbcli import dbapi


def now_utc():
    return datetime.now(timezone.utc)


class ProcessRepository:
    def __init__(self, host, port, user, password, schema, process_table):
        self.host = host
        self.port = port
        self.user = user
        self.password = password
        self.schema = schema
        self.process_table = process_table

    def connect(self):
        return dbapi.connect(
            address=self.host,
            port=self.port,
            user=self.user,
            password=self.password,
            encrypt=True,
        )

    def fq(self, name):
        return f'"{self.schema}"."{name}"'

    def create(self, *, run_uuid, set_id, set_date, file_id, task_chain_id):
        process_uuid = str(uuid.uuid4())
        sql = (
            f'INSERT INTO {self.fq(self.process_table)} '
            '("PROCESS_UUID","RUN_UUID","SET_ID","SET_DATE","FILE_ID","TASK_CHAIN_ID",'
            '"PROCESS_STATUS","START_TIMESTAMP","LAST_STATUS_TIMESTAMP","RETRY_COUNT") '
            'VALUES (?,?,?,?,?,?,?,?,?,?)'
        )
        vals = (
            process_uuid, run_uuid, set_id, set_date, file_id, task_chain_id,
            "CREATED", now_utc(), now_utc(), 0,
        )
        c = self.connect()
        try:
            c.cursor().execute(sql, vals)
            c.commit()
        finally:
            c.close()
        return process_uuid

    def update(self, process_uuid, *, status, dsp_log_id=None, http_status=None,
               retry_count=None, error_code=None, error_message=None, end=False):
        assigns = ['"PROCESS_STATUS"=?', '"LAST_STATUS_TIMESTAMP"=?']
        vals = [status, now_utc()]
        if dsp_log_id is not None:
            assigns.append('"DSP_LOG_ID"=?'); vals.append(dsp_log_id)
        if http_status is not None:
            assigns.append('"HTTP_STATUS"=?'); vals.append(http_status)
        if retry_count is not None:
            assigns.append('"RETRY_COUNT"=?'); vals.append(retry_count)
        if error_code is not None:
            assigns.append('"ERROR_CODE"=?'); vals.append(str(error_code)[:100])
        if error_message is not None:
            assigns.append('"ERROR_MESSAGE"=?'); vals.append(str(error_message)[:2000])
        if end:
            assigns.append('"END_TIMESTAMP"=?'); vals.append(now_utc())
        sql = f'UPDATE {self.fq(self.process_table)} SET {", ".join(assigns)} WHERE "PROCESS_UUID"=?'
        vals.append(process_uuid)
        c = self.connect()
        try:
            c.cursor().execute(sql, tuple(vals))
            c.commit()
        finally:
            c.close()
