\
from __future__ import annotations
import subprocess
from pathlib import Path

def decrypt_symmetric(src: str, dst: str, passphrase: str) -> None:
    Path(dst).parent.mkdir(parents=True, exist_ok=True)
    p = subprocess.run(
        ["gpg", "--batch", "--yes", "--pinentry-mode", "loopback",
         "--passphrase-fd", "0", "--output", dst, "--decrypt", src],
        input=(passphrase + "\n").encode("utf-8"),
        stdout=subprocess.PIPE, stderr=subprocess.PIPE,
    )
    if p.returncode != 0:
        raise RuntimeError(f"GPG decrypt failed: {p.stderr.decode('utf-8', errors='replace')[-1000:]}")

def encrypt_symmetric(src: str, dst: str, passphrase: str) -> None:
    Path(dst).parent.mkdir(parents=True, exist_ok=True)
    p = subprocess.run(
        ["gpg", "--batch", "--yes", "--pinentry-mode", "loopback",
         "--passphrase-fd", "0", "--symmetric", "--cipher-algo", "AES256",
         "--output", dst, src],
        input=(passphrase + "\n").encode("utf-8"),
        stdout=subprocess.PIPE, stderr=subprocess.PIPE,
    )
    if p.returncode != 0:
        raise RuntimeError(f"GPG encrypt failed: {p.stderr.decode('utf-8', errors='replace')[-1000:]}")
