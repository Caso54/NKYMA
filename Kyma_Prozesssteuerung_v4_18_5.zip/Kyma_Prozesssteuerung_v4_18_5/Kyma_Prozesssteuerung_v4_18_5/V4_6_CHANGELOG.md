# v4.6 changes

- Added parameterizable schedules on set and file level.
- File schedule overrides set schedule.
- Legacy `active_when` remains the fallback when no schedule is configured.
- Added optional bank holiday calendar with safe empty/disabled fallback.
- Added archive handling for known-but-unscheduled and unknown completed inbound files.
- Added audit warnings `FILE_NOT_SCHEDULED` and `UNKNOWN_FILE` including original filename and archive target.
- Files without DONE prefix are still ignored/not archived when prefix gating is enabled.
- FULL-before-DELTA sequencing remains unchanged and works with schedule-based month-end FULL deliveries.
