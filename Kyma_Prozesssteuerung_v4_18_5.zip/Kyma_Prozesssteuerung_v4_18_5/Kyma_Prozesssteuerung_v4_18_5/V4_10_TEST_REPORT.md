# v4.10 Test Report

Automatisierte Regression:

```text
49 passed
COMPILE_OK
```

Zusätzlich geprüft:

- AS300 Quelle ausschließlich `/outbound/DS_DL_EX_AS300/initial/part-*.csv`
- AS300 Ziel `<AS300_OUTPUT_FILENAME_PREFIX>_<Timestamp>.csv.gpg`
- UTF-8 ohne BOM
- CRLF/CR -> LF Normalisierung
- mehrere Parts: Header nur einmal
- Outbound-Archiv behält `DS_DL_EX_AS300/initial`-Struktur
- Archive-Fehler: Originalquelle wird nicht gelöscht
- erfolgreicher Archive-Schritt vor Delete
- neue Datei nach Start-Snapshot wird nicht gelöscht
- benötigte HDLF-Verzeichnisse werden wieder angelegt
- bestehende Inbound-/Schedule-/Manual-/FULL-DELTA-/DataSphere-/Audit-Regression bleibt grün
