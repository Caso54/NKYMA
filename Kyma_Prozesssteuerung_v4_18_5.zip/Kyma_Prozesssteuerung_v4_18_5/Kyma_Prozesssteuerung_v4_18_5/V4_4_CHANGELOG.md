# v4.4 – DONE prefix + UTF-8 hardening

- `DONE_` is the configurable HDLF upload-completion marker.
- With `INBOUND_DONE_PREFIX_ENABLED=true`, only files with the configured prefix are processed.
- The prefix is removed before delivery-model matching and before upload to the decrypted target directory.
- The physical source file remains `DONE_*` in the inbound directory while it is processed.
- Decrypted text/CSV payloads are strictly validated as UTF-8 without BOM before upload.
- CSV and audit outputs are written as UTF-8 without BOM.
- Base64 decoded text must itself be valid UTF-8.
- JSON/OData/DataSphere request payloads are encoded explicitly as UTF-8.
- FULL and DELTA may arrive together, but paired FULL taskchains complete before DELTA taskchains start.
