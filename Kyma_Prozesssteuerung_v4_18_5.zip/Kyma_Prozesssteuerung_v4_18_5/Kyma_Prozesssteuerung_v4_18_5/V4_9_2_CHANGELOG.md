# v4.9.2 – AS300 LF line endings

- AS300 plaintext CSV is normalized to LF (`\n`) before GPG encryption.
- CRLF (`\r\n`) and standalone CR (`\r`) are converted to LF.
- UTF-8 validation runs before and after normalization.
- HDLF audit event `OUTBOUND_LINE_ENDINGS / SUCCESS` records the normalization step.
- Added regression tests for CRLF, LF and mixed line endings.
- Output naming remains `SAP_AVQ_AS300_BOOKING_<Timestamp>.csv.gpg`.
