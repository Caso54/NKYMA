# v4.5 Full Code Review and Simulation

## Result
- Python compilation: PASS
- Automated tests: 28/28 PASS
- UTF-8 without BOM checks: PASS
- DONE_ gating on/off: PASS
- FULL before DELTA sequence: PASS
- DataSphere API retry/audit: PASS
- Central OData status ON/OFF/retry/non-blocking: PASS
- Set status matrix: PASS
- Base64 decode restored in `sets` path: PASS
- Optional files included in ingest matching: PASS
- Failed predecessor set can be reopened by late re-delivery: PASS
- Empty monthly-only daily set rows no longer created: PASS

## Important deployment dependency
`app/common_hldf.py` is intentionally not reconstructed. The proven project-specific HDLF implementation must be copied into `app/common_hldf.py` before the Docker build. The Dockerfile now fails fast at build time if it is missing.

## Detailed simulated scenarios
1. DONE prefix enabled: unprefixed file ignored.
2. DONE prefix enabled: DONE_ stripped for matching and decrypted target filename.
3. DONE prefix disabled: normal filename accepted.
4. .part file ignored.
5. Invalid UTF-8 rejected.
6. UTF-8 BOM rejected for inbound payload.
7. Umlauts/special characters preserved as UTF-8 without BOM.
8. Base64 UTF-8 text decoded and written UTF-8 without BOM.
9. Monthly day activates daily DELTA plus additional FULL.
10. DELTA may physically arrive/list before FULL; candidate sorting starts FULL first.
11. DELTA is deferred until corresponding FULL has completed successfully.
12. DataSphere start HTTP 503 retried and then succeeds.
13. DataSphere polling HTTP 500 retried.
14. DataSphere RUNNING -> SUCCEEDED produces successful process completion.
15. DataSphere terminal FAILED produces process/file failure and audit error.
16. Set with no received files -> WAITING.
17. Partial successful set -> BLOCKED.
18. Required process failure -> FAILED.
19. Complete set with unfinished predecessor -> WAITING_PREDECESSOR.
20. Complete set with unfinished dependency -> WAITING_DEPENDENCY.
21. Complete set -> COMPLETED.
22. Central status reporting disabled -> no HTTP status call.
23. Central status reporting enabled -> status HTTP call succeeds.
24. Central status transient error -> retry.
25. Central status permanent error -> audited FAILED but business processing not raised/aborted.
26. Optional files participate in matching/processing but not required-set completeness.
27. Late re-delivery can target oldest FAILED/open set if the file is not completed there.
28. Monthly-only sets do not create empty daily predecessor rows.

## Remaining external/integration tests
The following cannot be proven by unit simulation and require the real Kyma/DataSphere/HDLF environment:
- actual `common_hldf.py` REST behavior/certificate handling
- real GPG payload and production passphrase
- HANA Open SQL DDL/permissions and exact port/host
- actual DataSphere Task Chain API response/status vocabulary
- target OData service entity contract/authentication
- real file sizes, chunk upload behavior, network interruption and restart
- actual weekend/month-end scheduling

## Kubernetes manifest review
The packaged inbound CronJob was updated from an obsolete image reference to `process-control-v4-5`, is `suspend: true` by default, uses `Europe/Zurich`, and is scheduled every 10 minutes on all calendar days when enabled. This avoids missing weekend deliveries or a monthly FULL day falling on a weekend. Adjust cadence if operations requires a different interval.
