# v4.18.2 Test Report

## Scope
- New switch `EXTRACTION_DATE_VALIDATION_ENABLED`.
- Strict default remains enabled.
- Validation bypass is independent of schedule enforcement.
- Existing streaming, Base64 AUTO_STRICT, safe lifecycle and OpenSQL-off behavior retained.

## Results
- Python compile check: PASS.
- Full regression suite: **89/89 passed**.
- Focused v4.18.2 + streaming/Base64/lifecycle suite: **12/12 passed**.
- JSON configuration validation: PASS (all files).
- Kubernetes YAML parse validation: PASS (ConfigMap and both CronJobs).

## Concrete simulation
Scenario: set date `2026-09-27`, extraction date `2026-09-25`, allowed offsets `[0, -1]`.

- `EXTRACTION_DATE_VALIDATION_ENABLED=true`:
  - processed: 0
  - audit: `INVALID_EXTRACTION_DATE`
  - expected result: file rejected.

- `EXTRACTION_DATE_VALIDATION_ENABLED=false`:
  - processed: 1
  - audit: `EXTRACTION_DATE_VALIDATION_BYPASS`
  - expected result: file accepted for processing.

## Safety behavior
- Default value when environment variable is absent: `true`.
- Bypass emits a WARNING and audit event; it is not silent.
- Unknown file rules, schedule rules and safe archive `copy -> size/SHA-256 verify -> delete` are unchanged.
