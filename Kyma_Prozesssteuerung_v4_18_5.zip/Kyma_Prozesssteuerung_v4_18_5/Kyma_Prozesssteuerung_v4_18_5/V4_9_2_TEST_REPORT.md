# v4.9.2 test report

Result: 47 tests passed; compileall OK.

Additional scenarios:
- CRLF input -> LF only before encryption
- mixed CRLF/LF/CR input -> LF only before encryption
- LF input remains LF
- existing AS300 filename, merge, cleanup, directory resilience and inbound regressions remain green
