\
# Existing DataSphere OAuth secret (update/create)
kubectl create secret generic datasphere-oauth-secret `
  --namespace=dsp-poc `
  --from-literal=DSP_CLIENT_ID='REPLACE_CLIENT_ID' `
  --from-literal=DSP_CLIENT_SECRET='REPLACE_CLIENT_SECRET' `
  --dry-run=client -o yaml | kubectl apply -f -

# Open SQL credentials
kubectl create secret generic datasphere-sql-secret `
  --namespace=dsp-poc `
  --from-literal=DSP_SQL_USER='REPLACE_SQL_USER' `
  --from-literal=DSP_SQL_PASSWORD='REPLACE_SQL_PASSWORD' `
  --dry-run=client -o yaml | kubectl apply -f -

# Inbound GPG
kubectl create secret generic inbound-gpg-secret `
  --namespace=dsp-poc `
  --from-literal=INBOUND_GPG_PASSPHRASE='REPLACE_INBOUND_GPG_PASSPHRASE' `
  --dry-run=client -o yaml | kubectl apply -f -

# AS-300 outbound GPG
kubectl create secret generic as300-gpg-secret `
  --namespace=dsp-poc `
  --from-literal=OUTBOUND_GPG_PASSPHRASE='REPLACE_OUTBOUND_GPG_PASSPHRASE' `
  --dry-run=client -o yaml | kubectl apply -f -

kubectl get secrets -n dsp-poc
