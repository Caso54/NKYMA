\
$ErrorActionPreference = "Stop"

kubectl apply -f .\k8s\configmap.yaml
kubectl apply -f .\k8s\cronjob-inbound.yaml
kubectl apply -f .\k8s\cronjob-outbound.yaml

kubectl get cronjobs -n dsp-poc

# Manual test:
# kubectl create job --from=cronjob/hldf-inbound-decrypt inbound-manual-001 -n dsp-poc
# kubectl logs -n dsp-poc -l job-name=inbound-manual-001 --all-containers=true -f
