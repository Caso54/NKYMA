# v4.18.3 Changelog

- Fixed FULL -> DELTA sequencing when `DATASPHERE_TASKCHAIN_API_ENABLED=false`.
- `DECRYPTED_ONLY` now releases the paired DELTA only for the local sequencing check while the taskchain API is disabled.
- `DECRYPTED_ONLY` is not treated as a global success/completion state.
- Added repository `file_status(...)` lookup for both OpenSQL and in-memory delivery repositories.
- Existing v4.18.2 extraction-date toggle, AUTO_STRICT streaming, safe lifecycle, and SQL-off behavior remain unchanged.
