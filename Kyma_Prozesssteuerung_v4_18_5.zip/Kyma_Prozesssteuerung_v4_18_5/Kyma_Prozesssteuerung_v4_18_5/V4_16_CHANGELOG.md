# v4.16

- Added `DATASPHERE_TASKCHAIN_API_ENABLED`.
- Default/test value is `false`: inbound stops after successful decrypt/validation/optional Base64 transform and HDLF upload to `/inbound/decrypted`.
- With the switch off no DataSphere client is created, no OAuth token is requested, and no taskchain POST/GET is executed.
- File status is recorded as `DECRYPTED_ONLY` and HDLF audit gets `TASKCHAIN_API_SKIPPED`.
- When enabled, v4.15 poll heartbeat remains active (taskchain, logId, poll count, status, elapsed and remaining seconds).
- Source CSV date (`YYYY-MM-DD`) and timestamp (`YYYY-MM-DD HH:MM:SS`) field values remain unchanged and are excluded from Base64 decoding.
