# v4.12 - HDLF virtual-prefix resilience

- Removed the runtime dependency on HDLF `MKDIRS`.
- Canonicalizes all HDLF paths to one leading slash and collapses duplicate separators.
- Treats `LISTSTATUS`/directory-list 404 FileNotFound responses as an empty HDLF prefix.
- Treats `exists()` 404 as `False`.
- Upload and rename operations use the complete normalized destination path without pre-creating a directory.
- Preserves always-on HDLF audit behavior; `/auditlog` is recreated implicitly by the next audit upload.
- Preserves inbound/outbound processing, OpenSQL phase switches, scheduling switches, AS300 LF/UTF-8/GPG rules and archive-before-delete behavior.
- Bundles the user's current Phase-1 ConfigMap settings.
