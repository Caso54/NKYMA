# v4.12 Test Report

Additional HDLF virtual-prefix scenarios:

1. `//inbound//decrypted/` normalizes to `/inbound/decrypted`.
2. Missing prefix / LISTSTATUS 404 returns an empty listing instead of aborting the job.
3. Missing prefix / exists 404 returns false.
4. `mkdirs()` and `ensure_dirs()` perform no HDLF backend request and therefore emit no MKDIRS warning.
5. Upload and rename use the complete normalized path without pre-creating a directory.
6. Existing inbound, outbound, UTF-8, LF, FULL/DELTA, schedule, manual-ingest, OpenSQL phase and audit regression tests remain enabled.
