# V4.10.1 verification and simulation report

## Result

- Automated regression: **50/50 passed**
- Python compile check: **OK**
- Active code/config contains no legacy central OData/REST status sender.
- Inbound and outbound CronJobs use image tag `process-control-v4-10` and are delivered with `suspend: true`.

## AS300 outbound

Source: `/outbound/DS_DL_EX_AS300/initial/part-*.csv`.

Processing verified:
1. Snapshot source files at run start.
2. Download and UTF-8 validate.
3. Merge multiple parts with one header.
4. Normalize line separators to LF only.
5. Create `<AS300_OUTPUT_FILENAME_PREFIX>_<UTC timestamp>.csv`.
6. GPG-encrypt to `<AS300_OUTPUT_FILENAME_PREFIX>_<UTC timestamp>.csv.gpg`.
7. Upload to `/outbound/encrypted/`.
8. Verify encrypted target exists.
9. Copy the original source snapshot to `/outbound/archiv/DS_DL_EX_AS300/initial/...`.
10. Delete originals only after the archive copy is complete.
11. Re-create required HDLF directories because HDLF can remove empty folders.

Default prefix: `SAP_AVQ_AS300_BOOKING`.
Config key: `AS300_OUTPUT_FILENAME_PREFIX`.

## Safety cases verified

- A new `part-*.csv` arriving after the initial snapshot is not deleted by the running job.
- Archive failure keeps the original source files.
- Cleanup failure does not remove the successfully generated encrypted target.
- CRLF, LF and mixed line endings all result in LF-only plaintext before encryption.
- Required inbound/outbound/audit directories are ensured again.
- Central OpenSQL steering is independently switchable with `CENTRAL_OPENSQL_STATUS_ENABLED`; HDLF audit remains independent.
- Manual ingest and schedule bypass remain covered by the regression suite.

## Deployment note

The Dockerfile intentionally fails if `app/common_hldf.py` is missing. The proven project-specific HDLF module must therefore be present before the image build.
