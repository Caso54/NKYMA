# v4.9 – AS-300 outbound and HDLF directory resilience

- AS-300 input fixed to `/outbound/DS_DL_EX_AS300/initial/part-*.csv`.
- Output is now `SAP_AVQ_AS300_BOOKING_<UTC timestamp>.csv.gpg`; ZIP packaging removed.
- One part is passed through as CSV content; multiple DataSphere part files are merged in lexical order with one header.
- UTF-8 validation remains mandatory; generated CSV is UTF-8 without BOM.
- Source snapshot is deleted only after encrypted target upload and existence verification.
- Only files present in the start snapshot are deleted, protecting a newly arriving DataSphere export.
- Added `HDLF_OUTBOUND_AS300_SOURCE_PATH` config.
- Required HDLF directories are re-created before/after processing because empty HDLF directories may disappear.
- Storage adapter provides a compatible `delete_file()` abstraction. The deployed `common_hldf.py` must expose one of: `delete_file`, `delete`, `remove_file`, `remove`.
