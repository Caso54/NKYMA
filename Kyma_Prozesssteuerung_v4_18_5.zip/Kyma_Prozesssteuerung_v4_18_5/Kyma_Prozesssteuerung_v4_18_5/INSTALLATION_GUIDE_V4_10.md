# Kyma Prozesssteuerung v4.10 – Einrichtung und Parametrierung

## 1. Zielstand

v4.10 umfasst:

- Inbound-Verarbeitung aus `/inbound/`
- `DONE_` als optionaler Completion-Marker
- GPG-Entschlüsselung
- strikte UTF-8-Verarbeitung ohne BOM
- optionales Base64-Decoding
- Set-/File-Scheduling inkl. Wochentagen, Ultimo und optionalem Bankfeiertagskalender
- Manual-Ingest/Notfallmodus zum bewussten Schedule-Bypass
- DataSphere Taskchain-Start und Status-Polling via REST/OAuth2
- FULL vor DELTA für konfigurierte Paare
- optionales Schreiben in die zentrale OpenSQL-Steuerungstabelle
- HDLF-Audit unter `/auditlog/` immer aktiv
- AS300 Outbound aus `/outbound/DS_DL_EX_AS300/initial/part-*.csv`
- AS300-Zieldatei `<AS300_OUTPUT_FILENAME_PREFIX>_<UTC-Timestamp>.csv.gpg`
- AS300-Ausgabe UTF-8 ohne BOM und nur LF als Line Separator
- Archivierung der ursprünglichen DataSphere-Outbound-Struktur vor dem Löschen
- automatische Wiederanlage benötigter HDLF-Verzeichnisse

## 2. Empfohlener Startzustand

Für die ersten Integrationstests:

```yaml
BANK_HOLIDAY_CALENDAR_ENABLED: "false"
CENTRAL_OPENSQL_STATUS_ENABLED: "false"
SCHEDULE_ENFORCEMENT_ENABLED: "true"
MANUAL_INGEST_MODE: "false"
INBOUND_DONE_PREFIX_ENABLED: "true"
ARCHIVE_UNSCHEDULED_FILES: "true"
ARCHIVE_UNKNOWN_FILES: "true"
```

Beide CronJobs bleiben zunächst `suspend: true` und werden manuell als Test-Jobs gestartet.

## 3. Lokale Vorbereitung

Projekt entpacken und in das Verzeichnis `kyma_process_control` wechseln.

Die projektspezifische, bereits bewährte Datei `app/common_hldf.py` ist weiterhin erforderlich. Sie ist nicht Bestandteil dieses Pakets, weil sie in den vorliegenden Vorgängerpaketen nicht enthalten war.

Prüfung in PowerShell:

```powershell
Test-Path .\app\common_hldf.py
```

Erwartet: `True`.

Der Docker-Build bricht ansonsten absichtlich ab.

## 4. ConfigMap parametrisieren

Datei: `k8s/configmap.yaml`

Folgende Platzhalter müssen ersetzt werden:

```yaml
DSP_HOST: "https://<DATASPHERE_HOST>"
DSP_TOKEN_URL: "https://<OAUTH_HOST>/oauth/token"
DSP_SPACE_ID: "DS_DL"
DSP_SQL_HOST: "<OPEN_SQL_HOST>"
DSP_SQL_PORT: "<OPEN_SQL_PORT>"
DSP_SQL_SCHEMA: "<OPEN_SQL_SCHEMA>"
```

Den Open-SQL-Port exakt aus den DataSphere Database-User-Verbindungsinformationen übernehmen; nicht pauschal 443 annehmen.

### HDLF-Verzeichnisse

```yaml
HDLF_INBOUND_PATH: "/inbound"
HDLF_DECRYPTED_PATH: "/inbound/decrypted"
HDLF_INBOUND_ARCHIVE_PATH: "/inbound/archiv"
HDLF_OUTBOUND_PATH: "/outbound"
HDLF_OUTBOUND_AS300_SOURCE_PATH: "/outbound/DS_DL_EX_AS300/initial"
HDLF_ENCRYPTED_PATH: "/outbound/encrypted"
HDLF_OUTBOUND_ARCHIVE_PATH: "/outbound/archiv"
AS300_OUTPUT_FILENAME_PREFIX: "SAP_AVQ_AS300_BOOKING"
AUDIT_LOG_PATH: "/auditlog"
```

Die Anwendung legt benötigte Verzeichnisse vor ihrer Nutzung wieder an. Das ist notwendig, weil HDLF leere Verzeichnisse nach dem Löschen der letzten Datei entfernen kann.

### Scheduling

```yaml
BANK_HOLIDAY_CALENDAR_ENABLED: "false"
BANK_HOLIDAY_CALENDAR_FILE: "/opt/app/config/bank_holidays.json"
SCHEDULE_ENFORCEMENT_ENABLED: "true"
MANUAL_INGEST_MODE: "false"
```

Normalbetrieb: Scheduling aktiv, Manual-Ingest aus.

Notfallbetrieb:

```yaml
SCHEDULE_ENFORCEMENT_ENABLED: "true"
MANUAL_INGEST_MODE: "true"
```

Nur die Schedule-Prüfung wird dabei übersteuert. DONE-Prüfung, bekannte Filedefinition, GPG, UTF-8, Base64, Retry, Audit und Restart-Schutz bleiben aktiv.

### DONE Completion Marker

```yaml
INBOUND_DONE_PREFIX_ENABLED: "true"
INBOUND_DONE_PREFIX: "DONE_"
```

Bei aktivem Marker werden Dateien ohne `DONE_` ignoriert. Der Präfix wird vor Matching und Ablage der entschlüsselten Datei logisch entfernt.

### Zentrale OpenSQL-Prozesssteuerung

```yaml
CENTRAL_OPENSQL_STATUS_ENABLED: "false"
```

Für die ersten Tests bleibt dieser Schalter aus. Die DataSphere Taskchain REST API bleibt unabhängig davon aktiv. Das HDLF-Audit bleibt ebenfalls immer aktiv.

Später:

```yaml
CENTRAL_OPENSQL_STATUS_ENABLED: "true"
```

Dann werden zusätzlich relevante Statusinformationen in `FI_IT_M_TA_RUN_LOG_TC` geschrieben.

Es existiert keine zusätzliche OData/REST-Statusschnittstelle mehr.

## 5. Benötigte Kyma Secrets

### DataSphere OAuth2

```powershell
kubectl create secret generic datasphere-oauth-secret `
  -n dsp-poc `
  --from-literal=DSP_CLIENT_ID='...' `
  --from-literal=DSP_CLIENT_SECRET='...' `
  --dry-run=client -o yaml | kubectl apply -f -
```

### DataSphere Open SQL

```powershell
kubectl create secret generic datasphere-sql-secret `
  -n dsp-poc `
  --from-literal=DSP_SQL_USER='...' `
  --from-literal=DSP_SQL_PASSWORD='...' `
  --dry-run=client -o yaml | kubectl apply -f -
```

### Inbound GPG

```powershell
kubectl create secret generic inbound-gpg-secret `
  -n dsp-poc `
  --from-literal=INBOUND_GPG_PASSPHRASE='...' `
  --dry-run=client -o yaml | kubectl apply -f -
```

### AS300 Outbound GPG

```powershell
kubectl create secret generic as300-gpg-secret `
  -n dsp-poc `
  --from-literal=OUTBOUND_GPG_PASSPHRASE='...' `
  --dry-run=client -o yaml | kubectl apply -f -
```

### HDLF Client Certificate

Benötigt wird das bestehende Secret `hldf-client-cert` mit Client-Zertifikat und Private Key, die im Container als

- `/certs/clientblkb.crt`
- `/certs/clientblkb.key`

verwendet werden.

### GitHub Container Registry

Das bestehende `ghcr-pull-secret` wird als `imagePullSecret` verwendet.

Das alte allgemeine `kyma-dev-secrets/PASSPHRASE` wird im v4.10-CronJob nicht mehr verwendet.

## 6. OpenSQL Tabellen

Datei: `config/schema.sql`.

Technische Tabellen:

- `FI_IT_M_TA_FILE_STATUS`
- `FI_IT_M_TA_SET_STATUS`
- `FI_IT_M_TA_PROCESS_STATUS`
- `FI_IT_M_TA_AUDIT_LOG`

Zusätzliche zentrale Steuerungstabelle:

- `FI_IT_M_TA_RUN_LOG_TC`

Das Schreiben in `FI_IT_M_TA_RUN_LOG_TC` hängt von `CENTRAL_OPENSQL_STATUS_ENABLED` ab.

Die FILE/SET/PROCESS/AUDIT-Tabellen werden für Orchestrierung, Restart und technische Nachvollziehbarkeit verwendet. Das HDLF-Audit unter `/auditlog/` ist davon unabhängig.

## 7. Taskchain-Konfiguration

Datei: `config/datasphere_taskchains.json`.

Die Zuordnung erfolgt per File. Für jede Filedefinition sind `task_chain_id` und Endpoint hinterlegt.

FULL/DELTA-Paare werden so verarbeitet, dass bei gemeinsamer Fälligkeit die FULL-Taskchain zuerst erfolgreich beendet werden muss, bevor die zugehörige DELTA-Taskchain gestartet wird.

## 8. Set-/File-Schedule konfigurieren

Datei: `config/delivery_model.json`.

Schedules können auf Set-Ebene gepflegt und auf File-Ebene überschrieben werden. Unterstützt werden u. a.:

- `DAILY`
- `WEEKDAYS`
- `DAYS_OF_WEEK`
- `MONTH_END`
- `MONTH_END_PLUS_1`
- `FIRST_DAY_OF_MONTH`
- `NTH_DAY_OF_MONTH`
- `DAILY_EXCEPT_MONTH_END`
- `BANK_WORKDAY`
- `NTH_BANK_WORKDAY_OF_MONTH`
- `MANUAL`

Bankfeiertage werden nur berücksichtigt, wenn `BANK_HOLIDAY_CALENDAR_ENABLED=true` ist und in `config/bank_holidays.json` Feiertage gepflegt sind. Bei deaktiviertem oder leerem Kalender gelten die normalen Tagesregeln.

Ein bekanntes File, das am Anlieferungstag nicht vorgesehen ist, wird bei normalem Schedule-Betrieb nicht verarbeitet, sondern nach `/inbound/archiv/` verschoben und als `FILE_NOT_SCHEDULED / WARNING` auditiert. Unbekannte abgeschlossene Files werden als `UNKNOWN_FILE / WARNING` behandelt.

## 9. Inbound-Prozess

Regulärer Ablauf:

```text
/inbound/DONE_<file>.gpg
  -> Completion-Marker prüfen
  -> File/Set/Schedule bestimmen
  -> GPG entschlüsseln
  -> UTF-8 ohne BOM prüfen
  -> optional Base64 decodieren
  -> erneut UTF-8 prüfen
  -> /inbound/decrypted/<file>.csv
  -> passende DataSphere Taskchain via REST starten
  -> Taskchain-Status pollen
  -> File/Set/Process-Status aktualisieren
  -> HDLF-Audit schreiben
  -> Original archivieren
```

## 10. AS300 Outbound-Prozess

Quelle:

```text
/outbound/DS_DL_EX_AS300/initial/part-xxxxxxxxxx.csv
```

Bei mehreren `part-*.csv` werden die Parts in lexikalischer Reihenfolge zusammengeführt. Der CSV-Header wird nur einmal geschrieben.

Vor der Verschlüsselung gilt:

- UTF-8 ohne BOM
- Line Separator ausschließlich LF (`\n`)
- CRLF und einzelne CR werden auf LF normalisiert

Zieldatei:

```text
`/outbound/encrypted/<AS300_OUTPUT_FILENAME_PREFIX>_<UTC-Timestamp>.csv.gpg`
```

Danach wird die beim Start des Laufs vorhandene DataSphere-Quellstruktur archiviert:

```text
/outbound/archiv/DS_DL_EX_AS300/initial/part-xxxxxxxxxx.csv
```

Erst wenn alle Snapshot-Dateien erfolgreich im Archiv vorhanden sind, werden die ursprünglichen Dateien unter `/outbound/DS_DL_EX_AS300/initial/` gelöscht. Schlägt die Archivierung fehl, bleiben die Originale erhalten.

Dateien, die während des laufenden Jobs neu eintreffen und nicht zum Start-Snapshot gehörten, werden weder archiviert noch gelöscht; sie werden im nächsten Lauf verarbeitet.

Anschließend werden die benötigten HDLF-Verzeichnisse wieder sichergestellt.

## 11. Docker Image bauen

Empfohlener Tag:

```powershell
docker build --no-cache `
  -t ghcr.io/caso54/kyma-dev:process-control-v4-10 .
```

Kontrolle `common_hldf.py`:

```powershell
docker run --rm `
  --entrypoint sh `
  ghcr.io/caso54/kyma-dev:process-control-v4-10 `
  -c "test -f /opt/app/app/common_hldf.py && echo FOUND || echo MISSING"
```

Danach:

```powershell
docker push ghcr.io/caso54/kyma-dev:process-control-v4-10
```

## 12. Kubernetes Konfiguration einspielen

```powershell
kubectl apply -f .\k8s\configmap.yaml
kubectl apply -f .\k8s\cronjob-inbound.yaml
kubectl apply -f .\k8s\cronjob-outbound.yaml
```

Beide CronJobs sind im Paket zunächst `suspend: true`.

Kontrolle:

```powershell
kubectl get cronjobs -n dsp-poc
```

## 13. Manueller Inbound-Test

```powershell
kubectl create job `
  --from=cronjob/hldf-inbound-decrypt `
  inbound-v410-test-001 `
  -n dsp-poc

kubectl logs `
  -n dsp-poc `
  -l job-name=inbound-v410-test-001 `
  -c inbound `
  -f
```

## 14. Manueller Outbound-Test

Vorher mindestens ein gültiges DataSphere-File unter

```text
/outbound/DS_DL_EX_AS300/initial/part-*.csv
```

bereitstellen.

Dann:

```powershell
kubectl create job `
  --from=cronjob/hldf-outbound-encrypt `
  outbound-v410-test-001 `
  -n dsp-poc

kubectl logs `
  -n dsp-poc `
  -l job-name=outbound-v410-test-001 `
  -c outbound `
  -f
```

Erwartet:

```text
`/outbound/encrypted/<AS300_OUTPUT_FILENAME_PREFIX>_<Timestamp>.csv.gpg`
/outbound/archiv/DS_DL_EX_AS300/initial/part-*.csv
```

und das Quellverzeichnis `/outbound/DS_DL_EX_AS300/initial/` ist danach wieder vorhanden und leer, sofern während des Laufs keine neue Lieferung eingetroffen ist.

## 15. Audit prüfen

Das HDLF-Audit ist immer aktiv:

```text
/auditlog/
```

Relevante Events sind u. a.:

- `SCHEDULE_BYPASS`
- `FILE_NOT_SCHEDULED`
- `UNKNOWN_FILE`
- `DSP_START_API`
- `DSP_STATUS_API`
- `OUTBOUND_LINE_ENDINGS`
- `OUTBOUND_ARCHIVE`
- `OUTBOUND_CLEANUP`
- `OUTBOUND_AS300`

## 16. Produktivfreigabe

Erst nach erfolgreichen manuellen Tests die CronJobs aktivieren:

```powershell
kubectl patch cronjob hldf-inbound-decrypt -n dsp-poc -p '{"spec":{"suspend":false}}'
kubectl patch cronjob hldf-outbound-encrypt -n dsp-poc -p '{"spec":{"suspend":false}}'
```

Vor Produktivsetzung zusätzlich prüfen:

- tatsächlicher Open-SQL-Port und Schema
- OAuth Client Credentials
- Zugriff der Taskchain-API auf alle konfigurierten Taskchains
- HDLF Zertifikat/Private Key
- GPG Passphrases
- `common_hldf.py` inklusive `mkdirs`, Upload/Download, Rename, Exists und Delete-Operation
- Bankfeiertagskalender weiterhin aus oder fachlich vollständig gepflegt
- Schedule-Regeln der Sets/Files
- manuelle Notfallfunktion wieder `false`
