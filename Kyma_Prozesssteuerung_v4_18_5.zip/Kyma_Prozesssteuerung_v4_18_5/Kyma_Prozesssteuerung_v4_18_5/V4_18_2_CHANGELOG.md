# v4.18.2 Changelog

## Extraction-date validation switch
- Added `EXTRACTION_DATE_VALIDATION_ENABLED` (default `true`).
- `true`: existing validation via `allowed_extraction_date_offset_days` remains unchanged.
- `false`: extraction-date validation is bypassed independently of schedule enforcement.
- Bypass is logged as WARNING and written as `EXTRACTION_DATE_VALIDATION_BYPASS` audit event.
- Kubernetes image tag updated to `process-control-v4-18-2`.

## Safety
- Default remains strict (`true`).
- Unknown-file handling, schedule handling, Base64 streaming, safe archive lifecycle and OpenSQL switches are unchanged.
