\
# Kyma Process Control – BLKB / DataSphere

Dieses Projekt implementiert die neue Kyma-Prozesssteuerung für:
- Inbound Avaloq -> HDLF -> Kyma -> DataSphere Task Chain
- zentrale Statusablage in SAP DataSphere Open SQL (`FI_IT_M_TA_RUN_LOG_TC`)
- OAuth2 Client-Credentials für SAP DataSphere Tasks REST API
- Polling der Task-Chain-Logs
- Restart/Idempotenz auf Basis `DS_Run_UUID`
- GPG-Entschlüsselung und optionales Base64-Decoding
- Outbound AS-300: `part*.csv` zusammenführen -> ZIP -> GPG AES256 -> `/outbound/encrypted/`
- Retry, Logging und konfigurierbare Parallelität
- TEST/PROD ohne Codeänderung, nur über Secrets/ConfigMap

## Wichtige Annahme zum HDLF-Zugriff

Die reale HDLF-Anbindung wird über das bereits vorhandene Modul `common_hldf.py`
verwendet. Der Adapter erwartet die bestehenden Funktionen:
`list_files`, `list_dirs`, `mkdirs`, `rename`, `download_to_file`,
`upload_file_chunked`, `exists`, `create_empty_file`.

Damit bleibt die bisher funktionierende HDLF-Anbindung erhalten. Das Modul
`common_hldf.py` muss im Container unter `/opt/app/app/common_hldf.py`
vorhanden sein. Falls ihr euren bisherigen Docker-Build weiterverwendet,
kann die Datei einfach mitkopiert werden.

## DataSphere Open SQL Tabelle

Die Implementierung nutzt die bestehende Tabelle `FI_IT_M_TA_RUN_LOG_TC`.

Primärschlüssel:
- DS_Space_ID
- DS_Object_Type
- DS_TC_Group_ID
- DS_Object_ID
- DS_Run_UUID

Geschriebene Statusfelder:
- DS_Run_Start_Timestamp
- DS_Run_Status_DSP
- DS_Run_Status_Kyma
- DS_Run_Status_Ext
- DS_Run_End_Timestamp
- DS_Run_Message
- DS_Object_NR
- DS_File_Name
- DS_Run_Row_Count

## Kubernetes Secrets

Bereits vorgesehen:

`datasphere-oauth-secret`
- DSP_CLIENT_ID
- DSP_CLIENT_SECRET

`datasphere-sql-secret`
- DSP_SQL_USER
- DSP_SQL_PASSWORD

`inbound-gpg-secret`
- INBOUND_GPG_PASSPHRASE

`as300-gpg-secret`
- OUTBOUND_GPG_PASSPHRASE

## ConfigMap

Siehe `k8s/configmap.yaml`.

Wesentliche Werte:
- DSP_HOST
- DSP_TOKEN_URL
- DSP_SPACE_ID
- DSP_SQL_HOST
- DSP_SQL_PORT
- DSP_SQL_SCHEMA
- DSP_STATUS_TABLE
- HDLF_INBOUND_PATH
- HDLF_DECRYPTED_PATH
- HDLF_OUTBOUND_PATH
- HDLF_ENCRYPTED_PATH
- MAX_WORKERS
- POLL_INTERVAL_SECONDS
- MAX_RETRIES
- RETRY_WAIT_SECONDS
- PROCESS_RULES_FILE

## Startmodi

Inbound:
`python -m app.main inbound`

Outbound AS-300:
`python -m app.main outbound-as300`

## DataSphere Task Chain Regeln

Die Datei `config/process_rules.json` ordnet Dateimuster einer Task Chain zu.
Beispiel:

```json
[
  {
    "enabled": true,
    "file_pattern": "^_SAP_.*POSITION.*\\.gpg$",
    "space_id": "DSP_POC",
    "task_chain_id": "TC_POSITION",
    "tc_group_id": "001",
    "object_nr": "001",
    "object_type": "TASK_CHAIN",
    "decode_base64": true
  }
]
```

## Wichtiger Deployment-Hinweis

Die CronJobs laufen mit `concurrencyPolicy: Forbid`, damit derselbe CronJob
nicht parallel doppelt startet. Zusätzlich verhindert die Open-SQL-Prüfung
eine erneute Verarbeitung eines bereits erfolgreich abgeschlossenen Runs.

## Status-Mapping

Kyma:
- STARTED
- FILE_READY
- DSP_STARTED
- COMPLETED
- FAILED

DataSphere:
- SUBMITTED
- RUNNING
- COMPLETED
- FAILED
- CANCELED

## Noch einzutragende kundenspezifische Werte

Vor Deployment:
1. echte DataSphere URLs/Hosts/Port/Schema in ConfigMap setzen
2. echte Task-Chain-Regeln in `config/process_rules.json` eintragen
3. bestehendes `common_hldf.py` in `app/` übernehmen
4. GPG-Secrets anlegen
5. Image-Tag in den CronJobs anpassen


## v3 File-/Set-Steuerung

Neue Betriebsart: `python -m app.main sets`.

Umgesetzt: Extraktionsdatum Liefertag/Tag-1, tägliche DELTA, monatliche FULL, generische Files, getrennte File-/Set-Status, BLOCKED bei fehlenden Files, WAITING_PREDECESSOR für Folgesets und verspätete Files zum ältesten offenen Set. Vor Ersttest `config/schema.sql` ausführen. Dateimuster in `config/delivery_model.json` pflegen.


Hinweis v3.1: DELTA wird für die drei FULL-Objekte täglich erwartet; am Monatsstichtag kommt FULL zusätzlich hinzu. Generische Files werden in einem eigenen GENERIC_DAILY-Set einmal verarbeitet und von fachlichen Sets als Abhängigkeit verwendet.


## Current control architecture (v4.8)

- DataSphere Task Chain execution/status polling uses REST/OAuth and remains active for normal processing.
- Central process-steering table `FI_IT_M_TA_RUN_LOG_TC` is optional via `CENTRAL_OPENSQL_STATUS_ENABLED`.
- There is no additional OData/REST status-reporting channel.
- The standard audit log is always written as UTF-8 CSV to HDLF under `AUDIT_LOG_PATH` (default `/auditlog`).
- Bank holiday processing is optional via `BANK_HOLIDAY_CALENDAR_ENABLED` and is disabled by default.
- Emergency schedule bypass is available with `MANUAL_INGEST_MODE=true`.

Recommended normal settings:

```yaml
CENTRAL_OPENSQL_STATUS_ENABLED: "false"
BANK_HOLIDAY_CALENDAR_ENABLED: "false"
SCHEDULE_ENFORCEMENT_ENABLED: "true"
MANUAL_INGEST_MODE: "false"
INBOUND_DONE_PREFIX_ENABLED: "true"
```

Emergency/manual ingest:

```yaml
SCHEDULE_ENFORCEMENT_ENABLED: "true"
MANUAL_INGEST_MODE: "true"
```

Return `MANUAL_INGEST_MODE` to `false` immediately after the emergency/manual run.

## v4.9 AS-300 outbound

Source:
`/outbound/DS_DL_EX_AS300/initial/part-*.csv`

Target:
`/outbound/encrypted/<AS300_OUTPUT_FILENAME_PREFIX>_<UTC timestamp>.csv.gpg`

The job takes a snapshot of the source directory, creates the encrypted target and verifies that it exists. Only then are files from that snapshot deleted. HDLF may remove empty directories automatically; therefore required directories are re-created through the storage adapter before/after processing.

ConfigMap:
`HDLF_OUTBOUND_AS300_SOURCE_PATH=/outbound/DS_DL_EX_AS300/initial`

## Aktueller Stand v4.10

Die aktuelle Einrichtung ist in `INSTALLATION_GUIDE_V4_10.md` beschrieben. Wesentliche Neuerung ist die sichere Archivierung der ursprünglichen AS300-DataSphere-Struktur vor dem Löschen der Quelldateien.

## v4.17 performance note
Business payload processing is streaming/bounded-memory. See `V4_17_CHANGELOG.md` and `V4_17_TEST_REPORT.md`.

## v4.18 – Streaming, AUTO_STRICT und sicherer Lifecycle

Empfohlene Startkonfiguration:

```text
OPENSQL_PERSISTENCE_ENABLED=false
CENTRAL_OPENSQL_STATUS_ENABLED=false
DATASPHERE_TASKCHAIN_API_ENABLED=false
BASE64_MODE=AUTO_STRICT
BASE64_FALLBACK_FIELDS=
INBOUND_SUCCESS_LIFECYCLE=KEEP
OUTBOUND_SOURCE_LIFECYCLE=ARCHIVE
```

`AUTO_STRICT` schreibt eine CSV nur neu, wenn anhand einer begrenzten Streaming-Analyse eine Base64-Spalte erkannt wurde oder ein Header explizit in `BASE64_FALLBACK_FIELDS` konfiguriert ist. Für bekannte Base64-Felder ist die explizite Feldkonfiguration die robusteste Variante.

Bei Lifecycle `ARCHIVE` wird nie nur umbenannt: v4.18 kopiert, lädt die Archivkopie erneut herunter, vergleicht Größe und SHA-256 und löscht die Quelle erst bei erfolgreicher Integritätsprüfung.

## v4.18.2 – Extraction date validation switch

New ConfigMap switch:

```text
EXTRACTION_DATE_VALIDATION_ENABLED=true
```

- `true` (default): extraction dates are validated against `allowed_extraction_date_offset_days`.
- `false`: extraction-date validation is bypassed independently of schedule enforcement. Use for controlled recovery/manual processing only. A WARNING and audit event `EXTRACTION_DATE_VALIDATION_BYPASS` are written for every accepted mismatch.

Recommended production setting: `true`.
Controlled recovery setting: `false`, then return to `true` after the run.

## v4.18.3 FULL/DELTA sequencing
When `DATASPHERE_TASKCHAIN_API_ENABLED=false`, a paired FULL with status `DECRYPTED_ONLY` is considered sufficient only for releasing its paired DELTA in the same orchestration flow. `DECRYPTED_ONLY` is not treated as global `COMPLETED`/`LOADED` status. With the taskchain API enabled, the existing loaded/completed success semantics remain unchanged.

## v4.18.5

DataSphere-facing files in `/inbound/decrypted` now have stable names: everything from `_ACP` onward is removed. Example: `AVQ_SAP_NAME_INTL_ACP_2026_09_25_08_16_55.csv.gpg` becomes `AVQ_SAP_NAME_INTL.csv`. Source filenames remain unchanged for matching, audit, lifecycle and FULL/DELTA logic.
