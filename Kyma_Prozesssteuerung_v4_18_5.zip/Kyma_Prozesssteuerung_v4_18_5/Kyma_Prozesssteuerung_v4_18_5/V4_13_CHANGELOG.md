# v4.13 – HDLF upload contract and audit hardening

## Fixed
- Corrected `HldfStorage.upload(local, remote)` adapter to call the proven `common_hldf.upload_file_chunked(remote, local)` contract.
- This fixes uploads for `/auditlog`, `/inbound/decrypted`, `/outbound/encrypted`, and `/outbound/archiv` through the common adapter.
- HDLF audit work files are always created in a container temporary directory; an HDLF remote path is never used as a local filesystem path.
- Audit transport failures are logged as warnings and no longer abort the business process.

## Preserved
- HDLF paths are normalized to a single leading slash.
- Missing/empty HDLF prefixes are treated as empty where appropriate.
- No backend MKDIRS dependency.
- Phase 1 keeps OpenSQL disabled.
- User-provided `k8s/configmap.yaml` is retained as the deployment configuration basis.
