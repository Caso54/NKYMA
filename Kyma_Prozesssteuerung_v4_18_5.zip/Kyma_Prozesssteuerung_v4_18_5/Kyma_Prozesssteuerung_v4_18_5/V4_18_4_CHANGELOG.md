# v4.18.4

- Recognizes additional production Avaloq/SAP inbound filename variants observed in runtime logs without changing logical file IDs or task-chain mappings.
- Added aliases for ADDR, BAL_DELTA V01A, BP_PERSON_REL, CODE_TABLE V01A, COLLAT_ITEM, COLLECT_ITEM, CONT_ADD, MP_XRATE_CNVT, OBJ_FILTERED, PERSON_NAME_HIST and POS_BOOK_NNM V01A.
- Added `DROP_DUPLICATE_INBOUND_FILES` (default true). Files containing `__DUP_<8 hex>` before `.gpg` are deleted before business matching and audited as `DUPLICATE_FILE_DROPPED`.
- Existing v4.18.3 FULL/DELTA behavior remains unchanged.
