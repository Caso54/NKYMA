from pathlib import Path
from types import SimpleNamespace

import app.outbound as outbound_mod
from app.outbound import OutboundAS300


class FakeStorage:
    def __init__(self, files):
        self.files = dict(files)
        self.dirs = set()
        self.uploaded = {}
        self.deleted = []

    def ensure_dirs(self, *paths):
        self.dirs.update(p for p in paths if p)

    def mkdirs(self, path):
        self.dirs.add(path)

    def list_files(self, path):
        prefix = path.rstrip('/') + '/'
        return [p for p in sorted(self.files) if p.startswith(prefix) and '/' not in p[len(prefix):]]

    def exists(self, path):
        return path in self.files or path in self.uploaded

    def download(self, remote, local):
        Path(local).write_bytes(self.files[remote])

    def upload(self, local, remote):
        data = Path(local).read_bytes()
        self.uploaded[remote] = data
        self.files[remote] = data
        self.mkdirs(remote.rsplit('/', 1)[0])

    def delete_file(self, path):
        self.deleted.append(path)
        self.files.pop(path, None)


class FakeAudit:
    def __init__(self, *args, **kwargs):
        self.events=[]
    def write(self, **kwargs):
        self.events.append(kwargs)


def cfg():
    return SimpleNamespace(
        sql_host='h', sql_port=443, sql_user='u', sql_password='p', sql_schema='s',
        sql_status_table='T', central_opensql_status_enabled=False,
        audit_log_path='/auditlog', dsp_space_id='DS_DL', outbound_gpg_passphrase='secret',
        outbound_path='/outbound', outbound_source_path='/outbound/DS_DL_EX_AS300/initial',
        encrypted_path='/outbound/encrypted',
        outbound_archive_path='/outbound/archiv',
        as300_output_filename_prefix='SAP_AVQ_AS300_BOOKING',
    )


def test_outbound_uses_exact_source_and_csv_gpg_name(monkeypatch, tmp_path):
    src='/outbound/DS_DL_EX_AS300/initial/part-00001.csv'
    storage=FakeStorage({src: b'A;B\n1;M\xc3\xbcller\n'})
    monkeypatch.setattr(outbound_mod, 'HldfStorage', lambda: storage)
    monkeypatch.setattr(outbound_mod, 'HldfAuditLogger', FakeAudit)
    monkeypatch.setattr(outbound_mod, 'encrypt_symmetric', lambda src, dst, pw: Path(dst).write_bytes(b'GPG'+Path(src).read_bytes()))
    p=OutboundAS300(cfg())
    p.run()
    targets=[x for x in storage.uploaded if x.startswith('/outbound/encrypted/')]
    assert len(targets)==1
    assert Path(targets[0]).name.startswith('SAP_AVQ_AS300_BOOKING_')
    assert targets[0].endswith('.csv.gpg')
    assert '.zip' not in targets[0]
    assert src in storage.deleted
    assert '/outbound/archiv/DS_DL_EX_AS300/initial/part-00001.csv' in storage.uploaded
    assert '/outbound/DS_DL_EX_AS300/initial' in storage.dirs
    assert '/outbound/encrypted' in storage.dirs
    assert '/auditlog' in storage.dirs


def test_multiple_parts_are_merged_header_once(monkeypatch):
    base='/outbound/DS_DL_EX_AS300/initial'
    files={
        base+'/part-00001.csv': b'A;B\n1;x\n',
        base+'/part-00002.csv': b'A;B\n2;y\n',
    }
    storage=FakeStorage(files)
    monkeypatch.setattr(outbound_mod, 'HldfStorage', lambda: storage)
    monkeypatch.setattr(outbound_mod, 'HldfAuditLogger', FakeAudit)
    captured={}
    def fake_encrypt(src,dst,pw):
        captured['plain']=Path(src).read_text(encoding='utf-8')
        Path(dst).write_bytes(b'gpg')
    monkeypatch.setattr(outbound_mod, 'encrypt_symmetric', fake_encrypt)
    OutboundAS300(cfg()).run()
    assert captured['plain']=='A;B\n1;x\n2;y\n'
    assert set(storage.deleted)==set(files)
    assert '/outbound/archiv/DS_DL_EX_AS300/initial/part-00001.csv' in storage.uploaded
    assert '/outbound/archiv/DS_DL_EX_AS300/initial/part-00002.csv' in storage.uploaded


def test_new_file_arriving_after_snapshot_is_not_deleted(monkeypatch):
    base='/outbound/DS_DL_EX_AS300/initial'
    first=base+'/part-00001.csv'
    late=base+'/part-99999.csv'
    storage=FakeStorage({first:b'A;B\n1;x\n'})
    monkeypatch.setattr(outbound_mod, 'HldfStorage', lambda: storage)
    monkeypatch.setattr(outbound_mod, 'HldfAuditLogger', FakeAudit)
    def fake_encrypt(src,dst,pw):
        storage.files[late]=b'A;B\n9;late\n'
        Path(dst).write_bytes(b'gpg')
    monkeypatch.setattr(outbound_mod, 'encrypt_symmetric', fake_encrypt)
    OutboundAS300(cfg()).run()
    assert first in storage.deleted
    assert late not in storage.deleted
    assert late in storage.files


def test_cleanup_failure_does_not_remove_successful_target(monkeypatch):
    src='/outbound/DS_DL_EX_AS300/initial/part-00001.csv'
    storage=FakeStorage({src:b'A;B\n1;x\n'})
    def bad_delete(path):
        raise RuntimeError('delete unavailable')
    storage.delete_file=bad_delete
    monkeypatch.setattr(outbound_mod, 'HldfStorage', lambda: storage)
    monkeypatch.setattr(outbound_mod, 'HldfAuditLogger', FakeAudit)
    monkeypatch.setattr(outbound_mod, 'encrypt_symmetric', lambda src,dst,pw: Path(dst).write_bytes(b'gpg'))
    OutboundAS300(cfg()).run()
    assert any(p.endswith('.csv.gpg') for p in storage.uploaded)
    assert src in storage.files


def test_as300_crlf_is_normalized_to_lf_before_encryption(monkeypatch):
    src='/outbound/DS_DL_EX_AS300/initial/part-00001.csv'
    storage=FakeStorage({src:b'A;B\r\n1;x\r\n2;y\r\n'})
    monkeypatch.setattr(outbound_mod, 'HldfStorage', lambda: storage)
    monkeypatch.setattr(outbound_mod, 'HldfAuditLogger', FakeAudit)
    captured={}
    def fake_encrypt(src,dst,pw):
        captured['plain']=Path(src).read_bytes()
        Path(dst).write_bytes(b'gpg')
    monkeypatch.setattr(outbound_mod, 'encrypt_symmetric', fake_encrypt)
    OutboundAS300(cfg()).run()
    assert b'\r' not in captured['plain']
    assert captured['plain'] == b'A;B\n1;x\n2;y\n'


def test_as300_mixed_line_endings_are_normalized_to_lf(monkeypatch):
    src='/outbound/DS_DL_EX_AS300/initial/part-00001.csv'
    storage=FakeStorage({src:b'A;B\r\n1;x\n2;y\r3;z\r\n'})
    monkeypatch.setattr(outbound_mod, 'HldfStorage', lambda: storage)
    monkeypatch.setattr(outbound_mod, 'HldfAuditLogger', FakeAudit)
    captured={}
    def fake_encrypt(src,dst,pw):
        captured['plain']=Path(src).read_bytes()
        Path(dst).write_bytes(b'gpg')
    monkeypatch.setattr(outbound_mod, 'encrypt_symmetric', fake_encrypt)
    OutboundAS300(cfg()).run()
    assert b'\r' not in captured['plain']
    assert captured['plain'].count(b'\n') >= 3


def test_as300_lf_input_stays_lf(monkeypatch):
    src='/outbound/DS_DL_EX_AS300/initial/part-00001.csv'
    storage=FakeStorage({src:b'A;B\n1;x\n'})
    monkeypatch.setattr(outbound_mod, 'HldfStorage', lambda: storage)
    monkeypatch.setattr(outbound_mod, 'HldfAuditLogger', FakeAudit)
    captured={}
    def fake_encrypt(src,dst,pw):
        captured['plain']=Path(src).read_bytes()
        Path(dst).write_bytes(b'gpg')
    monkeypatch.setattr(outbound_mod, 'encrypt_symmetric', fake_encrypt)
    OutboundAS300(cfg()).run()
    assert captured['plain'] == b'A;B\n1;x\n'


def test_archive_failure_keeps_original_source(monkeypatch):
    src='/outbound/DS_DL_EX_AS300/initial/part-00001.csv'
    storage=FakeStorage({src:b'A;B\n1;x\n'})
    original_upload=storage.upload
    def fail_archive(local, remote):
        if remote.startswith('/outbound/archiv/'):
            raise RuntimeError('archive unavailable')
        return original_upload(local, remote)
    storage.upload=fail_archive
    monkeypatch.setattr(outbound_mod, 'HldfStorage', lambda: storage)
    monkeypatch.setattr(outbound_mod, 'HldfAuditLogger', FakeAudit)
    monkeypatch.setattr(outbound_mod, 'encrypt_symmetric', lambda src,dst,pw: Path(dst).write_bytes(b'gpg'))
    proc=OutboundAS300(cfg())
    proc.run()
    assert src in storage.files
    assert src not in storage.deleted
    assert any(p.endswith('.csv.gpg') for p in storage.uploaded)
    assert any(e.get('process_type')=='OUTBOUND_ARCHIVE' and e.get('status')=='FAILED' for e in proc.hldf_audit.events)


def test_outbound_archive_preserves_datasphere_directory_structure(monkeypatch):
    base='/outbound/DS_DL_EX_AS300/initial'
    src=base+'/part-12345.csv'
    storage=FakeStorage({src:b'A;B\n1;x\n'})
    monkeypatch.setattr(outbound_mod, 'HldfStorage', lambda: storage)
    monkeypatch.setattr(outbound_mod, 'HldfAuditLogger', FakeAudit)
    monkeypatch.setattr(outbound_mod, 'encrypt_symmetric', lambda src,dst,pw: Path(dst).write_bytes(b'gpg'))
    OutboundAS300(cfg()).run()
    archived='/outbound/archiv/DS_DL_EX_AS300/initial/part-12345.csv'
    assert archived in storage.uploaded
    assert storage.uploaded[archived] == b'A;B\n1;x\n'
    assert src in storage.deleted


def test_as300_output_filename_prefix_is_configurable(monkeypatch):
    src='/outbound/DS_DL_EX_AS300/initial/part-00001.csv'
    storage=FakeStorage({src:b'A;B\n1;x\n'})
    monkeypatch.setattr(outbound_mod, 'HldfStorage', lambda: storage)
    monkeypatch.setattr(outbound_mod, 'HldfAuditLogger', FakeAudit)
    monkeypatch.setattr(outbound_mod, 'encrypt_symmetric', lambda src,dst,pw: Path(dst).write_bytes(b'gpg'))
    c=cfg()
    c.as300_output_filename_prefix='CUSTOM_AS300_PREFIX'
    OutboundAS300(c).run()
    targets=[x for x in storage.uploaded if x.startswith('/outbound/encrypted/')]
    assert len(targets)==1
    assert Path(targets[0]).name.startswith('CUSTOM_AS300_PREFIX_')
    assert targets[0].endswith('.csv.gpg')
