import json
from datetime import date
from pathlib import Path
from app.delivery_model import DeliveryModel
from app.set_orchestrator import SetOrchestrator

ROOT=Path(__file__).resolve().parents[1]

def test_runtime_unknown_aliases_are_known():
    model=DeliveryModel.load(str(ROOT/'config/delivery_model.json'))
    names=[
      'AVQ_SAP_ADDR_ACP_2026_09_25_16_05_06.csv.gpg',
      'AVQ_SAP_BAL_DELTA_ACP_V01A_2026_09_26_04_37_46.csv.gpg',
      'AVQ_SAP_BP_PERSON_REL_ACP_2026_09_25_16_12_26.csv.gpg',
      'AVQ_SAP_CODE_TABLE_ACP_V01A_2026_09_25_17_52_13.csv.gpg',
      'AVQ_SAP_COLLAT_ITEM_ACP_2026_09_25_16_06_06.csv.gpg',
      'AVQ_SAP_COLLECT_ITEM_ACP_2026_09_25_16_53_17.csv.gpg',
      'AVQ_SAP_CONT_ADD_ACP_2026_09_25_16_52_33.csv.gpg',
      'AVQ_SAP_MP_XRATE_CNVT_ACP_2026_09_26_00_07_47.csv.gpg',
      'AVQ_SAP_OBJ_FILTERED_ACP_2026_09_25_10_40_20.csv.gpg',
      'AVQ_SAP_PERSON_NAME_HIST_ACP_2026_09_25_16_30_00.csv.gpg',
      'AVQ_SAP_POS_BOOK_NNM_ACP_V01A_2026_09_26_02_48_01.csv.gpg',
    ]
    for name in names:
        matches=[]
        for s in model.sets:
            for f in s.required_files+s.optional_files:
                if f.parse(name, default_extraction_date=date(2026,9,27)):
                    matches.append((s.set_id,f.file_id))
        assert len(matches)==1, (name,matches)

def test_dup_name_detection():
    assert SetOrchestrator._is_duplicate_inbound_name('AVQ_SAP_ADDR_ACP_2026_09_25_16_05_06.csv__DUP_3236db8c.gpg')
    assert not SetOrchestrator._is_duplicate_inbound_name('AVQ_SAP_ADDR_ACP_2026_09_25_16_05_06.csv.gpg')

def test_duplicate_drop_calls_storage_delete_and_audits():
    class Storage:
        def __init__(self): self.deleted=[]
        def delete_file(self,p): self.deleted.append(p)
    class Cfg:
        inbound_path='/inbound'
    o=SetOrchestrator.__new__(SetOrchestrator)
    o.storage=Storage(); o.cfg=Cfg(); events=[]
    o._audit=lambda **kw: events.append(kw)
    ok=o._drop_duplicate_inbound({'path':'/inbound/X.csv__DUP_1234abcd.gpg'}, 'X.csv__DUP_1234abcd.gpg')
    assert ok is True
    assert o.storage.deleted == ['/inbound/X.csv__DUP_1234abcd.gpg']
    assert events[0]['process_type']=='DUPLICATE_FILE_DROPPED'
