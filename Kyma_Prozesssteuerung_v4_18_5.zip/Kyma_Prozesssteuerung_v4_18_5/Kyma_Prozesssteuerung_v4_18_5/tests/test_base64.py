\
from app.csv_transform import _decode_candidate

def test_base64_short_values():
    assert _decode_candidate("MzY=") == "36"
    assert _decode_candidate("NDEwNw==") == "4107"
    assert _decode_candidate("not_base64") == "not_base64"
