from types import SimpleNamespace
import os
import pytest

from app.config import Settings
from app.memory_repo import InMemoryDeliveryRepository, InMemoryProcessRepository
import app.set_orchestrator as so


class FakeStorage:
    def ensure_dirs(self, *paths): pass
    def mkdirs(self, path): pass


class FakeAudit:
    def __init__(self, *a, **k): self.events=[]
    def write(self, **kwargs): self.events.append(kwargs)


class FakeDSPCtor:
    def __init__(self, *a, **k): pass


def base_env(monkeypatch):
    values = {
        "DSP_HOST": "https://example.invalid",
        "DSP_TOKEN_URL": "https://oauth.invalid/token",
        "DSP_CLIENT_ID": "cid",
        "DSP_CLIENT_SECRET": "secret",
        "DSP_SPACE_ID": "DS_DL",
        "DELIVERY_MODEL_FILE": os.path.abspath("config/delivery_model.json"),
        "TASKCHAINS_FILE": os.path.abspath("config/datasphere_taskchains.json"),
        "BANK_HOLIDAY_CALENDAR_FILE": os.path.abspath("config/bank_holidays.json"),
        "OPENSQL_PERSISTENCE_ENABLED": "false",
        "CENTRAL_OPENSQL_STATUS_ENABLED": "false",
        "SCHEDULE_ENFORCEMENT_ENABLED": "false",
        "INBOUND_DONE_PREFIX_ENABLED": "false",
    }
    for k,v in values.items(): monkeypatch.setenv(k,v)
    for k in ("DSP_SQL_HOST","DSP_SQL_USER","DSP_SQL_PASSWORD","DSP_SQL_SCHEMA"):
        monkeypatch.delenv(k, raising=False)


def test_phase1_settings_do_not_require_sql(monkeypatch):
    base_env(monkeypatch)
    cfg = Settings.from_env()
    assert cfg.opensql_persistence_enabled is False
    assert cfg.central_opensql_status_enabled is False
    assert cfg.sql_host == ""
    assert cfg.sql_user == ""


def test_phase1_set_orchestrator_uses_memory_and_no_sql(monkeypatch):
    base_env(monkeypatch)
    cfg = Settings.from_env()
    monkeypatch.setattr(so, "HldfStorage", FakeStorage)
    monkeypatch.setattr(so, "HldfAuditLogger", FakeAudit)
    monkeypatch.setattr(so, "DataSphereClient", FakeDSPCtor)

    orch = so.SetOrchestrator(cfg)
    assert isinstance(orch.repo, InMemoryDeliveryRepository)
    assert isinstance(orch.process_repo, InMemoryProcessRepository)
    assert orch.audit is None
    assert orch.central_opensql is None


def test_phase1_taskchain_api_runs_without_sql(monkeypatch):
    base_env(monkeypatch)
    monkeypatch.setenv("DATASPHERE_TASKCHAIN_API_ENABLED", "true")
    cfg = Settings.from_env()
    monkeypatch.setattr(so, "HldfStorage", FakeStorage)
    monkeypatch.setattr(so, "HldfAuditLogger", FakeAudit)
    monkeypatch.setattr(so, "DataSphereClient", FakeDSPCtor)
    orch = so.SetOrchestrator(cfg)

    calls=[]
    class DSP:
        def run_task_chain(self, space, tc, params):
            calls.append(("POST", space, tc, params))
            return SimpleNamespace(log_id="LOG-1")
        def get_task_status(self, space, log_id):
            calls.append(("GET", space, log_id))
            return "SUCCEEDED"
    orch.dsp = DSP()
    s = SimpleNamespace(space_id="DS_DL", set_id="XX")
    f = SimpleNamespace(file_id="FILE_X")
    orch._run_file_taskchain(s=s, f=f, run_uuid="RUN-1", set_date=orch.model.today(), task_chain_id="TC_X", endpoint="https://example.invalid/tc")
    assert [c[0] for c in calls] == ["POST", "GET"]
    assert any(e["process_type"] == "DSP_START_API" and e["status"] == "SUCCESS" for e in orch.hldf_audit.events)
    assert any(e["process_type"] == "DSP_TASK_STATUS" and e["status"] == "SUCCEEDED" for e in orch.hldf_audit.events)


def test_phase2_requires_sql_credentials(monkeypatch):
    base_env(monkeypatch)
    monkeypatch.setenv("OPENSQL_PERSISTENCE_ENABLED", "true")
    with pytest.raises(RuntimeError, match="DSP_SQL_HOST"):
        Settings.from_env()


def test_phase3_central_sql_also_requires_sql_credentials(monkeypatch):
    base_env(monkeypatch)
    monkeypatch.setenv("CENTRAL_OPENSQL_STATUS_ENABLED", "true")
    with pytest.raises(RuntimeError, match="DSP_SQL_HOST"):
        Settings.from_env()
