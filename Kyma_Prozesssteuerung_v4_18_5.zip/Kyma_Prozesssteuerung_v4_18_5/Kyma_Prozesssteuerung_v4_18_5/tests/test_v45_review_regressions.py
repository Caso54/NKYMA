from datetime import date
from pathlib import Path
from types import SimpleNamespace

from app.set_orchestrator import SetOrchestrator


class ModelNoDaily:
    sets = [SimpleNamespace(set_id='LI')]
    def today(self): return date(2026, 9, 24)
    def active_required_files(self, s, d): return ()

class RepoTrack:
    def __init__(self): self.ensure_set_calls=[]; self.ensure_file_calls=[]
    def ensure_set(self,*a): self.ensure_set_calls.append(a)
    def ensure_expected_file(self,*a): self.ensure_file_calls.append(a)


def test_monthly_only_set_does_not_create_empty_daily_predecessor():
    o=SetOrchestrator.__new__(SetOrchestrator)
    o.model=ModelNoDaily(); o.repo=RepoTrack()
    o.initialize_today_sets()
    assert o.repo.ensure_set_calls == []


def test_optional_files_are_part_of_ingest_matching_source_code():
    # Regression guard on the actual method implementation: optional files must be traversed.
    import inspect
    src=inspect.getsource(SetOrchestrator.ingest_available_files)
    assert 's.required_files + s.optional_files' in src
    assert 'all_active_files' in src


def test_base64_decode_is_wired_into_sets_processing_source_code():
    import inspect
    src=inspect.getsource(SetOrchestrator._process_file)
    assert 'decode_base64_csv' in src
    assert 'use_base64_decode' in src
    assert 'validate_utf8_file(transformed, allow_bom=False)' in src


def test_failed_sets_are_reopenable_for_late_redelivery_source_code():
    from app import delivery_repo
    import inspect
    src=inspect.getsource(delivery_repo.DeliveryRepository.oldest_open_missing_set)
    assert "FAILED" in src


def test_predecessor_ignores_zero_expected_rows_source_code():
    from app import delivery_repo
    import inspect
    src=inspect.getsource(delivery_repo.DeliveryRepository.predecessor_completed)
    assert 'COALESCE("EXPECTED_FILES",0)>0' in src
