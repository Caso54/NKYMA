import sys
import types
from datetime import date
from types import SimpleNamespace

hdbcli = types.ModuleType('hdbcli')
hdbcli.dbapi = types.SimpleNamespace(connect=lambda **kwargs: None)
sys.modules.setdefault('hdbcli', hdbcli)

from app.set_orchestrator import SetOrchestrator


def test_done_prefix_switch_and_strip():
    o = SetOrchestrator.__new__(SetOrchestrator)
    o.cfg = SimpleNamespace(inbound_done_prefix_enabled=True, inbound_done_prefix='DONE_')
    assert o._logical_inbound_name('DONE_AVQ_SAP_OBJ_ACP.gpg') == 'AVQ_SAP_OBJ_ACP.gpg'
    assert o._logical_inbound_name('AVQ_SAP_OBJ_ACP.gpg') is None
    o.cfg = SimpleNamespace(inbound_done_prefix_enabled=False, inbound_done_prefix='DONE_')
    assert o._logical_inbound_name('AVQ_SAP_OBJ_ACP.gpg') == 'AVQ_SAP_OBJ_ACP.gpg'


def test_full_candidate_sorted_before_delta_even_if_delta_arrives_first():
    o = SetOrchestrator.__new__(SetOrchestrator)
    s = SimpleNamespace(set_id='AL')
    full = SimpleNamespace(file_id='FULL', pair_id='OBJ')
    delta = SimpleNamespace(file_id='DELTA', pair_id='OBJ')
    d = date(2026, 10, 1)
    # tuple shape mirrors ingest_available_files candidate tuple
    delta_c = ('itemD','DONE_DELTA.gpg',s,delta,d,d,d,'DELTA','DELTA.gpg')
    full_c = ('itemF','DONE_FULL.gpg',s,full,d,d,d,'FULL','FULL.gpg')
    ordered = sorted([delta_c, full_c], key=o._candidate_sort_key)
    assert ordered[0][3].file_id == 'FULL'
    assert ordered[1][3].file_id == 'DELTA'


def test_paired_full_dependency_detected_for_delta():
    o = SetOrchestrator.__new__(SetOrchestrator)
    full = SimpleNamespace(file_id='FULL', pair_id='OBJ', required_mode='FULL')
    delta = SimpleNamespace(file_id='DELTA', pair_id='OBJ', required_mode='DELTA')
    s = SimpleNamespace(set_id='AL')
    class M:
        def active_required_files(self, set_def, set_date):
            return (full, delta)
    o.model = M()
    assert o._paired_full_file(s, delta, date(2026,10,1)) is full
    assert o._paired_full_file(s, full, date(2026,10,1)) is None
