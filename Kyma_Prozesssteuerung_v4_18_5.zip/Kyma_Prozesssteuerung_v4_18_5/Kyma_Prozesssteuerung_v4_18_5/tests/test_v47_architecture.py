from pathlib import Path
from types import SimpleNamespace

from app.hldf_audit import HldfAuditLogger
from app.set_orchestrator import SetOrchestrator


class FakeStorage:
    def __init__(self):
        self.files = {}
    def exists(self, path):
        return path in self.files
    def download(self, remote, local):
        Path(local).write_bytes(self.files[remote])
    def upload(self, local, remote):
        self.files[remote] = Path(local).read_bytes()


def test_hldf_audit_is_utf8_and_daily():
    st = FakeStorage()
    log = HldfAuditLogger(st, "/auditlog", "SETS")
    remote = log.write(run_uuid="u1", process_type="TEST", status="SUCCESS", message="Grüezi Zürich – Müller")
    assert remote.startswith("/auditlog/audit_sets_")
    text = st.files[remote].decode("utf-8")
    assert "Grüezi Zürich – Müller" in text
    assert text.startswith("TIMESTAMP_UTC;")


def test_hldf_audit_appends_existing_daily_file():
    st = FakeStorage()
    log = HldfAuditLogger(st, "/auditlog", "SETS")
    remote = log.write(run_uuid="u1", process_type="A", status="SUCCESS")
    log.write(run_uuid="u2", process_type="B", status="WARNING")
    text = st.files[remote].decode("utf-8")
    assert text.count("TIMESTAMP_UTC;") == 1
    assert ";A;SUCCESS;" in text
    assert ";B;WARNING;" in text


def test_set_audit_writes_hldf_even_when_opensql_audit_fails():
    class H:
        def __init__(self): self.calls = 0
        def write(self, **kwargs): self.calls += 1
    class Broken:
        def write(self, **kwargs): raise RuntimeError("db down")
    o = SetOrchestrator.__new__(SetOrchestrator)
    o.hldf_audit = H()
    o.audit = Broken()
    o._audit(process_type="TEST", status="SUCCESS", message="x")
    assert o.hldf_audit.calls == 1


def test_central_opensql_disabled_is_noop():
    o = SetOrchestrator.__new__(SetOrchestrator)
    o.central_opensql = None
    o._central_control_create(s=SimpleNamespace(space_id="S", set_id="SET"), f=SimpleNamespace(file_id="F"), run_uuid="u", task_chain_id="TC")
    o._central_control_update(s=SimpleNamespace(space_id="S", set_id="SET"), run_uuid="u", task_chain_id="TC", dsp_status="RUNNING")


def test_no_odata_status_module_or_config():
    root = Path(__file__).resolve().parents[1]
    assert not (root / "app" / "central_status.py").exists()
    config = (root / "k8s" / "configmap.yaml").read_text(encoding="utf-8")
    assert "CENTRAL_STATUS_REPORTING_ENABLED" not in config
    assert "CENTRAL_STATUS_ENDPOINT" not in config
    assert 'CENTRAL_OPENSQL_STATUS_ENABLED: "false"' in config
    assert 'AUDIT_LOG_PATH: "/auditlog"' in config

def test_central_opensql_enabled_receives_status():
    class R:
        def __init__(self): self.created=[]; self.updated=[]
        def create_run(self, **kwargs): self.created.append(kwargs)
        def update_run(self, **kwargs): self.updated.append(kwargs)
    r=R()
    o=SetOrchestrator.__new__(SetOrchestrator)
    o.central_opensql=r
    s=SimpleNamespace(space_id="DS_DL", set_id="AL")
    f=SimpleNamespace(file_id="FILE1")
    o._central_control_create(s=s,f=f,run_uuid="run-1",task_chain_id="TC1",message="start")
    o._central_control_update(s=s,run_uuid="run-1",task_chain_id="TC1",dsp_status="RUNNING",kyma_status="PROCESSING")
    assert r.created[0]["run_uuid"] == "run-1"
    assert r.updated[0]["dsp_status"] == "RUNNING"
