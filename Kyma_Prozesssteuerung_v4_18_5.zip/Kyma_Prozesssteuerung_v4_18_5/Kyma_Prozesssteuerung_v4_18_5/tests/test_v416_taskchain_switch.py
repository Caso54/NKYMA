from pathlib import Path


def test_configmap_disables_taskchain_api_for_phase1():
    text = Path("k8s/configmap.yaml").read_text(encoding="utf-8")
    assert 'DATASPHERE_TASKCHAIN_API_ENABLED: "false"' in text


def test_orchestrator_has_decrypt_only_gate_before_taskchain():
    code = Path("app/set_orchestrator.py").read_text(encoding="utf-8")
    gate = code.index("if not self.cfg.datasphere_taskchain_api_enabled")
    meta = code.index("task_chain_id, endpoint = self._taskchain_meta", gate)
    run = code.index("self._run_file_taskchain", meta)
    assert gate < meta < run
    assert 'status="DECRYPTED_ONLY"' in code
    assert 'process_type="TASKCHAIN_API_SKIPPED"' in code


def test_datasphere_client_is_not_constructed_when_disabled():
    code = Path("app/set_orchestrator.py").read_text(encoding="utf-8")
    assert "if cfg.datasphere_taskchain_api_enabled else None" in code


def test_taskchain_run_is_guarded_when_disabled():
    code = Path("app/set_orchestrator.py").read_text(encoding="utf-8")
    assert 'raise RuntimeError("DataSphere taskchain API is disabled")' in code


def test_default_settings_switch_is_false():
    code = Path("app/config.py").read_text(encoding="utf-8")
    assert 'env_bool("DATASPHERE_TASKCHAIN_API_ENABLED", False)' in code
