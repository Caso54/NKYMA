from pathlib import Path
import json
from datetime import date
from types import SimpleNamespace

from app.delivery_model import DeliveryModel
from app.set_orchestrator import SetOrchestrator


def _model(tmp_path, *, set_schedule=None):
    delivery = {
        "timezone": "Europe/Zurich",
        "rules": {"allowed_extraction_date_offset_days": [0, -1]},
        "sets": [{
            "set_id": "T1", "enabled": True, "space_id": "DS_DL",
            "schedule": set_schedule,
            "required_files": [{
                "file_id": "FILE_A",
                "pattern": r"^FILE_A(?:_(?P<extract_date>\d{8}))?\.gpg$",
                "fixed_mode": "DELTA", "active_when": "ALWAYS", "required": True,
            }]
        }]
    }
    p = tmp_path / "delivery.json"
    p.write_text(json.dumps(delivery), encoding="utf-8")
    return DeliveryModel.load(str(p))


class FakeStorage:
    def __init__(self, files):
        self.files = {((x if str(x).startswith("/") else "/inbound/" + str(x))): b"test-payload" for x in files}
        self.renames = []
        self.deleted = []
        self.uploaded = []
    def list_files(self, path):
        prefix = path.rstrip("/") + "/"
        return [p for p in sorted(self.files) if p.startswith(prefix) and "/" not in p[len(prefix):]]
    def mkdirs(self,path): pass
    def exists(self,path): return path in self.files
    def rename(self,src,dst): self.renames.append((src,dst))
    def download(self, remote, local): Path(local).write_bytes(self.files[remote])
    def upload(self, local, remote):
        self.files[remote] = Path(local).read_bytes(); self.uploaded.append(remote)
    def delete_file(self, path):
        self.deleted.append(path); self.files.pop(path, None)


class FakeRepo:
    def __init__(self):
        self.sets=[]; self.expected=[]; self.updated=[]
    def ensure_set(self,*a,**k): self.sets.append((a,k))
    def ensure_expected_file(self,*a,**k): self.expected.append((a,k))
    def oldest_open_missing_set(self,*a,**k): return None
    def file_success_exists(self,*a,**k): return False
    def summarize_set(self, set_id, set_date, ids):
        return {"expected":len(ids),"received":len(ids),"success":len(ids),"missing":0,"failed":0}
    def predecessor_completed(self,*a,**k): return True
    def dependencies_completed(self,*a,**k): return True
    def update_set(self,*a,**k): self.updated.append((a,k))


class Audit:
    def __init__(self): self.events=[]
    def write(self, **kwargs): self.events.append(kwargs)


def _orch(model, files, *, manual=False, enforcement=True):
    o=SetOrchestrator.__new__(SetOrchestrator)
    o.model=model
    o.storage=FakeStorage(files)
    o.repo=FakeRepo()
    o.audit=Audit()
    o.hldf_audit=Audit()
    o.cfg=SimpleNamespace(
        inbound_path="/inbound", inbound_archive_path="/inbound/archiv",
        archive_unscheduled_files=True, archive_unknown_files=True,
        inbound_done_prefix_enabled=True, inbound_done_prefix="DONE_",
        manual_ingest_mode=manual, schedule_enforcement_enabled=enforcement,
    )
    o.processed=[]
    o._process_file=lambda *a,**k: o.processed.append((a,k))
    return o


def test_normal_mode_archives_known_unscheduled_file(tmp_path):
    m=_model(tmp_path, set_schedule={"type":"WEEKDAYS"})
    object.__setattr__(m, "today", lambda: date(2026,9,26)) # Saturday
    o=_orch(m,["DONE_FILE_A_20260926.gpg"],manual=False,enforcement=True)
    o.ingest_available_files()
    assert not o.processed
    assert o.storage.uploaded
    assert o.storage.deleted
    assert any(e["process_type"]=="FILE_NOT_SCHEDULED" for e in o.hldf_audit.events)


def test_manual_mode_processes_known_unscheduled_file_and_warns(tmp_path):
    m=_model(tmp_path, set_schedule={"type":"WEEKDAYS"})
    object.__setattr__(m, "today", lambda: date(2026,9,26)) # Saturday
    o=_orch(m,["DONE_FILE_A_20260926.gpg"],manual=True,enforcement=True)
    o.ingest_available_files()
    assert len(o.processed)==1
    assert o.storage.renames == []
    assert any(e["process_type"]=="SCHEDULE_BYPASS" and e["status"]=="WARNING" for e in o.hldf_audit.events)
    # Only the actually supplied file is registered for the manual batch.
    assert len(o.repo.expected)==1
    assert o.repo.expected[0][0][2] == "FILE_A"


def test_schedule_enforcement_disabled_also_bypasses_schedule(tmp_path):
    m=_model(tmp_path, set_schedule={"type":"WEEKDAYS"})
    object.__setattr__(m, "today", lambda: date(2026,9,26))
    o=_orch(m,["DONE_FILE_A_20260926.gpg"],manual=False,enforcement=False)
    o.ingest_available_files()
    assert len(o.processed)==1
    ev=[e for e in o.hldf_audit.events if e["process_type"]=="SCHEDULE_BYPASS"]
    assert ev and ev[0]["details"]["bypass_mode"]=="SCHEDULE_ENFORCEMENT_DISABLED"


def test_manual_mode_does_not_allow_unknown_file(tmp_path):
    m=_model(tmp_path, set_schedule={"type":"WEEKDAYS"})
    object.__setattr__(m, "today", lambda: date(2026,9,26))
    o=_orch(m,["DONE_UNKNOWN_20260926.gpg"],manual=True,enforcement=True)
    o.ingest_available_files()
    assert not o.processed
    assert o.storage.uploaded
    assert o.storage.deleted
    assert any(e["process_type"]=="UNKNOWN_FILE" for e in o.hldf_audit.events)


def test_manual_mode_still_requires_done_prefix(tmp_path):
    m=_model(tmp_path, set_schedule={"type":"WEEKDAYS"})
    object.__setattr__(m, "today", lambda: date(2026,9,26))
    o=_orch(m,["FILE_A_20260926.gpg"],manual=True,enforcement=True)
    o.ingest_available_files()
    assert not o.processed
    assert o.storage.renames == []
    assert o.hldf_audit.events == []


def test_manual_delta_alone_is_allowed_without_forcing_inactive_full():
    o=SetOrchestrator.__new__(SetOrchestrator)
    o.cfg=SimpleNamespace(manual_ingest_mode=True, schedule_enforcement_enabled=True)
    full=SimpleNamespace(file_id='FULL', pair_id='OBJ', required_mode='FULL')
    delta=SimpleNamespace(file_id='DELTA', pair_id='OBJ', required_mode='DELTA')
    s=SimpleNamespace(set_id='AL', required_files=(full,delta), optional_files=())
    class M:
        def active_required_files(self, set_def, set_date): return ()
    o.model=M()
    assert o._paired_full_file(s, delta, date(2026,9,24)) is None


def test_manual_full_and_delta_same_batch_sorts_full_first():
    o=SetOrchestrator.__new__(SetOrchestrator)
    s=SimpleNamespace(set_id='AL')
    full=SimpleNamespace(file_id='FULL', pair_id='OBJ')
    delta=SimpleNamespace(file_id='DELTA', pair_id='OBJ')
    d=date(2026,9,24)
    delta_c=('d','DONE_DELTA.gpg',s,delta,d,d,d,'DELTA','DELTA.gpg')
    full_c=('f','DONE_FULL.gpg',s,full,d,d,d,'FULL','FULL.gpg')
    ordered=sorted([delta_c,full_c], key=o._candidate_sort_key)
    assert [x[3].file_id for x in ordered] == ['FULL','DELTA']
