\
from app.rules import ProcessRule

def test_rule():
    r = ProcessRule(
        file_pattern=r"^_SAP_.*\.gpg$",
        space_id="S",
        task_chain_id="TC",
        tc_group_id="001",
        object_nr="001",
    )
    assert r.matches("_SAP_TEST.gpg")
    assert not r.matches("ABC.csv")
