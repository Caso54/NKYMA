from pathlib import Path

import pytest

from app.csv_transform import analyze_base64_csv, prepare_csv_payload
from app.file_integrity import file_integrity
from app.file_lifecycle import apply_remote_lifecycle


class MemoryStorage:
    def __init__(self, files=None):
        self.files = dict(files or {})
        self.deleted = []
        self.upload_count = 0
    def download(self, remote, local):
        Path(local).write_bytes(self.files[remote])
    def upload(self, local, remote):
        self.upload_count += 1
        self.files[remote] = Path(local).read_bytes()
    def exists(self, path):
        return path in self.files
    def delete_file(self, path):
        self.deleted.append(path)
        self.files.pop(path, None)


def test_auto_strict_no_base64_does_not_rewrite(tmp_path):
    src = tmp_path / "plain.csv"
    dst = tmp_path / "decoded.csv"
    src.write_text("ID;NAME;DATE\n1;Müller;2026-09-26\n2;Meier;2026-09-27\n", encoding="utf-8")
    upload, rows, decision = prepare_csv_payload(str(src), str(dst), mode="AUTO_STRICT")
    assert upload == str(src)
    assert rows is None
    assert decision.rewrite_required is False
    assert not dst.exists()


def test_auto_strict_detects_encoded_column_only(tmp_path):
    src = tmp_path / "encoded.csv"
    dst = tmp_path / "decoded.csv"
    src.write_text("ID;TEXT;DATE\n1;SGVsbG8=;2026-09-26\n2;V29ybGQ=;2026-09-27\n", encoding="utf-8")
    decision = analyze_base64_csv(str(src))
    assert decision.decode_fields == ("TEXT",)
    upload, rows, decision = prepare_csv_payload(str(src), str(dst), mode="AUTO_STRICT")
    assert upload == str(dst)
    assert rows == 2
    assert dst.read_text(encoding="utf-8") == "ID;TEXT;DATE\n1;Hello;2026-09-26\n2;World;2026-09-27\n"


def test_fallback_field_forces_column_decode(tmp_path):
    src = tmp_path / "fallback.csv"
    dst = tmp_path / "decoded.csv"
    # MzY= is short but valid; fallback makes the intended field explicit.
    src.write_text("ID;CODE\n1;MzY=\n", encoding="utf-8")
    upload, rows, decision = prepare_csv_payload(str(src), str(dst), mode="AUTO_STRICT", fallback_fields=["CODE"])
    assert decision.decode_fields == ("CODE",)
    assert dst.read_text(encoding="utf-8") == "ID;CODE\n1;36\n"


def test_archive_copy_verify_delete(tmp_path):
    source = "/inbound/a.gpg"
    archive = "/inbound/archiv/a.gpg"
    storage = MemoryStorage({source: b"payload" * 1000})
    result = apply_remote_lifecycle(storage, source, "ARCHIVE", archive_target=archive, temp_dir=str(tmp_path))
    assert source not in storage.files
    assert archive in storage.files
    assert storage.files[archive] == b"payload" * 1000
    assert source in storage.deleted
    assert result.integrity == file_integrity(tmp_path / "src_a.gpg")


def test_archive_integrity_failure_keeps_source(tmp_path):
    source = "/inbound/a.gpg"
    archive = "/inbound/archiv/a.gpg"
    class CorruptStorage(MemoryStorage):
        def upload(self, local, remote):
            self.files[remote] = Path(local).read_bytes() + b"CORRUPT"
    storage = CorruptStorage({source: b"payload"})
    with pytest.raises(RuntimeError, match="integrity mismatch"):
        apply_remote_lifecycle(storage, source, "ARCHIVE", archive_target=archive, temp_dir=str(tmp_path))
    assert source in storage.files
    assert source not in storage.deleted


def test_keep_does_no_io():
    source = "/inbound/a.gpg"
    storage = MemoryStorage({source: b"x"})
    result = apply_remote_lifecycle(storage, source, "KEEP")
    assert result.action == "KEEP"
    assert source in storage.files
    assert storage.deleted == []

def test_delete_lifecycle_removes_source_without_archive():
    source = "/inbound/a.gpg"
    storage = MemoryStorage({source: b"x"})
    result = apply_remote_lifecycle(storage, source, "DELETE")
    assert result.action == "DELETE"
    assert source not in storage.files
    assert storage.deleted == [source]
