from pathlib import Path
from types import ModuleType
import sys

from app.storage import HldfStorage, normalize_hldf_path


class NotFound(Exception):
    status_code = 404


def backend(monkeypatch):
    m = ModuleType('app.common_hldf')
    m.calls = []
    def list_files(path):
        m.calls.append(('list_files', path))
        if path == '/missing':
            raise NotFound('FileNotFoundException: file-not-found')
        return ['ok']
    def list_dirs(path):
        m.calls.append(('list_dirs', path))
        if path == '/missing':
            raise RuntimeError('HTTP 404 FileNotFoundException')
        return ['child']
    def exists(path):
        m.calls.append(('exists', path))
        if path == '/missing':
            raise NotFound('not found')
        return True
    def upload_file_chunked(remote, local):
        m.calls.append(('upload', remote, local))
        return remote
    def rename(src, dst):
        m.calls.append(('rename', src, dst))
        return True
    def download_to_file(remote, local):
        m.calls.append(('download', remote))
        Path(local).write_bytes(b'x')
    m.list_files=list_files
    m.list_dirs=list_dirs
    m.exists=exists
    m.upload_file_chunked=upload_file_chunked
    m.rename=rename
    m.download_to_file=download_to_file
    monkeypatch.setitem(sys.modules, 'app.common_hldf', m)
    import app
    monkeypatch.setattr(app, 'common_hldf', m, raising=False)
    return m


def test_path_normalization_removes_double_slashes():
    assert normalize_hldf_path('//inbound//decrypted/') == '/inbound/decrypted'
    assert normalize_hldf_path('/auditlog') == '/auditlog'
    assert normalize_hldf_path('outbound/encrypted') == '/outbound/encrypted'


def test_missing_prefix_lists_as_empty(monkeypatch):
    backend(monkeypatch)
    s=HldfStorage()
    assert s.list_files('//missing/') == []
    assert s.list_dirs('//missing/') == []
    assert s.exists('//missing/') is False


def test_mkdirs_and_ensure_dirs_do_not_call_backend(monkeypatch):
    m=backend(monkeypatch)
    s=HldfStorage()
    assert s.mkdirs('//inbound') == '/inbound'
    s.ensure_dirs('//inbound', '//auditlog')
    assert m.calls == []


def test_upload_and_rename_use_normalized_full_paths_without_mkdir(monkeypatch, tmp_path):
    m=backend(monkeypatch)
    s=HldfStorage()
    local=tmp_path/'x.txt'
    local.write_text('x', encoding='utf-8')
    s.upload(str(local), '//outbound//encrypted//x.gpg')
    s.rename('//inbound//x.gpg', '//inbound//archiv//x.gpg')
    assert any(c[0] == 'upload' and c[1] == '/outbound/encrypted/x.gpg' and c[2] == str(local) for c in m.calls)
    assert ('rename', '/inbound/x.gpg', '/inbound/archiv/x.gpg') in m.calls
    assert not any(c[0] == 'mkdirs' for c in m.calls)
