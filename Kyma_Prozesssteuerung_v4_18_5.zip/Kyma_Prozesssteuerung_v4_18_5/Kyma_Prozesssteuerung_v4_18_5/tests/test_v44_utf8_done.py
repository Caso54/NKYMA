from pathlib import Path
from types import SimpleNamespace
import pytest

from app.set_orchestrator import SetOrchestrator
from app.utf8_utils import validate_utf8_file, write_utf8_text
from app.csv_transform import decode_base64_csv


def test_done_prefix_enabled_and_output_name_clean():
    o = SetOrchestrator.__new__(SetOrchestrator)
    o.cfg = SimpleNamespace(inbound_done_prefix_enabled=True, inbound_done_prefix='DONE_')
    logical = o._logical_inbound_name('DONE_AVQ_SAP_BP_ACP_20260924.gpg')
    assert logical == 'AVQ_SAP_BP_ACP_20260924.gpg'
    assert logical[:-4] == 'AVQ_SAP_BP_ACP_20260924'
    assert not logical.startswith('DONE_')


def test_done_prefix_can_be_disabled():
    o = SetOrchestrator.__new__(SetOrchestrator)
    o.cfg = SimpleNamespace(inbound_done_prefix_enabled=False, inbound_done_prefix='DONE_')
    assert o._logical_inbound_name('AVQ_SAP_BP_ACP_20260924.gpg') == 'AVQ_SAP_BP_ACP_20260924.gpg'


def test_utf8_without_bom_accepts_umlauts(tmp_path: Path):
    p = tmp_path / 'ok.csv'
    write_utf8_text(p, 'NAME;TEXT\nMüller;Grüezi – Zürich\n')
    validate_utf8_file(p, allow_bom=False)
    data = p.read_bytes()
    assert not data.startswith(b'\xef\xbb\xbf')
    assert 'Müller'.encode('utf-8') in data


def test_utf8_bom_rejected_for_inbound_payload(tmp_path: Path):
    p = tmp_path / 'bom.csv'
    p.write_bytes(b'\xef\xbb\xbfA;B\n1;2\n')
    with pytest.raises(UnicodeError):
        validate_utf8_file(p, allow_bom=False)


def test_invalid_utf8_rejected(tmp_path: Path):
    p = tmp_path / 'bad.csv'
    p.write_bytes(b'A;B\n\xff;2\n')
    with pytest.raises(UnicodeDecodeError):
        validate_utf8_file(p, allow_bom=False)


def test_base64_decoded_umlaut_is_written_utf8_without_bom(tmp_path: Path):
    import base64
    src = tmp_path / 'src.csv'
    dst = tmp_path / 'dst.csv'
    encoded = base64.b64encode('Grüezi Zürich'.encode('utf-8')).decode('ascii')
    src.write_text('ID;TEXT\n1;' + encoded + '\n', encoding='utf-8')
    decode_base64_csv(str(src), str(dst))
    raw = dst.read_bytes()
    assert not raw.startswith(b'\xef\xbb\xbf')
    assert 'Grüezi Zürich'.encode('utf-8') in raw
