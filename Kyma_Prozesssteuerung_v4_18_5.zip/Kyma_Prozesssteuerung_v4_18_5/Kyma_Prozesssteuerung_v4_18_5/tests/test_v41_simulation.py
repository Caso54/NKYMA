import sys
import types

# Test-only stub: production image installs hdbcli via requirements.txt.
hdbcli = types.ModuleType("hdbcli")
hdbcli.dbapi = types.SimpleNamespace(connect=lambda **kwargs: None)
sys.modules.setdefault("hdbcli", hdbcli)

from datetime import date
from types import SimpleNamespace

from app.datasphere import DataSphereHTTPError, TaskRun
from app.delivery_model import DeliveryModel
from app.set_orchestrator import SetOrchestrator


class FakeAudit:
    def __init__(self): self.events=[]
    def write(self, **kwargs): self.events.append(kwargs)

class FakeProcessRepo:
    def __init__(self): self.created=[]; self.updates=[]
    def create(self, **kwargs): self.created.append(kwargs); return 'proc-1'
    def update(self, process_uuid, **kwargs): self.updates.append((process_uuid, kwargs))

class FakeDSP:
    def __init__(self, start_seq=None, status_seq=None):
        self.start_seq=list(start_seq or [TaskRun('log-1')])
        self.status_seq=list(status_seq or ['SUCCEEDED'])
        self.start_calls=0; self.status_calls=0
    def run_task_chain(self, *args, **kwargs):
        self.start_calls += 1
        x=self.start_seq.pop(0)
        if isinstance(x, Exception): raise x
        return x
    def get_task_status(self, *args, **kwargs):
        self.status_calls += 1
        x=self.status_seq.pop(0)
        if isinstance(x, Exception): raise x
        return x

class FakeSetRepo:
    def __init__(self, summary, predecessor=True, deps=True, oldest=None):
        self.summary=summary; self.predecessor=predecessor; self.deps=deps; self.oldest=oldest; self.set_updates=[]
    def summarize_set(self, *args): return dict(self.summary)
    def predecessor_completed(self, *args): return self.predecessor
    def dependencies_completed(self, *args): return self.deps
    def update_set(self, *args, **kwargs): self.set_updates.append((args,kwargs))
    def oldest_open_missing_set(self, *args): return self.oldest


def orch_base():
    o=SetOrchestrator.__new__(SetOrchestrator)
    o.cfg=SimpleNamespace(
        max_retries=2, retry_wait_seconds=0, poll_interval_seconds=0,
        poll_timeout_seconds=5, dsp_host='https://tenant.example',
        datasphere_taskchain_api_enabled=True
    )
    o.audit=FakeAudit(); o.process_repo=FakeProcessRepo()
    return o


def sf():
    s=SimpleNamespace(set_id='BP', space_id='DS_DL', depends_on_sets=())
    f=SimpleNamespace(file_id='AVQ_SAP_BP_ACP')
    return s,f


def test_taskchain_retry_success_is_audited():
    o=orch_base(); s,f=sf()
    o.dsp=FakeDSP(
        start_seq=[DataSphereHTTPError(503,'temporary'), TaskRun('log-77')],
        status_seq=[DataSphereHTTPError(500,'temporary status'), 'RUNNING', 'SUCCEEDED']
    )
    final=o._run_file_taskchain(
        s=s,f=f,run_uuid='run-1',set_date=date(2026,9,23),
        task_chain_id='TC_BP',endpoint='https://tenant/run/TC_BP'
    )
    assert final is None
    assert o.dsp.start_calls == 2
    assert o.dsp.status_calls == 3
    statuses=[(e['process_type'],e['status'],e.get('http_status')) for e in o.audit.events]
    assert ('DSP_START_API','RETRY',503) in statuses
    assert ('DSP_START_API','SUCCESS',202) in statuses
    assert ('DSP_STATUS_API','RETRY',500) in statuses
    assert ('DSP_TASK_STATUS','RUNNING',None) in statuses
    assert ('DSP_TASK_STATUS','SUCCEEDED',None) in statuses
    assert any(u[1].get('status')=='SUCCESS' and u[1].get('end') for u in o.process_repo.updates)


def test_taskchain_terminal_failure_is_audited():
    o=orch_base(); s,f=sf(); o.dsp=FakeDSP(status_seq=['RUNNING','FAILED'])
    try:
        o._run_file_taskchain(s=s,f=f,run_uuid='run-2',set_date=date(2026,9,23),task_chain_id='TC_BP',endpoint='x')
        assert False, 'expected failure'
    except RuntimeError as exc:
        assert 'ended with status FAILED' in str(exc)
    assert any(e['process_type']=='DSP_TASK_STATUS' and e['status']=='FAILED' for e in o.audit.events)
    assert any(u[1].get('status')=='FAILED' and u[1].get('end') for u in o.process_repo.updates)


def test_set_status_matrix():
    s=SimpleNamespace(set_id='BP',depends_on_sets=(), required_files=())
    f1=SimpleNamespace(file_id='A'); f2=SimpleNamespace(file_id='B')
    class M:
        def active_required_files(self,*args): return (f1,f2)
    cases=[
        ({'expected':2,'received':0,'success':0,'missing':2,'failed':0}, True, True, 'WAITING'),
        ({'expected':2,'received':1,'success':1,'missing':1,'failed':0}, True, True, 'BLOCKED'),
        ({'expected':2,'received':2,'success':1,'missing':1,'failed':1}, True, True, 'FAILED'),
        ({'expected':2,'received':2,'success':2,'missing':0,'failed':0}, False, True, 'WAITING_PREDECESSOR'),
        ({'expected':2,'received':2,'success':2,'missing':0,'failed':0}, True, False, 'WAITING_DEPENDENCY'),
        ({'expected':2,'received':2,'success':2,'missing':0,'failed':0}, True, True, 'COMPLETED'),
    ]
    for summary,pred,deps,expected in cases:
        o=SetOrchestrator.__new__(SetOrchestrator); o.model=M(); o.repo=FakeSetRepo(summary,pred,deps)
        assert o.evaluate_set(s,date(2026,9,23)) == expected


def test_monthly_full_plus_daily_delta():
    m=DeliveryModel.load('config/delivery_model.json')
    al=next(s for s in m.sets if s.set_id=='AL')
    normal={f.file_id for f in m.active_required_files(al,date(2026,9,23))}
    monthly={f.file_id for f in m.active_required_files(al,date(2026,10,1))}
    assert 'AVQ_SAP_OBJ_DELTA_ACP' in normal and 'AVQ_SAP_OBJ_ACP' not in normal
    assert 'AVQ_SAP_OBJ_DELTA_ACP' in monthly and 'AVQ_SAP_OBJ_ACP' in monthly
    assert 'AVQ_SAP_NAME_INTL_DELTA_ACP' in monthly and 'AVQ_SAP_NAME_INTL_ACP' in monthly
    assert 'AVQ_SAP_CLASS2_DELTA_ACP' in monthly and 'AVQ_SAP_CLASS2_FILTERED_ACP' in monthly
