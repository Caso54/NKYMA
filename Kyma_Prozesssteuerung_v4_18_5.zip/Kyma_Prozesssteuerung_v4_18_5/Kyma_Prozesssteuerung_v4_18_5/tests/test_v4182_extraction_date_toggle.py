import json
from datetime import date
from pathlib import Path
from types import SimpleNamespace

from app.delivery_model import DeliveryModel
from app.set_orchestrator import SetOrchestrator


def _model(tmp_path):
    delivery = {
        "timezone": "Europe/Zurich",
        "rules": {"allowed_extraction_date_offset_days": [0, -1]},
        "sets": [{
            "set_id": "T1", "enabled": True, "space_id": "DS_DL",
            "required_files": [{
                "file_id": "FILE_A",
                "pattern": r"^FILE_A_(?P<extract_date>\d{8})\.gpg$",
                "fixed_mode": "DELTA", "active_when": "ALWAYS", "required": True,
            }]
        }]
    }
    p = tmp_path / "delivery.json"
    p.write_text(json.dumps(delivery), encoding="utf-8")
    return DeliveryModel.load(str(p))


class FakeStorage:
    def __init__(self, name):
        self.files = {"/inbound/" + name: b"payload"}
    def list_files(self, path):
        prefix = path.rstrip("/") + "/"
        return [p for p in self.files if p.startswith(prefix) and "/" not in p[len(prefix):]]
    def mkdirs(self, path): pass
    def exists(self, path): return path in self.files
    def download(self, remote, local): Path(local).write_bytes(self.files[remote])
    def upload(self, local, remote): self.files[remote] = Path(local).read_bytes()
    def delete_file(self, path): self.files.pop(path, None)


class FakeRepo:
    def ensure_set(self,*a,**k): pass
    def ensure_expected_file(self,*a,**k): pass
    def oldest_open_missing_set(self,*a,**k): return None
    def file_success_exists(self,*a,**k): return False
    def summarize_set(self,*a,**k): return {"expected":1,"received":1,"success":1,"missing":0,"failed":0}
    def predecessor_completed(self,*a,**k): return True
    def dependencies_completed(self,*a,**k): return True
    def update_set(self,*a,**k): pass


class Audit:
    def __init__(self): self.events=[]
    def write(self, **kwargs): self.events.append(kwargs)


def _orch(model, enabled):
    o = SetOrchestrator.__new__(SetOrchestrator)
    o.model = model
    o.storage = FakeStorage("FILE_A_20260925.gpg")
    o.repo = FakeRepo()
    o.audit = Audit(); o.hldf_audit = Audit()
    o.cfg = SimpleNamespace(
        inbound_path="/inbound", inbound_archive_path="/inbound/archiv",
        archive_unscheduled_files=True, archive_unknown_files=True,
        inbound_done_prefix_enabled=False, inbound_done_prefix="DONE_",
        manual_ingest_mode=False, schedule_enforcement_enabled=False,
        extraction_date_validation_enabled=enabled,
    )
    o.processed=[]
    o._process_file=lambda *a,**k: o.processed.append((a,k))
    return o


def test_old_extraction_date_rejected_when_validation_enabled(tmp_path):
    m=_model(tmp_path)
    object.__setattr__(m, "today", lambda: date(2026,9,27))
    o=_orch(m, True)
    o.ingest_available_files()
    assert o.processed == []
    assert any(e["process_type"] == "INVALID_EXTRACTION_DATE" for e in o.hldf_audit.events)


def test_old_extraction_date_accepted_when_validation_disabled(tmp_path):
    m=_model(tmp_path)
    object.__setattr__(m, "today", lambda: date(2026,9,27))
    o=_orch(m, False)
    o.ingest_available_files()
    assert len(o.processed) == 1
    assert any(e["process_type"] == "EXTRACTION_DATE_VALIDATION_BYPASS" for e in o.hldf_audit.events)
