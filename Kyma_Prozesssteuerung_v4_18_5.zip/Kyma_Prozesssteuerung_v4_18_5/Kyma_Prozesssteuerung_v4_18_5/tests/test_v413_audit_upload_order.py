from pathlib import Path
from types import ModuleType
import sys

from app.hldf_audit import HldfAuditLogger
from app.storage import HldfStorage


def _backend(monkeypatch):
    m = ModuleType("app.common_hldf")
    m.remote = {}
    m.calls = []

    def exists(path):
        return path in m.remote

    def download_to_file(remote, local):
        Path(local).write_bytes(m.remote[remote])

    # Proven common_hldf contract: remote path first, local file second.
    def upload_file_chunked(remote, local):
        m.calls.append((remote, local))
        assert remote.startswith("/")
        assert Path(local).exists()
        m.remote[remote] = Path(local).read_bytes()
        return remote

    m.exists = exists
    m.download_to_file = download_to_file
    m.upload_file_chunked = upload_file_chunked
    m.list_files = lambda path: []
    m.list_dirs = lambda path: []
    m.rename = lambda src, dst: True
    monkeypatch.setitem(sys.modules, "app.common_hldf", m)
    import app
    monkeypatch.setattr(app, "common_hldf", m, raising=False)
    return m


def test_storage_upload_passes_remote_then_local(monkeypatch, tmp_path):
    m = _backend(monkeypatch)
    storage = HldfStorage()
    local = tmp_path / "plain.csv"
    local.write_text("A;B\n1;2\n", encoding="utf-8")
    storage.upload(str(local), "//inbound//decrypted//plain.csv")
    remote, local_arg = m.calls[-1]
    assert remote == "/inbound/decrypted/plain.csv"
    assert local_arg == str(local)
    assert m.remote[remote] == local.read_bytes()


def test_audit_uses_temp_local_file_and_hldf_remote(monkeypatch):
    m = _backend(monkeypatch)
    storage = HldfStorage()
    audit = HldfAuditLogger(storage, "/auditlog", "SETS")
    result = audit.write(process_type="JOB", status="STARTED", message="test")
    assert result is not None
    remote, local_arg = m.calls[-1]
    assert remote.startswith("/auditlog/audit_sets_")
    assert remote.endswith(".csv")
    assert "/auditlog/" not in local_arg.replace("\\", "/")
    assert b"PROCESS_TYPE" in m.remote[remote]
    assert b"JOB" in m.remote[remote]


class BrokenStorage:
    def exists(self, remote):
        return False
    def upload(self, local, remote):
        raise RuntimeError("simulated audit backend failure")


def test_audit_failure_does_not_abort_business_process(caplog):
    audit = HldfAuditLogger(BrokenStorage(), "/auditlog", "INBOUND")
    result = audit.write(process_type="JOB", status="STARTED", message="test")
    assert result is None
    assert "HDLF audit write failed" in caplog.text
