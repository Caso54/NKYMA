from pathlib import Path

from app.csv_transform import decode_base64_csv
from app.outbound import OutboundAS300
from app.utf8_utils import validate_utf8_file


def test_streaming_utf8_validation_handles_chunk_boundaries(tmp_path):
    p = tmp_path / "x.csv"
    # multibyte UTF-8 sequence deliberately close to a small custom chunk boundary
    p.write_bytes(("A" * 31 + "ä" + "\n").encode("utf-8") * 1000)
    validate_utf8_file(p, allow_bom=False, chunk_size=32)


def test_csv_transform_preserves_dates_and_timestamps(tmp_path):
    src = tmp_path / "in.csv"
    dst = tmp_path / "out.csv"
    src.write_text(
        "DATE;TIMESTAMP;ENC\n2026-09-25;2026-09-25 16:05:06;SGVsbG8=\n",
        encoding="utf-8",
        newline="",
    )
    assert decode_base64_csv(str(src), str(dst)) == 1
    assert dst.read_text(encoding="utf-8") == (
        "DATE;TIMESTAMP;ENC\n2026-09-25;2026-09-25 16:05:06;Hello\n"
    )


def test_outbound_merge_emits_lf_only(tmp_path):
    p1 = tmp_path / "p1.csv"
    p2 = tmp_path / "p2.csv"
    out = tmp_path / "out.csv"
    p1.write_bytes(b"A;B\r\n1;2\r\n")
    p2.write_bytes(b"A;B\n3;4\n")
    assert OutboundAS300._merge_csv([str(p1), str(p2)], str(out)) == 2
    data = out.read_bytes()
    assert b"\r" not in data
    assert data == b"A;B\n1;2\n3;4\n"
