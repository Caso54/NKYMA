from datetime import date
from types import SimpleNamespace
from app.memory_repo import InMemoryDeliveryRepository
from app.set_orchestrator import SetOrchestrator


def _orchestrator(taskchain_enabled: bool):
    o = SetOrchestrator.__new__(SetOrchestrator)
    o.cfg = SimpleNamespace(datasphere_taskchain_api_enabled=taskchain_enabled)
    o.repo = InMemoryDeliveryRepository()
    return o


def test_decrypted_only_full_releases_delta_when_taskchain_disabled():
    o = _orchestrator(False)
    d = date(2026, 9, 27)
    o.repo.ensure_expected_file('SET', d, 'FULL', 'REQUIRED', 'FULL')
    o.repo.update_file_status(set_id='SET', set_date=d, file_id='FULL', run_uuid='r1', status='DECRYPTED_ONLY', end=True)
    assert o._full_ready_for_delta('SET', d, 'FULL') is True


def test_decrypted_only_full_does_not_release_delta_when_taskchain_enabled():
    o = _orchestrator(True)
    d = date(2026, 9, 27)
    o.repo.ensure_expected_file('SET', d, 'FULL', 'REQUIRED', 'FULL')
    o.repo.update_file_status(set_id='SET', set_date=d, file_id='FULL', run_uuid='r1', status='DECRYPTED_ONLY', end=True)
    assert o._full_ready_for_delta('SET', d, 'FULL') is False


def test_completed_full_releases_delta_in_both_modes():
    d = date(2026, 9, 27)
    for enabled in (False, True):
        o = _orchestrator(enabled)
        o.repo.ensure_expected_file('SET', d, 'FULL', 'REQUIRED', 'FULL')
        o.repo.update_file_status(set_id='SET', set_date=d, file_id='FULL', run_uuid='r1', status='COMPLETED', end=True)
        assert o._full_ready_for_delta('SET', d, 'FULL') is True


def test_failed_full_never_releases_delta():
    d = date(2026, 9, 27)
    for enabled in (False, True):
        o = _orchestrator(enabled)
        o.repo.ensure_expected_file('SET', d, 'FULL', 'REQUIRED', 'FULL')
        o.repo.update_file_status(set_id='SET', set_date=d, file_id='FULL', run_uuid='r1', status='FAILED', end=True)
        assert o._full_ready_for_delta('SET', d, 'FULL') is False
