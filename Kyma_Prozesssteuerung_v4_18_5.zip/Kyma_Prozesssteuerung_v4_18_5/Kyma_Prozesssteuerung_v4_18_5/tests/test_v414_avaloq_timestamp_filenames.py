from datetime import date

from app.delivery_model import ExpectedFile, normalize_inbound_filename_for_matching


def expected():
    return ExpectedFile(
        file_id="AVQ_SAP_REL_KEY_ACP",
        role="GENERIC",
        pattern=r"^AVQ_SAP_REL_KEY_ACP(?:[_-](?P<extract_date>\d{8})(?:[_-]?\d{6})?)?(?:\.csv)?(?:\.gpg)?$",
        required_mode="DELTA",
        active_when="ALWAYS",
        required=True,
        task_chain_id="TC_TEST",
        task_chain_endpoint=None,
        dsp_dataflow=None,
        pair_id=None,
    )


def test_compact_timestamp_still_matches():
    parsed = expected().parse("AVQ_SAP_REL_KEY_ACP_20260925_160506.csv.gpg")
    assert parsed["extraction_date"] == date(2026, 9, 25)
    assert parsed["mode"] == "DELTA"


def test_avaloq_separated_timestamp_matches():
    parsed = expected().parse("AVQ_SAP_REL_KEY_ACP_2026_09_25_16_05_06.csv.gpg")
    assert parsed["extraction_date"] == date(2026, 9, 25)
    assert parsed["mode"] == "DELTA"


def test_avaloq_separated_date_only_matches():
    parsed = expected().parse("AVQ_SAP_REL_KEY_ACP_2026_09_25.csv.gpg")
    assert parsed["extraction_date"] == date(2026, 9, 25)


def test_dash_separated_variant_is_supported_too():
    parsed = expected().parse("AVQ_SAP_REL_KEY_ACP_2026-09-25_16-05-06.csv.gpg")
    assert parsed["extraction_date"] == date(2026, 9, 25)


def test_original_filename_is_not_modified():
    original = "AVQ_SAP_REL_KEY_ACP_2026_09_25_16_05_06.csv.gpg"
    normalized = normalize_inbound_filename_for_matching(original)
    assert original == "AVQ_SAP_REL_KEY_ACP_2026_09_25_16_05_06.csv.gpg"
    assert normalized == "AVQ_SAP_REL_KEY_ACP_20260925_160506.csv.gpg"


def test_non_timestamp_filename_is_untouched():
    name = "AVQ_SAP_REL_KEY_ACP.csv.gpg"
    assert normalize_inbound_filename_for_matching(name) == name
