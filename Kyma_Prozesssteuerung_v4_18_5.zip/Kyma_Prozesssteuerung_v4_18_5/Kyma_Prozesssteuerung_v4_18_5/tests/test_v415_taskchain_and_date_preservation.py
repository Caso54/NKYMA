from pathlib import Path
import csv
from app.csv_transform import decode_base64_csv, _decode_candidate


def test_date_value_is_never_changed():
    assert _decode_candidate('2026-09-25') == '2026-09-25'


def test_timestamp_value_is_never_changed():
    assert _decode_candidate('2026-09-25 16:05:06') == '2026-09-25 16:05:06'


def test_csv_date_and_timestamp_roundtrip(tmp_path):
    src = tmp_path / 'in.csv'
    dst = tmp_path / 'out.csv'
    src.write_text('ID;DATE_FIELD;TS_FIELD\n1;2026-09-25;2026-09-25 16:05:06\n', encoding='utf-8')
    decode_base64_csv(str(src), str(dst))
    with dst.open('r', encoding='utf-8', newline='') as f:
        rows = list(csv.reader(f, delimiter=';'))
    assert rows[1][1] == '2026-09-25'
    assert rows[1][2] == '2026-09-25 16:05:06'


def test_poll_heartbeat_present_in_code():
    code = Path('app/set_orchestrator.py').read_text(encoding='utf-8')
    assert 'DataSphere taskchain poll:' in code
    assert 'logId=%s' in code
    assert 'elapsed=%ss' in code
    assert 'remaining=%ss' in code
