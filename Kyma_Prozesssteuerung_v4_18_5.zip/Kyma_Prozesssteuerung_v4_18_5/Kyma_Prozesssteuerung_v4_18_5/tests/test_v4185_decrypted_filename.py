from app.filename_utils import build_decrypted_filename


def test_remove_everything_from_acp_normal_name():
    assert build_decrypted_filename(
        "AVQ_SAP_NAME_INTL_ACP_2026_09_25_08_16_55.csv.gpg"
    ) == "AVQ_SAP_NAME_INTL.csv"


def test_remove_version_and_timestamp_after_acp():
    assert build_decrypted_filename(
        "AVQ_SAP_BAL_DELTA_ACP_V01A_2026_09_26_04_37_46.csv.gpg"
    ) == "AVQ_SAP_BAL_DELTA.csv"


def test_delta_marker_before_acp_is_preserved():
    assert build_decrypted_filename(
        "AVQ_SAP_CLASS2_DELTA_ACP_2026_09_25_16_06_06.csv.gpg"
    ) == "AVQ_SAP_CLASS2_DELTA.csv"


def test_filename_without_acp_keeps_previous_decrypted_name():
    assert build_decrypted_filename("OTHER_FILE_20260927.csv.gpg") == "OTHER_FILE_20260927.csv"


def test_path_is_reduced_to_basename():
    assert build_decrypted_filename(
        "/inbound/AVQ_SAP_ASSET_ACP_2026_09_25_16_05_07.csv.gpg"
    ) == "AVQ_SAP_ASSET.csv"


def test_set_orchestrator_uploads_to_stable_decrypted_name(monkeypatch, tmp_path):
    from datetime import date
    from types import SimpleNamespace
    import app.set_orchestrator as mod

    uploaded = []

    class Storage:
        def download(self, remote, local):
            from pathlib import Path
            Path(local).write_bytes(b"encrypted-placeholder")
        def upload(self, local, remote):
            uploaded.append(remote)

    class Repo:
        def upsert_file(self, **kwargs):
            pass
        def update_file_status(self, **kwargs):
            pass

    def fake_decrypt(_enc, plain, _passphrase):
        from pathlib import Path
        Path(plain).write_text("A;B\n1;2\n", encoding="utf-8")

    monkeypatch.setattr(mod, "decrypt_symmetric", fake_decrypt)

    o = mod.SetOrchestrator.__new__(mod.SetOrchestrator)
    o.cfg = SimpleNamespace(
        inbound_gpg_passphrase="secret",
        use_base64_decode=False,
        decrypted_path="/inbound/decrypted",
        inbound_success_lifecycle="KEEP",
        datasphere_taskchain_api_enabled=False,
        inbound_archive_path="/inbound/archiv",
        inbound_path="/inbound",
        base64_mode="AUTO_STRICT",
        base64_fallback_fields=(),
    )
    o.storage = Storage()
    o.repo = Repo()
    o._audit = lambda **kwargs: None

    s = SimpleNamespace(set_id="TEST")
    f = SimpleNamespace(file_id="NAME_INTL", role="FULL")
    o._process_file(
        "/inbound/AVQ_SAP_NAME_INTL_ACP_2026_09_25_08_16_55.csv.gpg",
        "AVQ_SAP_NAME_INTL_ACP_2026_09_25_08_16_55.csv.gpg",
        "AVQ_SAP_NAME_INTL_ACP_2026_09_25_08_16_55.csv.gpg",
        s, f, date(2026, 9, 27), date(2026, 9, 27), date(2026, 9, 25), "FULL",
    )

    assert uploaded == ["/inbound/decrypted/AVQ_SAP_NAME_INTL.csv"]
