import json
from datetime import date
from pathlib import Path
from types import SimpleNamespace

from app.delivery_model import DeliveryModel
from app.set_orchestrator import SetOrchestrator


def _model(tmp_path, *, holidays=None, enabled=False, set_schedule=None, file_schedule=None):
    delivery = {
        "timezone": "Europe/Zurich",
        "rules": {"allowed_extraction_date_offset_days": [0, -1]},
        "sets": [{
            "set_id": "T1", "enabled": True, "space_id": "DS_DL",
            "schedule": set_schedule,
            "required_files": [{
                "file_id": "FILE_A", "pattern": r"^FILE_A(?:_(?P<extract_date>\d{8}))?\.gpg$",
                "fixed_mode": "DELTA", "active_when": "ALWAYS", "required": True,
                "schedule": file_schedule,
            }]
        }]
    }
    dp = tmp_path / "delivery.json"
    dp.write_text(json.dumps(delivery), encoding="utf-8")
    hp = tmp_path / "holidays.json"
    hp.write_text(json.dumps({"calendar_id":"X","holidays":holidays or []}), encoding="utf-8")
    return DeliveryModel.load(str(dp), bank_holiday_calendar_enabled=enabled, bank_holiday_calendar_file=str(hp))


def test_weekdays_and_month_end(tmp_path):
    m = _model(tmp_path, set_schedule={"type":"WEEKDAYS"})
    s=m.sets[0]; f=s.required_files[0]
    assert m.file_active(s,f,date(2026,9,25)) is True  # Fri
    assert m.file_active(s,f,date(2026,9,26)) is False # Sat

    m2 = _model(tmp_path, set_schedule={"type":"MONTH_END"})
    s=m2.sets[0]; f=s.required_files[0]
    assert m2.file_active(s,f,date(2026,9,30)) is True
    assert m2.file_active(s,f,date(2026,9,29)) is False


def test_file_schedule_overrides_set(tmp_path):
    m = _model(tmp_path, set_schedule={"type":"WEEKDAYS"}, file_schedule={"type":"MONTH_END"})
    s=m.sets[0]; f=s.required_files[0]
    assert m.file_active(s,f,date(2026,10,31)) is True  # Saturday month-end override
    assert m.file_active(s,f,date(2026,10,30)) is False


def test_bank_holiday_toggle_and_empty_fallback(tmp_path):
    holiday="2026-09-25"
    m_off = _model(tmp_path, holidays=[holiday], enabled=False, set_schedule={"type":"BANK_WORKDAY"})
    s=m_off.sets[0]; f=s.required_files[0]
    assert m_off.file_active(s,f,date(2026,9,25)) is True

    m_empty = _model(tmp_path, holidays=[], enabled=True, set_schedule={"type":"BANK_WORKDAY"})
    s=m_empty.sets[0]; f=s.required_files[0]
    assert m_empty.file_active(s,f,date(2026,9,25)) is True

    m_on = _model(tmp_path, holidays=[holiday], enabled=True, set_schedule={"type":"BANK_WORKDAY"})
    s=m_on.sets[0]; f=s.required_files[0]
    assert m_on.file_active(s,f,date(2026,9,25)) is False


def test_nth_bank_workday(tmp_path):
    # Sep 1 2026 is Tuesday. Make Sep 2 a holiday; third bank workday becomes Sep 4.
    m = _model(tmp_path, holidays=["2026-09-02"], enabled=True,
               set_schedule={"type":"NTH_BANK_WORKDAY_OF_MONTH","n":3})
    s=m.sets[0]; f=s.required_files[0]
    assert m.file_active(s,f,date(2026,9,4)) is True
    assert m.file_active(s,f,date(2026,9,3)) is False


class FakeStorage:
    def __init__(self, files):
        self.files = {((x if str(x).startswith("/") else "/inbound/" + str(x))): b"test-payload" for x in files}
        self.renames = []
        self.deleted = []
        self.uploaded = []
    def list_files(self, path):
        prefix = path.rstrip("/") + "/"
        return [p for p in sorted(self.files) if p.startswith(prefix) and "/" not in p[len(prefix):]]
    def mkdirs(self,path): pass
    def exists(self,path): return path in self.files
    def rename(self,src,dst): self.renames.append((src,dst))
    def download(self, remote, local): Path(local).write_bytes(self.files[remote])
    def upload(self, local, remote):
        self.files[remote] = Path(local).read_bytes(); self.uploaded.append(remote)
    def delete_file(self, path):
        self.deleted.append(path); self.files.pop(path, None)

class FakeRepo:
    def ensure_set(self,*a,**k): pass
    def ensure_expected_file(self,*a,**k): pass
    def oldest_open_missing_set(self,*a,**k): return None
    def file_success_exists(self,*a,**k): return False
    def summarize_set(self,*a,**k): return {"expected":1,"received":0,"success":0,"missing":1,"failed":0}
    def predecessor_completed(self,*a,**k): return True
    def dependencies_completed(self,*a,**k): return True
    def update_set(self,*a,**k): pass

class FakeAudit:
    def __init__(self): self.events=[]
    def write(self,**k): self.events.append(k)


def _orch(model, files, tmp_path):
    o=SetOrchestrator.__new__(SetOrchestrator)
    o.model=model
    o.storage=FakeStorage(files)
    o.repo=FakeRepo()
    o.audit=FakeAudit()
    o.cfg=SimpleNamespace(
        inbound_path="/inbound", inbound_archive_path="/inbound/archiv",
        archive_unscheduled_files=True, archive_unknown_files=True,
        inbound_done_prefix_enabled=True, inbound_done_prefix="DONE_",
    )
    # no normal file should be processed in these archive tests
    o._process_file=lambda *a,**k: (_ for _ in ()).throw(AssertionError("must not process"))
    o.evaluate_set=lambda *a,**k: "NOT_REQUIRED"
    return o


def test_unscheduled_known_file_archived_and_warned(tmp_path):
    m=_model(tmp_path, set_schedule={"type":"WEEKDAYS"})
    object.__setattr__(m, "today", lambda: date(2026,9,26))
    o=_orch(m,["DONE_FILE_A_20260926.gpg"],tmp_path)
    o.ingest_available_files()
    assert "/inbound/archiv/DONE_FILE_A_20260926.gpg" in o.storage.uploaded
    assert "/inbound/DONE_FILE_A_20260926.gpg" in o.storage.deleted
    assert any(e["process_type"]=="FILE_NOT_SCHEDULED" and e["status"]=="WARNING" for e in o.audit.events)


def test_unknown_file_archived_and_warned(tmp_path):
    m=_model(tmp_path, set_schedule={"type":"DAILY"})
    object.__setattr__(m, "today", lambda: date(2026,9,24))
    o=_orch(m,["DONE_SOMETHING_UNKNOWN_20260924.gpg"],tmp_path)
    o.ingest_available_files()
    assert "/inbound/archiv/DONE_SOMETHING_UNKNOWN_20260924.gpg" in o.storage.uploaded
    assert "/inbound/DONE_SOMETHING_UNKNOWN_20260924.gpg" in o.storage.deleted
    assert any(e["process_type"]=="UNKNOWN_FILE" and e["status"]=="WARNING" for e in o.audit.events)


def test_incomplete_file_without_done_prefix_is_not_archived(tmp_path):
    m=_model(tmp_path, set_schedule={"type":"DAILY"})
    object.__setattr__(m, "today", lambda: date(2026,9,24))
    o=_orch(m,["FILE_A_20260924.gpg"],tmp_path)
    o.ingest_available_files()
    assert o.storage.renames == []
    assert o.audit.events == []
