# v4.16 Test Report

- Full regression: 77/77 passed.
- Focused taskchain/date tests: passed.
- `DATASPHERE_TASKCHAIN_API_ENABLED=false` is the delivered test default.
- With the switch disabled, `SetOrchestrator` does not construct a `DataSphereClient`; therefore no OAuth request and no taskchain POST/GET can occur.
- After successful decrypt/UTF-8 validation/optional Base64 transform the file is uploaded to `/inbound/decrypted`, status becomes `DECRYPTED_ONLY`, and processing returns before taskchain metadata/run.
- HDLF audit records `TASKCHAIN_API_SKIPPED`.
- Date values `YYYY-MM-DD` and timestamp values `YYYY-MM-DD HH:MM:SS` are preserved byte-for-value at field level by the transform and excluded from Base64 decoding.
- v4.15 taskchain poll heartbeat remains available when the switch is enabled: taskchain id, logId, poll number, status, elapsed seconds, remaining seconds.
