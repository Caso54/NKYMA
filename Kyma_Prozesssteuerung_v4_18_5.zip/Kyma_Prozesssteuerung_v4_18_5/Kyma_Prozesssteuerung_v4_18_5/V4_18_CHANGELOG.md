# v4.18 Changelog

## Ziel
v4.18 optimiert die v4.17-Streaming-Basis für große tägliche Datenmengen und verschärft die Dateisicherheit, ohne Business-Payloads vollständig in den RAM zu laden.

## Änderungen
- Neuer Base64-Modus `AUTO_STRICT`.
  - begrenzte Streaming-Analyse (`10.000` Datenzeilen standardmäßig),
  - automatische Auswahl nur eindeutig erkannter Base64-Spalten,
  - Datum/Timestamp bleiben unverändert,
  - keine CSV-Neuschreibung, wenn keine Transformation nötig ist.
- Feldbezogener Fallback über `BASE64_FALLBACK_FIELDS` und optional pro `process_rules.json`-Regel über `base64_fallback_fields`.
- `BASE64_MODE` unterstützt `AUTO_STRICT`, `ALL/LEGACY` und `OFF`.
- Sicherer Datei-Lifecycle `KEEP | ARCHIVE | DELETE`.
  - Inbound: `INBOUND_SUCCESS_LIFECYCLE`, Default `KEEP`.
  - Outbound: `OUTBOUND_SOURCE_LIFECYCLE`, Default `ARCHIVE`.
  - `ARCHIVE` ist zwingend `copy -> verify -> delete`.
  - Verify vergleicht Dateigröße und SHA-256 einer frisch zurückgelesenen Archivkopie mit der Quelle.
  - Bei Verify-/Upload-Fehler wird die Quelle nicht gelöscht.
- Outbound-Quellsnapshot bleibt laufbezogen; später eintreffende Dateien werden weiterhin nicht gelöscht.
- Große Payloads bleiben Streaming-basiert. Keine neuen Whole-file-Reads für Business-Payloads.
- DataSphere Taskchain API und OpenSQL bleiben in der ausgelieferten ConfigMap standardmäßig deaktiviert.

## Neue Module
- `app/file_integrity.py`
- `app/file_lifecycle.py`

## Kompatibilität
- Bestehender `decode_base64=true`-Schalter in `process_rules.json` bleibt erhalten.
- `ALL/LEGACY` stellt das bisherige feldweise Base64-Verhalten her.
- v4.18 ersetzt absichtlich unsichere reine `rename`-Archivtests durch verifizierte Copy/Delete-Tests.
