# Schedule configuration (v4.6)

Schedules can be defined on set level and overridden per file. If neither is present, legacy `active_when` behavior is preserved.

## Supported schedule types

- `DAILY`
- `WEEKDAYS`
- `DAYS_OF_WEEK` with `days: [MON, TUE, ...]`
- `MONTH_END`
- `MONTH_END_PLUS_1`
- `FIRST_DAY_OF_MONTH`
- `NTH_DAY_OF_MONTH` with `day`
- `DAILY_EXCEPT_MONTH_END`
- `BANK_WORKDAY`
- `NTH_BANK_WORKDAY_OF_MONTH` with `n`
- `MANUAL`

Any schedule may additionally use `exclude_bank_holidays: true`. This exclusion only has an effect if `BANK_HOLIDAY_CALENDAR_ENABLED=true` and at least one holiday is maintained.

## Set example

```json
{
  "set_id": "BP",
  "schedule": {
    "type": "WEEKDAYS",
    "exclude_bank_holidays": true
  }
}
```

## File override example for FULL/DELTA

```json
{
  "set_id": "AL",
  "schedule": {"type": "DAILY"},
  "required_files": [
    {
      "file_id": "AVQ_SAP_OBJ_DELTA_ACP",
      "fixed_mode": "DELTA",
      "schedule": {"type": "DAILY"}
    },
    {
      "file_id": "AVQ_SAP_OBJ_ACP",
      "fixed_mode": "FULL",
      "pair_id": "OBJ",
      "schedule": {"type": "MONTH_END"}
    }
  ]
}
```

At month-end both files are due. The existing orchestration rule still enforces FULL task chain completion before the paired DELTA task chain is started.

## Bank holiday calendar

ConfigMap:

```yaml
BANK_HOLIDAY_CALENDAR_ENABLED: "true"
BANK_HOLIDAY_CALENDAR_FILE: "/opt/app/config/bank_holidays.json"
```

`config/bank_holidays.json`:

```json
{
  "calendar_id": "BLKB_CH",
  "holidays": [
    "2026-01-01",
    "2026-12-25"
  ]
}
```

Fallback: if the switch is `false`, the file is missing, the file is blank, or `holidays` is empty, normal weekday/day rules apply without holiday exclusion.

## Unscheduled and unknown files

```yaml
HDLF_INBOUND_ARCHIVE_PATH: "/inbound/archiv"
ARCHIVE_UNSCHEDULED_FILES: "true"
ARCHIVE_UNKNOWN_FILES: "true"
```

- Known file but not due on that date: move original `DONE_*` GPG file to archive and audit `FILE_NOT_SCHEDULED` / `WARNING`.
- Unknown completed GPG file: move to archive and audit `UNKNOWN_FILE` / `WARNING`.
- Files without `DONE_` remain untouched when DONE-prefix gating is enabled because they may still be uploading.


## Manual / emergency ingest

Normal operation:

```yaml
SCHEDULE_ENFORCEMENT_ENABLED: "true"
MANUAL_INGEST_MODE: "false"
```

Emergency/manual ingest:

```yaml
SCHEDULE_ENFORCEMENT_ENABLED: "true"
MANUAL_INGEST_MODE: "true"
```

In manual mode only the schedule check is bypassed. The file must still be known in `delivery_model.json`, must satisfy the DONE-prefix gate when enabled, and is still subject to GPG, UTF-8, optional Base64 decoding, retry/timeout, duplicate/restart protection and audit logging. A `SCHEDULE_BYPASS / WARNING` event is always written to the HDLF audit. Unknown files remain blocked/archived. Only files actually present in the manual batch are registered; normal daily expected-file rows are not created. If a paired FULL and DELTA are both present, FULL is processed first. A DELTA supplied alone is allowed as an explicit manual action.

`SCHEDULE_ENFORCEMENT_ENABLED=false` is also supported as a global technical bypass, but `MANUAL_INGEST_MODE=true` is preferred for emergency operation because it is explicit in the audit trail.
