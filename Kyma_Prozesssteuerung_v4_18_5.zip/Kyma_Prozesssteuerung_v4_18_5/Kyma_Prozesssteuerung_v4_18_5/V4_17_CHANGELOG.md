# v4.17 – Streaming / Performance / Memory

## Goal
Remove whole-business-file memory loading and keep the existing functional behavior.

## Inbound / Sets
- UTF-8 validation is incremental (8 MiB chunks) instead of `Path.read_bytes()`.
- Base64 CSV transformation remains row-by-row and no longer performs a redundant full pre-validation pass.
- Date values `YYYY-MM-DD` and timestamps `YYYY-MM-DD HH:MM:SS` remain unchanged.
- Large decrypted intermediate files are deleted as soon as a transformed file is available.
- Stage logging now reports file size, process RSS and progress without logging payload data.
- Decrypt-only mode remains unchanged: `DATASPHERE_TASKCHAIN_API_ENABLED=false` stops after `/inbound/decrypted` upload.
- Legacy `inbound` mode now honors the same Taskchain API switch.

## Outbound AS-300
- No whole-file line-ending normalization in memory.
- CSV writer emits LF directly.
- Source parts are downloaded and merged one at a time and the local part is deleted immediately after merge.
- Existing header consistency validation, UTF-8 rules, encryption, archive-before-delete behavior and output naming remain unchanged.

## Audit
- The daily audit file is downloaded at most once per pod/day/process-family and cached locally.
- Each event is still uploaded immediately to HDLF.
- Audit failures still do not abort the business process.

## Kubernetes
- Inbound and outbound manifests point to `ghcr.io/caso54/kyma-dev:process-control-v4-17`.
- Existing test-phase ConfigMap switches are retained.
