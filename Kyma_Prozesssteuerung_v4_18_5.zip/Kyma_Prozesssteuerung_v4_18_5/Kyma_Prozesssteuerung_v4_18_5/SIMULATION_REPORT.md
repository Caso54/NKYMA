# Kyma Process Control v4.1 – Prüfung und Simulation

## Ergebnis

- Python-Syntaxprüfung: bestanden
- Bestehende Unit-Tests: bestanden
- Erweiterte Simulationstests: bestanden
- Gesamt: 6 Tests bestanden

## Gefundene und korrigierte Fehler

1. `SetOrchestrator` rief `active_files()` auf, obwohl das DeliveryModel nur `active_required_files()` / `all_active_files()` bereitstellt.
2. AuditRepository und ProcessRepository waren vorhanden, aber noch nicht in den produktiven Orchestrator eingebunden.
3. `schema.sql` enthielt die Tabellen `FI_IT_M_TA_PROCESS_STATUS` und `FI_IT_M_TA_AUDIT_LOG` noch nicht.
4. File-Status `LOADED` wurde bereits als Erfolg gewertet, obwohl die DataSphere-Taskchain noch nicht abgeschlossen war. Erfolg ist jetzt erst `COMPLETED`.
5. Die per File definierte DataSphere-Taskchain wurde im alten Orchestrator noch nicht ausgeführt. Jetzt wird sie pro File gestartet und überwacht.
6. Fehlende Extraktionsdatumsgruppe im Dateinamen konnte einen Runtime-Fehler erzeugen. Der Liefertag wird nun als Fallback verwendet; die Offset-Prüfung bleibt aktiv.
7. ConfigMap wurde um Taskchain-, Process- und Audit-Konfiguration erweitert.

## Simulierte Fälle

### 1. DataSphere Start-API mit Retry
- erster POST: HTTP 503
- Audit: `DSP_START_API / RETRY`
- zweiter POST: erfolgreich
- Audit: `DSP_START_API / SUCCESS`
- Ergebnis: Taskchain wird weiter überwacht

### 2. DataSphere Status-API mit Retry
- erster GET: HTTP 500
- Audit: `DSP_STATUS_API / RETRY`
- danach `RUNNING`
- danach `SUCCEEDED`
- Process-Status endet mit `SUCCESS`

### 3. DataSphere Taskchain endet fachlich/technisch mit FAILED
- Statusfolge: `RUNNING -> FAILED`
- Process-Status: `FAILED`
- Audit enthält `DSP_TASK_STATUS / FAILED`
- File-Verarbeitung schlägt fehl

### 4. Set-Statusmatrix
Geprüft wurden:
- kein File geliefert -> `WAITING`
- Teilmenge erfolgreich -> `BLOCKED`
- mindestens ein Prozess fehlgeschlagen -> `FAILED`
- alle Files fertig, Vorgänger offen -> `WAITING_PREDECESSOR`
- Dependency offen -> `WAITING_DEPENDENCY`
- alle Bedingungen erfüllt -> `COMPLETED`

### 5. Monatliche FULL-Logik
Für Set `AL` geprüft:
- normaler Tag: tägliche DELTA-Dateien aktiv, monatliche FULL-Dateien nicht aktiv
- 1. des Folgemonats: DELTA bleibt aktiv und FULL kommt zusätzlich dazu
- geprüft für OBJ, NAME_INTL und CLASS2

## Audit-Verhalten

Pro File werden u.a. folgende Events geschrieben:
- `FILE_RECEIVED`
- `GPG_DECRYPT / STARTED`
- `GPG_DECRYPT / SUCCESS`
- `DSP_START_API / STARTED`
- `DSP_START_API / SUCCESS|RETRY|FAILED`
- `DSP_STATUS_API / SUCCESS|RETRY|FAILED`
- `DSP_TASK_STATUS / <DataSphere-Status>` bei Statuswechsel
- `FILE_PROCESS / SUCCESS|FAILED`

API-Events enthalten soweit verfügbar:
- Taskchain-ID
- DSP logId
- HTTP-Methode
- HTTP-Status
- Endpoint
- Retry-Nummer
- Dauer in ms
- Fehlercode / Fehlermeldung

Secrets und Access Tokens werden nicht in das Auditlog geschrieben.

## Hinweis zur lokalen Testumgebung

Die Testumgebung außerhalb des Docker-Images enthält `hdbcli` nicht. Für die reinen In-Memory-Simulationen wurde deshalb nur im Test ein Stub verwendet. Das Produktiv-Image installiert `hdbcli` über `requirements.txt`.

## Noch real zu testen

Die Simulation ersetzt nicht den Integrationstest gegen:
- echtes HDLF
- echtes GPG Secret
- DataSphere OAuth
- echte DataSphere Taskchain APIs
- HANA/Open-SQL Tabellen

Diese Tests sollten mit suspendiertem CronJob und einem manuellen Kubernetes Job erfolgen.
